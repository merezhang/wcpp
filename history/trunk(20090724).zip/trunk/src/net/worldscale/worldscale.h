#pragma once



class worldscale
{
public:
    static void Main(void);
};


