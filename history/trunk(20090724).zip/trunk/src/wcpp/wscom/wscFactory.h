#ifndef __wscFactory_h__
#define __wscFactory_h__

#include "wsiFactory.h"
#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/ws_implements.h>


#define WS_IMPL_wsiFactory                                                                  \
    public:                                                                                 \
    virtual void CreateInstance(wsiObject * aOuter, const ws_iid & aIID, void ** ret) {     \
                                _realCreateInstance(aOuter,aIID,ret);}                      \
    virtual void LockFactory(ws_boolean aLock) {                                            \
                                _realLockFactory(aLock);}                                   \


class wscFactory : public wscObject, public wsiFactory
{
    WS_IMPL_wsiObject
    WS_IMPL_wsiFactory

    WS_IMPL_GET_INTERFACE_BEGIN
        WS_IMPL_GET_INTERFACE_BODY( wsiFactory )
    WS_IMPL_GET_INTERFACE_END
public:
    typedef wscObject super_class;
protected:
    wscFactory(void);
    ~wscFactory(void);
    virtual void _realCreateInstance(wsiObject * aOuter, const ws_iid & aIID, void ** ret);
    virtual void _realLockFactory(ws_boolean aLock);
};


#endif // __wscFactory_h__
