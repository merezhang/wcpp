#pragma once


#include <wcpp/wspr/ws_id.h>
#include <wcpp/wspr/ws_type.h>
#include "wsiServiceManager.h"
#include "wsiComponentManager.h"
#include "wsiComponentRegistrar.h"
#include "wsiMemory.h"


class wsiFile;
class wsiDirectoryServiceProvider;


class WSCOM
{
public:

	WSCOM(void);
	virtual ~WSCOM(void);

public:

	static void WS_InitWSCOM             (wsiServiceManager ** result, wsiFile * binDirectory, wsiDirectoryServiceProvider * appFileLocationProvider);
	static void WS_ShutdownWSCOM         (wsiServiceManager * servMgr);
	static void WS_GetServiceManager     (wsiServiceManager     ** result);
	static void WS_GetComponentManager   (wsiComponentManager   ** result);
	static void WS_GetComponentRegistrar (wsiComponentRegistrar ** result);
	static void WS_GetMemoryManager      (wsiMemory             ** result);

private:

	static void _GetGlobalManager        (const ws_iid & aIID, void ** ret);
	static void _WS_InitWSCOM            (wsiServiceManager ** result, wsiFile * binDirectory, wsiDirectoryServiceProvider * appFileLocationProvider);
	static void _WS_ShutdownWSCOM        (wsiServiceManager * servMgr);

};


