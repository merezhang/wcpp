#include "WSCOM_sub.h"
#include <wcpp/lang/wscThrowable.h>
#include <wcpp/wspr/wsuSingleLock.h>
#include <wcpp/wscom/wscModule.h>


void WSGetModule( wsiComponentManager *aCompMgr, wsiFile* location, wsiModule** return_cobj )
{
    WSCOM_sub::_real_WSGetModule( aCompMgr, location, return_cobj );
}


/*
***********************************************************************************************************************
	WSCOM
***********************************************************************************************************************
*/


void WSCOM::_WS_InitWSCOM(wsiServiceManager ** result, wsiFile * binDirectory, wsiDirectoryServiceProvider * appFileLocationProvider)
{
	WS_THROW( wseUnsupportedOperationException , "this is a WS_InitWSCOM in sub module." );
}


void WSCOM::_WS_ShutdownWSCOM(wsiServiceManager * servMgr)
{
	WS_THROW( wseUnsupportedOperationException , "this is a WS_ShutdownWSCOM in sub module." );
}


void WSCOM::_GetGlobalManager(const ws_iid & aIID, void ** ret)
{
	WSCOM_sub::GetGlobalManager_sub(aIID,ret);
}




/*
***********************************************************************************************************************
	WSCOM_sub
***********************************************************************************************************************
*/


void WSCOM_sub::_real_WSGetModule(wsiComponentManager *aCompMgr, wsiFile* location, wsiModule** return_cobj)
{
    if (aCompMgr==WS_NULL) {
        	WS_THROW( wseNullPointerException , "WSGetModule without Service Manager." );
    }

	ws_ptr<wsiComponentManager> cm;
	try {
		GetGlobalManager_sub( cm.GetIID(), (void**) (&cm) );
	} catch (...) {}
	if (!cm) {
		wsuSingleLock lock( & s_Mutex );
		s_GlobalMgr = aCompMgr;
	}

	wscModule::GetCurrentModule( return_cobj );
}


void WSCOM_sub::GetGlobalManager_sub(const ws_iid & aIID, void ** ret)
{
	wsuSingleLock lock( & s_Mutex );
	s_GlobalMgr->QueryInterface( aIID, ret );
}




ws_ptr<wsiComponentManager> WSCOM_sub::s_GlobalMgr;
wsuMutex WSCOM_sub::s_Mutex;




WSCOM_sub::WSCOM_sub(void)
{
}


WSCOM_sub::~WSCOM_sub(void)
{
}


