#include "wscMainModule.h"

#include <wcpp/lang/wsoLangService.h>
#include <wcpp/lang/service/wscLangService.h>


/*
 *************************************************************************************************
 *  wscModule
 *************************************************************************************************
 */


wsiModule * wscModule::NewCurrentModule(void)
{
    return (new wscMainModule());
}


/*
 *************************************************************************************************
 *  wscMainModule
 *************************************************************************************************
 */


wscMainModule::wscMainModule(void)
{
}


wscMainModule::~wscMainModule(void)
{
}


void wscMainModule::_realGetClassObject(wsiComponentManager * aCompMgr, const ws_cid & aCID, const ws_iid & aIID, void ** ret)
{
    if ((aCompMgr==WS_NULL) || (ret==WS_NULL)) {
        WS_THROW( wseNullPointerException , "" );
    }

    if ( aCID == wsoLangService::sCID ) {
        ws_ptr<wsiFactory> fa( new wscLangServiceFactory() );
        fa->QueryInterface( aIID, ret );
        return;
    }
    else {
        WS_THROW( wseClassNotFoundException , "" );
    }
}

