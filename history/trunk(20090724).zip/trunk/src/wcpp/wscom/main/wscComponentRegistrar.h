#pragma once
#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/ws_ptr.h>
#include "wsiComponentRegistrarEx.h"


#define WS_IMPL_wsiComponentRegistrarEx		\
    virtual void GetLibFileByCID(const ws_cid & aClass, wsiFile ** ret) {_realGetLibFileByCID(aClass,ret);}\
    virtual void SaveRegInfo(wsiFile * regfile) {_realSaveRegInfo(regfile);}\
    virtual void LoadRegInfo(wsiFile * regfile) {_realLoadRegInfo(regfile);}\


#define WS_IMPL_wsiComponentRegistrar		\
	public:		\
		\
	virtual void AutoRegister( wsiFile * aSpec ) \
		{ _realAutoRegister( aSpec ); } \
		\
	virtual void AutoUnregister( wsiFile * aSpec ) \
		{ _realAutoUnregister( aSpec ); } \
		\
	virtual void RegisterFactory(	const ws_cid & aClass, wsiString * aClassName, wsiString * aContractID, wsiFactory * aFactory ) \
		{ _realRegisterFactory(	aClass, aClassName, aContractID, aFactory );} \
		\
	virtual void UnregisterFactory(	const ws_cid & aClass, wsiFactory * aFactory ) \
		{ _realUnregisterFactory( aClass, aFactory );} \
		\
	virtual void RegisterFactoryLocation(	const ws_cid & aClass, wsiString * aClassName, wsiString * aContractID, wsiFile * aFile, wsiString * aLoaderStr, wsiString * aType ) \
		{ _realRegisterFactoryLocation(	aClass, aClassName, aContractID, aFile, aLoaderStr, aType );} \
		\
	virtual void UnregisterFactoryLocation(	const ws_cid & aClass, wsiFile * aFile ) \
		{ _realUnregisterFactoryLocation(	aClass, aFile );} \
		\
	virtual ws_boolean IsCIDRegistered( const ws_cid & aClass ) \
		{ return _realIsCIDRegistered( aClass );} \
		\
	virtual ws_boolean IsContractIDRegistered( wsiString * aContractID ) \
		{ return _realIsContractIDRegistered( aContractID );} \
		\
	virtual void EnumerateCIDs( wsiSimpleEnumerator ** rEnum ) \
		{ _realEnumerateCIDs( rEnum );} \
		\
	virtual void EnumerateContractIDs( wsiSimpleEnumerator ** rEnum ) \
		{ _realEnumerateContractIDs( rEnum );} \
		\
	virtual void CIDToContractID( const ws_cid & aClass, wsiString ** rContractID ) \
		{ _realCIDToContractID( aClass, rContractID );} \
		\
	virtual void ContractIDToCID( wsiString * aContractID, ws_cid & rClass ) \
		{ _realContractIDToCID( aContractID, rClass );} \


class wscComponentRegistrar : public  wsiComponentRegistrarEx
{
public:

	wscComponentRegistrar(void);
	~wscComponentRegistrar(void);

protected:

	virtual void       _realAutoRegister( wsiFile * aSpec ) ;
	virtual void       _realAutoUnregister( wsiFile * aSpec ) ;
	virtual void       _realRegisterFactory(	const ws_cid & aClass, wsiString * aClassName, wsiString * aContractID, wsiFactory * aFactory ) ;
	virtual void       _realUnregisterFactory(	const ws_cid & aClass, wsiFactory * aFactory ) ;
	virtual void       _realRegisterFactoryLocation(	const ws_cid & aClass, wsiString * aClassName, wsiString * aContractID, wsiFile * aFile, wsiString * aLoaderStr, wsiString * aType ) ;
	virtual void       _realUnregisterFactoryLocation(	const ws_cid & aClass, wsiFile * aFile ) ;
	virtual ws_boolean _realIsCIDRegistered( const ws_cid & aClass ) ;
	virtual ws_boolean _realIsContractIDRegistered( wsiString * aContractID ) ;
	virtual void       _realEnumerateCIDs( wsiSimpleEnumerator ** rEnum ) ;
	virtual void       _realEnumerateContractIDs( wsiSimpleEnumerator ** rEnum ) ;
	virtual void       _realCIDToContractID( const ws_cid & aClass, wsiString ** rContractID ) ;
	virtual void       _realContractIDToCID( wsiString * aContractID, ws_cid & rClass ) ;

    virtual void       _realGetLibFileByCID(const ws_cid & aClass, wsiFile ** ret);
    virtual void       _realSaveRegInfo(wsiFile * regfile);
    virtual void       _realLoadRegInfo(wsiFile * regfile);

};

