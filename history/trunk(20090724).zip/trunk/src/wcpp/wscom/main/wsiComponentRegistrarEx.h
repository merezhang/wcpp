#pragma once

#include <wcpp/wscom/wsiComponentRegistrar.h>


#define WS_IID_OF_wsiComponentRegistrarEx      \
    { 0x68d261d5, 0x8351, 0x4b75, { 0x80, 0x7e, 0xa2, 0x51, 0xbc, 0xe9, 0x9b, 0x43 } }
// {68D261D5-8351-4b75-807E-A251BCE99B43}


class wsiComponentRegistrarEx : public wsiComponentRegistrar
{
public:
    static const ws_iid sIID;
public:
    virtual void GetLibFileByCID(const ws_cid & aClass, wsiFile ** ret) = 0;
    virtual void SaveRegInfo(wsiFile * regfile) = 0;
    virtual void LoadRegInfo(wsiFile * regfile) = 0;
};

