#include "wscMemory.h"
#include <wcpp/lang/wscThrowable.h>


wscMemory::wscMemory(void)
{
}


wscMemory::~wscMemory(void)
{
}

	
void * wscMemory::_realAlloc(ws_int size)
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void * wscMemory::_realRealloc(void * ptr, ws_int newSize)
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscMemory::_realFree(void * ptr)
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscMemory::_realHeapMinimize(ws_boolean immediate)
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


ws_boolean wscMemory::_realIsLowMemory(void)
{
	WS_THROW( wseUnsupportedOperationException , "" );
}

