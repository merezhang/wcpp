#pragma once
#include "wsiModuleHolder.h"
#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/wscClass.h>
#include <wcpp/lang/ws_implements.h>
#include <wcpp/lang/ws_ptr.h>


class ws_library;
class wsiFile;


class wscSubModuleHolder : public wscObject, public wsiModuleHolder
{
    WS_IMPL_wsiObject;
    WS_IMPL_GET_CLASS( "wcpp.wscom.main.wscSubModuleHolder" );
public:
    wscSubModuleHolder(wsiFile * file);
    ~wscSubModuleHolder(void);
protected:
    virtual void GetModule(wsiModule ** ret);
private:
    ws_library * m_lib;
    void * m_proc;
};

