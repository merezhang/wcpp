#include "wscSubModuleHolder.h"
#include <wcpp/lang/wscThrowable.h>
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/wspr/ws_library.h>
#include <wcpp/wscom/wscModule.h>
#include <wcpp/io/wsiFile.h>
#include <wcpp/lang/wscString.h>
#include <wcpp/wscom/wseWSCOMException.h>
#include <wcpp/lang/ws_str.h>


/*
*********************************************************************************************************************
*   wscSubModuleHolder
*********************************************************************************************************************
*/


wscSubModuleHolder::wscSubModuleHolder(wsiFile * aFile)
:   m_lib(WS_NULL),
    m_proc(WS_NULL)
{
    ws_ptr<wsiFile> file(aFile);
    ws_str path;
    file->GetCanonicalPath( &path );

    ws_library * lib = ws_library::Load( path->GetBuffer() );
    if (lib==WS_NULL) {
        WS_THROW( wseLoadModuleException , "The lib file is not loaded." );
    }

    void * proc = lib->GetProc( WS_GET_MODULE_SYMBOL );
    if (proc==WS_NULL) {
        delete lib;
        lib = WS_NULL;
        WS_THROW( wseLoadModuleException , "The required symbol [WSGetModule] is not found in library." );
    }

    m_proc = proc;
    m_lib  = lib;
}


wscSubModuleHolder::~wscSubModuleHolder(void)
{
    ws_library * lib = m_lib;
    m_lib = WS_NULL;
    if (lib) {
        delete lib;
    }
}


void wscSubModuleHolder::GetModule(wsiModule ** ret)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}

