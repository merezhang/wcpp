#ifndef __wscMainModule_h__
#define __wscMainModule_h__

#include <wcpp/wscom/wscModule.h>


class wscMainModule : public wscModule
{
    WS_IMPL_GET_CLASS( "wcpp.wscom.main.wscMainModule" )
public:
	wscMainModule(void);
	~wscMainModule(void);
	virtual void _realGetClassObject(wsiComponentManager * aCompMgr, const ws_cid & aCID, const ws_iid & aIID, void ** ret);
};


#endif // __wscMainModule_h__
