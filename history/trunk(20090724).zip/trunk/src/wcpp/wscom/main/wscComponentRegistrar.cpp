#include "wscComponentRegistrar.h"
#include <wcpp/lang/wscThrowable.h>
#include "wsiComponentRegistrarEx.h"
#include <wcpp/io/wsiFile.h>
#include "wscSubModuleHolder.h"
#include <wcpp/wscom/wsiComponentManager.h>
#include <wcpp/wscom/WSCOM.h>
#include <wcpp/lang/ws_str.h>
#include <wcpp/wscom/wsiModule.h>


wscComponentRegistrar::wscComponentRegistrar(void)
{
}


wscComponentRegistrar::~wscComponentRegistrar(void)
{
}


void wscComponentRegistrar::_realAutoRegister( wsiFile * aSpec )
{
    if (aSpec == WS_NULL) {
        WS_THROW( wseNullPointerException, "wsiComponentRegistrar::AutoRegister(wsiFile * aSpec) with a null wsiFile." );
    }
    if ( aSpec->IsDirectory() ) {
        // is a directory
        ws_ptr<wsiFileArray> fileArray;
        aSpec->ListFiles( (&fileArray) );
        const ws_long cntFile = fileArray->GetSize();
        for (ws_long i=0; i<cntFile; i++) {
            try {
                ws_ptr<wsiFile> rFile;
                fileArray->GetItem( i, (&rFile) );
                if (!rFile->IsDirectory()) {
                    AutoRegister( rFile );
                }
            }
            catch (...) {
            }
        }
    }
    else {
        // is a normal file (not a directory)
        ws_ptr<wsiModuleHolder> subModuleHolder( new wscSubModuleHolder(aSpec) );
        ws_ptr<wsiModule> subModule;
        subModuleHolder->GetModule( &subModule );
        ws_ptr<wsiComponentManager> compMgr;
        WSCOM::WS_GetComponentManager( &compMgr );
        ws_str aLoaderStr, aType;
        subModule->RegisterSelf( compMgr, aSpec, aLoaderStr, aType );
    }
}


void wscComponentRegistrar::_realAutoUnregister( wsiFile * aSpec )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realRegisterFactory(	const ws_cid & aClass, wsiString * aClassName, wsiString * aContractID, wsiFactory * aFactory )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realUnregisterFactory(	const ws_cid & aClass, wsiFactory * aFactory )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realRegisterFactoryLocation(	const ws_cid & aClass, wsiString * aClassName, wsiString * aContractID, wsiFile * aFile, wsiString * aLoaderStr, wsiString * aType )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realUnregisterFactoryLocation(	const ws_cid & aClass, wsiFile * aFile )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


ws_boolean wscComponentRegistrar::_realIsCIDRegistered( const ws_cid & aClass )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


ws_boolean wscComponentRegistrar::_realIsContractIDRegistered( wsiString * aContractID )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realEnumerateCIDs( wsiSimpleEnumerator ** rEnum )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realEnumerateContractIDs( wsiSimpleEnumerator ** rEnum )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realCIDToContractID( const ws_cid & aClass, wsiString ** rContractID )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realContractIDToCID( wsiString * aContractID, ws_cid & rClass )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realGetLibFileByCID(const ws_cid & aClass, wsiFile ** ret)
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realSaveRegInfo(wsiFile * regfile)
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realLoadRegInfo(wsiFile * regfile)
{
	WS_THROW( wseUnsupportedOperationException , "" );
}

