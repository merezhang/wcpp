#include "wscGlobalManager.h"


void wscGlobalManager::GetGlobalManager(const ws_iid & aIID, void ** ret)
{
    static ws_ptr<wsiServiceManager> sGM( new wscGlobalManager() );
    sGM->QueryInterface( aIID, ret );
}


wscGlobalManager::wscGlobalManager(void)
{
}


wscGlobalManager::~wscGlobalManager(void)
{
}

