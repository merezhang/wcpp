#include "wscServiceManager.h"
#include <wcpp/wspr/wsuSingleLock.h>
#include <wcpp/lang/wscThrowable.h>
#include <wcpp/wscom/wsiComponentManager.h>
#include <wcpp/wscom/WSCOM.h>
#include <wcpp/wscom/wsiComponentRegistrar.h>


wscServiceManager::wscServiceManager(void)
{
}


wscServiceManager::~wscServiceManager(void)
{
}


void wscServiceManager::AddService(const ws_cid & aClass, wsiObject * obj)
{
	service_list::value_type val( aClass, obj );
	wsuSingleLock lock( & m_mutexForServiceList );
	m_services.insert( val );
}


void wscServiceManager::FindService(const ws_cid & aClass, wsiObject ** ret)
{
	wsuSingleLock lock( & m_mutexForServiceList );

	service_list::iterator iter = m_services.find( aClass );
	service_list::iterator end  = m_services.end();
    if (iter == end) {
		WS_THROW( wseClassNotFoundException , "no required service-obj in service-list." );
    }

	(*iter).second.QueryInterface( ret );
}




void wscServiceManager::_realGetService(const ws_cid & aClass, const ws_iid & aIID, void ** ret)
{
	ws_ptr<wsiObject> obj;
	try {
		FindService( aClass, &obj );
	} catch (...) {
		ws_ptr<wsiComponentManager> compMgr;
		WSCOM::WS_GetComponentManager( &compMgr );
		compMgr->CreateInstance( aClass, WS_NULL, obj.GetIID(), (void**) (&obj) );
		AddService( aClass, obj );
	}
	obj->QueryInterface( aIID, ret );
}


void wscServiceManager::_realGetServiceByContractID(wsiString * aContractID, const ws_iid & aIID, void ** ret)
{
	ws_ptr<wsiComponentRegistrar> cr;
	WSCOM::WS_GetComponentRegistrar( &cr );
	ws_cid cid;
	cr->ContractIDToCID( aContractID, cid );
	GetService( cid, aIID, ret );
}


ws_boolean wscServiceManager::_realIsServiceInstantiated(const ws_cid & aClass, const ws_iid & aIID)
{
	try {
		ws_ptr<wsiObject> obj;
		FindService( aClass, &obj );
		ws_ptr<wsiInterface> ret;
		obj->QueryInterface( aIID, (void**) (&ret) );
		return WS_TRUE;
	} catch (...) {}
	return WS_FALSE;
}


ws_boolean wscServiceManager::_realIsServiceInstantiatedByContractID(wsiString * aContractID, const ws_iid & aIID)
{
	ws_ptr<wsiComponentRegistrar> cr;
	WSCOM::WS_GetComponentRegistrar( &cr );
	ws_cid cid;
	cr->ContractIDToCID( aContractID, cid );
	return IsServiceInstantiated( cid, aIID );
}



