#pragma once
#include <wcpp/lang/wsiObject.h>


#define WS_IID_OF_wsiFactory        \
    { 0x2f9aa5ce, 0x40e9, 0x45ec, { 0x98, 0x2d, 0xa8, 0x46, 0xcc, 0x76, 0xbe, 0x13 } }
// {2F9AA5CE-40E9-45ec-982D-A846CC76BE13}


class wsiFactory : public wsiObject
{
public:
	static const ws_iid sIID;
public:
	virtual void CreateInstance(wsiObject * aOuter, const ws_iid & aIID, void ** ret) = 0;
	virtual void LockFactory(ws_boolean aLock) = 0;
};

