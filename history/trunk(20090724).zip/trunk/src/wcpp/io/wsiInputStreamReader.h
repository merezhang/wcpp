#ifndef __wsiInputStreamReader_h__
#define __wsiInputStreamReader_h__

#include "wsiReader.h"




class wsiInputStreamReader : public wsiReader
{
public:
	static const ws_iid sIID;
};




#endif // __wsInputStreamReader_h__
