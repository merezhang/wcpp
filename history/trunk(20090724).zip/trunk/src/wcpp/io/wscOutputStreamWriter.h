﻿#ifndef __wscOutputStreamWriter_h__
#define __wscOutputStreamWriter_h__

#include "wscWriter.h"
#include "wsiOutputStreamWriter.h"




class wscOutputStreamWriter : public wscWriter, public wsiOutputStreamWriter
{
};




#endif // __wsOutputStreamWriter_h__
