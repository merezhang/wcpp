#include "wscPrintStream.h"
#include <wcpp/lang/ws_str.h>
#include <wcpp/lang/wscLong.h>



#define WS_CHAR_LN '\n'




wscPrintStream::wscPrintStream(wsiOutputStream * out) : mOut(out), mErr(WS_FALSE)
{
	if (out) out->AddRef();
}


wscPrintStream::~wscPrintStream(void)
{
	wsiOutputStream * p = mOut;
	mOut = WS_NULL;
	if (p) p->Release();
}




void wscPrintStream::_realSetError(void)
{
	mErr = WS_TRUE;
}


ws_boolean wscPrintStream::_realCheckError(void)
{
	return mErr;
}


void wscPrintStream::_realClose(void)
{
	wsiOutputStream * p = mOut;
	if (p) p->Close();
}


void wscPrintStream::_realFlush(void)
{
	wsiOutputStream * p = mOut;
	if (p) p->Flush();
}


void wscPrintStream::_realWrite(const void * const buf, const ws_int len)
{
	wsiOutputStream * p = mOut;
	if (p) p->Write(buf,len);
}


void wscPrintStream::_realWrite(ws_int b)
{
	wsiOutputStream * p = mOut;
	if (p) p->Write(b);
}




void wscPrintStream::_realPrint(ws_boolean b)
{
	if (b) {
		_realWrite("true",4);
	} else {
		_realWrite("false",5);
	}
}


void wscPrintStream::_realPrint(ws_char c)
{
	_realWrite( c );
}


void wscPrintStream::_realPrint(const ws_char * const s)
{
	const ws_char * p = s;
	ws_int len = 0;
	while (*p) { len++; p++; }
	_realWrite( s, len );
}


void wscPrintStream::_realPrint(ws_double d)
{
}


void wscPrintStream::_realPrint(ws_float f)
{
}


void wscPrintStream::_realPrint(ws_int i)
{
}


void wscPrintStream::_realPrint(ws_long l)
{
	ws_str str;
	wscLong::ToString( l, &str );
	_realPrint( (wsiString*) str );
}


void wscPrintStream::_realPrint(wsiObject * obj)
{
	if (obj) {
		ws_str str;
		obj->ToString( &str );
		_realPrint( (wsiString*) str );
	}
}


void wscPrintStream::_realPrint(wsiString * str)
{
    ws_ptr<wsiString> p(str);
	const ws_char * buf = p->GetBuffer();
	const ws_int    len = p->GetLength();
	_realWrite( buf, len );
}


void wscPrintStream::_realPrintLn(void)
{
	_realWrite( WS_CHAR_LN );
}


void wscPrintStream::_realPrintLn(ws_boolean x)
{
	_realPrint(x);
	_realWrite( WS_CHAR_LN );
}


void wscPrintStream::_realPrintLn(ws_char x)
{
	_realPrint(x);
	_realWrite( WS_CHAR_LN );
}


void wscPrintStream::_realPrintLn(const ws_char * const x)
{
	_realPrint(x);
	_realWrite( WS_CHAR_LN );
}


void wscPrintStream::_realPrintLn(ws_double x)
{
	_realPrint(x);
	_realWrite( WS_CHAR_LN );
}


void wscPrintStream::_realPrintLn(ws_float x)
{
	_realPrint(x);
	_realWrite( WS_CHAR_LN );
}


void wscPrintStream::_realPrintLn(ws_int x)
{
	_realPrint(x);
	_realWrite( WS_CHAR_LN );
}


void wscPrintStream::_realPrintLn(ws_long x)
{
	_realPrint(x);
	_realWrite( WS_CHAR_LN );
}


void wscPrintStream::_realPrintLn(wsiObject * x)
{
	_realPrint(x);
	_realWrite( WS_CHAR_LN );
}


void wscPrintStream::_realPrintLn(wsiString * x)
{
	_realPrint(x);
	_realWrite( WS_CHAR_LN );
}



