#include "wscOutputStream.h"
#include <wcpp/lang/wscThrowable.h>


wscOutputStream::wscOutputStream(void)
{
}


wscOutputStream::~wscOutputStream(void)
{
}


void wscOutputStream::_realClose(void)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


void wscOutputStream::_realWrite(const void * const buf, const ws_int len)
{
    const ws_byte * bin =(const ws_byte *) buf;
    for (ws_int i=0; i<len; i++) {
        _realWrite( bin[i] );
    }
}


void wscOutputStream::_realFlush(void)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}

