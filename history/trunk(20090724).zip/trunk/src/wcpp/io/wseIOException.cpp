// wsIOException.cpp

#include "wseIOException.h"




const ws_char* const wseIOException::sSTR                  = "wcpp.io.wseIOException";
const ws_char* const wseEOFException::sSTR                 = "wcpp.io.wseEOFException";
const ws_char* const wseUnsupportedEncodingException::sSTR = "wcpp.io.wseUnsupportedEncodingException";
const ws_char* const wseUTFDataFormatException::sSTR       = "wcpp.io.wseUTFDataFormatException";
const ws_char* const wseInterruptedIOException::sSTR       = "wcpp.io.wseInterruptedIOException";



