#include "wsiFile.h"
#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/ws_str.h>
#include <wcpp/lang/wscString.h>


#define WS_IMPL_wsiFile     \
    public:                 \
    virtual ws_boolean CanExecute(void)                                             { return _realCanExecute(); } \
    virtual ws_boolean CanRead(void)                                                { return _realCanRead(); } \
    virtual ws_boolean CanWrite(void)                                               { return _realCanWrite(); } \
    virtual ws_int     CompareTo(wsiFile * pathname)                                { return _realCompareTo(pathname); } \
    virtual ws_boolean CreateNewFile(void)                                          { return _realCreateNewFile(); } \
    virtual ws_boolean Delete(void)                                                 { return _realDelete(); } \
    virtual void       DeleteOnExit(void)                                           { _realDeleteOnExit(); } \
/*  virtual ws_boolean Equals(wsiObject * obj)                                      { _realEquals(obj); } */ \
    virtual ws_boolean Exists(void)                                                 { return _realExists(); } \
    virtual void       GetAbsoluteFile(wsiFile ** ret)                              { _realGetAbsoluteFile(ret); } \
    virtual void       GetAbsolutePath(wsiString ** ret)                            { _realGetAbsolutePath(ret); } \
    virtual void       GetCanonicalFile(wsiFile ** ret)                             { _realGetCanonicalFile(ret); } \
    virtual void       GetCanonicalPath(wsiString ** ret)                           { _realGetCanonicalPath(ret); } \
    virtual ws_long    GetFreeSpace(void)                                           { return _realGetFreeSpace(); } \
    virtual void       GetName(wsiString ** ret)                                    { _realGetName(ret); } \
    virtual void       GetParent(wsiString ** ret)                                  { _realGetParent(ret); } \
    virtual void       GetParentFile(wsiFile ** ret)                                { _realGetParentFile(ret); } \
    virtual void       GetPath(wsiString ** ret)                                    { _realGetPath(ret); } \
    virtual ws_long    GetTotalSpace(void)                                          { return _realGetTotalSpace(); } \
    virtual ws_long    GetUsableSpace(void)                                         { return _realGetUsableSpace(); } \
/*  virtual ws_int     HashCode(void)                                               { return _realHashCode(); } */ \
    virtual ws_boolean IsAbsolute(void)                                             { return _realIsAbsolute(); } \
    virtual ws_boolean IsDirectory(void)                                            { return _realIsDirectory(); } \
    virtual ws_boolean IsFile(void)                                                 { return _realIsFile(); } \
    virtual ws_boolean IsHidden(void)                                               { return _realIsHidden(); } \
    virtual ws_long    LastModified(void)                                           { return _realLastModified(); } \
    virtual ws_long    Length(void)                                                 { return _realLength(); } \
    virtual void       List(wsiStringArray ** ret)                                  { _realList(ret); } \
    virtual void       List(wsiFilenameFilter * filter, wsiStringArray ** ret)      { _realList(filter, ret); } \
    virtual void       ListFiles(wsiFileArray ** ret)                               { _realListFiles(ret); } \
    virtual void       ListFiles(wsiFileFilter * filter, wsiFileArray ** ret)       { _realListFiles(filter, ret); } \
    virtual void       ListFiles(wsiFilenameFilter * filter, wsiFileArray ** ret)   { _realListFiles(filter, ret); } \
    virtual ws_boolean Mkdir(void)                                                  { return _realMkdir(); } \
    virtual ws_boolean Mkdirs(void)                                                 { return _realMkdirs(); } \
    virtual ws_boolean RenameTo(wsiFile * dest)                                     { return _realRenameTo(dest); } \
    virtual ws_boolean SetExecutable(ws_boolean executable)                         { return _realSetExecutable(executable); } \
    virtual ws_boolean SetExecutable(ws_boolean executable, ws_boolean ownerOnly)   { return _realSetExecutable(executable, ownerOnly); } \
    virtual ws_boolean SetLastModified(ws_long time)                                { return _realSetLastModified(time); } \
    virtual ws_boolean SetReadable(ws_boolean readable)                             { return _realSetReadable(readable); } \
    virtual ws_boolean SetReadable(ws_boolean readable, ws_boolean ownerOnly)       { return _realSetReadable(readable, ownerOnly); } \
    virtual ws_boolean SetReadOnly(void)                                            { return _realSetReadOnly(); } \
    virtual ws_boolean SetWritable(ws_boolean writable)                             { return _realSetWritable(writable); } \
    virtual ws_boolean SetWritable(ws_boolean writable, ws_boolean ownerOnly)       { return _realSetWritable(writable, ownerOnly); } \
/*  virtual void       ToString(wsiString ** ret)                                   { _realToString(ret); } */ \
    virtual void       ToURI(wsiURI ** ret)                                         { _realToURI(ret); } \




class wscFile : public wscObject, public wsiFile
{
    WS_IMPL_wsiObject
    WS_IMPL_wsiFile
    WS_IMPL_GET_CLASS( "wcpp.io.wscFile" )
public:
    wscFile(wsiFile * parent, wsiString * child);
    wscFile(wsiString * pathname);
    wscFile(wsiString * parent, wsiString * child);
    wscFile(wsiURI * uri);
    ~wscFile(void);
public:
    static void CreateTempFile(wsiString * prefix, wsiString * suffix, wsiFile ** ret);
            // ��Ĭ����ʱ�ļ�Ŀ¼�д���һ�����ļ���ʹ�ø���ǰ׺�ͺ�׺���������ơ� 
    static void CreateTempFile(wsiString * prefix, wsiString * suffix, wsiFile * directory, wsiFile ** ret);
            // ��ָ��Ŀ¼�д���һ���µĿ��ļ���ʹ�ø�����ǰ׺�ͺ�׺�ַ������������ơ� 
    static void ListRoots(wsiFileArray ** ret);
            // �г����õ��ļ�ϵͳ���� 
protected:
    virtual ws_boolean _realCanExecute(void) ;
    virtual ws_boolean _realCanRead(void) ;
    virtual ws_boolean _realCanWrite(void) ;
    virtual ws_int     _realCompareTo(wsiFile * pathname) ;
    virtual ws_boolean _realCreateNewFile(void) ;
    virtual ws_boolean _realDelete(void) ;
    virtual void       _realDeleteOnExit(void) ;
    virtual ws_boolean _realEquals(wsiObject * obj) ;
    virtual ws_boolean _realExists(void) ;
    virtual void       _realGetAbsoluteFile(wsiFile ** ret) ;
    virtual void       _realGetAbsolutePath(wsiString ** ret) ;
    virtual void       _realGetCanonicalFile(wsiFile ** ret) ;
    virtual void       _realGetCanonicalPath(wsiString ** ret) ;
    virtual ws_long    _realGetFreeSpace(void) ;
    virtual void       _realGetName(wsiString ** ret) ;
    virtual void       _realGetParent(wsiString ** ret) ;
    virtual void       _realGetParentFile(wsiFile ** ret) ;
    virtual void       _realGetPath(wsiString ** ret) ;
    virtual ws_long    _realGetTotalSpace(void) ;
    virtual ws_long    _realGetUsableSpace(void) ;
    virtual ws_int     _realHashCode(void) ;
    virtual ws_boolean _realIsAbsolute(void) ;
    virtual ws_boolean _realIsDirectory(void) ;
    virtual ws_boolean _realIsFile(void) ;
    virtual ws_boolean _realIsHidden(void) ;
    virtual ws_long    _realLastModified(void) ;
    virtual ws_long    _realLength(void) ;
    virtual void       _realList(wsiStringArray ** ret) ;
    virtual void       _realList(wsiFilenameFilter * filter, wsiStringArray ** ret) ;
    virtual void       _realListFiles(wsiFileArray ** ret) ;
    virtual void       _realListFiles(wsiFileFilter * filter, wsiFileArray ** ret) ;
    virtual void       _realListFiles(wsiFilenameFilter * filter, wsiFileArray ** ret) ;
    virtual ws_boolean _realMkdir(void) ;
    virtual ws_boolean _realMkdirs(void) ;
    virtual ws_boolean _realRenameTo(wsiFile * dest) ;
    virtual ws_boolean _realSetExecutable(ws_boolean executable) ;
    virtual ws_boolean _realSetExecutable(ws_boolean executable, ws_boolean ownerOnly) ;
    virtual ws_boolean _realSetLastModified(ws_long time) ;
    virtual ws_boolean _realSetReadable(ws_boolean readable) ;
    virtual ws_boolean _realSetReadable(ws_boolean readable, ws_boolean ownerOnly) ;
    virtual ws_boolean _realSetReadOnly(void) ;
    virtual ws_boolean _realSetWritable(ws_boolean writable) ;
    virtual ws_boolean _realSetWritable(ws_boolean writable, ws_boolean ownerOnly) ;
    virtual void       _realToString(wsiString ** ret) ;
    virtual void       _realToURI(wsiURI ** ret) ;
private:
    void Init(const ws_char * const aPathStrBuf, const ws_int aPathStrLen);
private:
    ws_str m_path;
};

