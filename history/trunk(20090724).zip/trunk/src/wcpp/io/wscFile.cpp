#include "wscFile.h"
#include <wcpp/lang/wscThrowable.h>
#include <wcpp/lang/wscString.h>


wscFile::wscFile(wsiFile * parent, wsiString * child)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


wscFile::wscFile(wsiString * pathname)
{
    if (pathname==WS_NULL) {
        WS_THROW( wseNullPointerException , "" );
    }
    Init( pathname->GetBuffer() , pathname->GetLength() );
}


wscFile::wscFile( wsiString * parent, wsiString * child)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


wscFile::wscFile(wsiURI * uri)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


void wscFile::Init(const ws_char * const aPathStrBuf, const ws_int aPathStrLen)
{
    WS_THROW( wseUnsupportedOperationException , "" );

    /*
    ws_str nameBuffer;
    for (ws_int i=0; i<aPathStrLen; i++) {
        const ws_char c = aPathStrBuf[i];
        if ((c=='\\') || (c=='/')) {
            nameBuffer;
        }
        else {
            nameBuffer += c;
        }
    }
    */
}


wscFile::~wscFile(void)
{
}




ws_boolean wscFile::_realCanExecute(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realCanRead(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realCanWrite(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_int     wscFile::_realCompareTo(wsiFile * pathname) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realCreateNewFile(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realDelete(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realDeleteOnExit(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realEquals(wsiObject * obj) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realExists(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetAbsoluteFile(wsiFile ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetAbsolutePath(wsiString ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetCanonicalFile(wsiFile ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetCanonicalPath(wsiString ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_long    wscFile::_realGetFreeSpace(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetName(wsiString ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetParent(wsiString ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetParentFile(wsiFile ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetPath(wsiString ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_long    wscFile::_realGetTotalSpace(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_long    wscFile::_realGetUsableSpace(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_int     wscFile::_realHashCode(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realIsAbsolute(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realIsDirectory(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realIsFile(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realIsHidden(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_long    wscFile::_realLastModified(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_long    wscFile::_realLength(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realList(wsiStringArray ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realList(wsiFilenameFilter * filter, wsiStringArray ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realListFiles(wsiFileArray ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realListFiles(wsiFileFilter * filter, wsiFileArray ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realListFiles(wsiFilenameFilter * filter, wsiFileArray ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realMkdir(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realMkdirs(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realRenameTo(wsiFile * dest) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetExecutable(ws_boolean executable) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetExecutable(ws_boolean executable, ws_boolean ownerOnly) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetLastModified(ws_long time) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetReadable(ws_boolean readable) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetReadable(ws_boolean readable, ws_boolean ownerOnly) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetReadOnly(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetWritable(ws_boolean writable) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetWritable(ws_boolean writable, ws_boolean ownerOnly) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realToString(wsiString ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realToURI(wsiURI ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }



