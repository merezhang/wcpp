#ifndef __wsiByteArrayInputStream_h__
#define __wsiByteArrayInputStream_h__

#include "wsiInputStream.h"


class wsiByteArrayInputStream : public wsiInputStream
{
public:
    static const ws_iid sIID;
};


#endif // __wsByteArrayInputStream_h__
