#ifndef __wsiReader_h__
#define __wsiReader_h__

#include <wcpp.lang/wsiObject.h>




class wsiReader : public wsiObject
{
public:
	static const ws_iid sIID;
};




#endif // __wsReader_h__
