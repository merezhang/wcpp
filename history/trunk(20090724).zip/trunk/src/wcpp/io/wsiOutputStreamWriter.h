#ifndef __wsiOutputStreamWriter_h__
#define __wsiOutputStreamWriter_h__

#include "wsiWriter.h"




class wsiOutputStreamWriter : public wsiWriter
{
public:
	static const ws_iid sIID;
};




#endif // __wsOutputStreamWriter_h__
