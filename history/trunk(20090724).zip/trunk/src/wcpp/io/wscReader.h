﻿#ifndef __wscReader_h__
#define __wscReader_h__

#include <wcpp/lang/wscObject.h>
#include "wsiReader.h"




class wscReader : public wscObject, public wsiReader
{
};




#endif // __wsReader_h__
