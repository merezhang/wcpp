﻿#ifndef __wscDataInputStream_h__
#define __wscDataInputStream_h__

#include "wscInputStream.h"
#include "wsiDataInputStream.h"




class wscDataInputStream : public wscInputStream, public wsiDataInputStream
{
};




#endif // __wsDataInputStream_h__
