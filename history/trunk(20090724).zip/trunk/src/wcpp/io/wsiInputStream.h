// wsiInputStream.h
#ifndef __wsiInputStream_h__
#define __wsiInputStream_h__

#include <wcpp/lang/wsiObject.h>


class wsiInputStream : public wsiObject
{
public:
    static const ws_iid sIID;

	virtual ws_int     Available     (void)                              = 0;
	virtual void       Close         (void)                              = 0;
	virtual void       Mark          (ws_int readlimit)                  = 0;
	virtual ws_boolean MarkSupported (void)                              = 0;
	virtual ws_int     Read          (void)                              = 0;	// abstract
	virtual ws_int     Read          (void* const buf, const ws_int len) = 0;
	virtual void       Reset         (void)                              = 0;
	virtual ws_long    Skip          (ws_long n)                         = 0;
};




#endif // __wsInputStream_h__
