// wscOutputStream.h
#ifndef __wscOutputStream_h__
#define __wscOutputStream_h__

#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/ws_implements.h>
#include "wsiOutputStream.h"


#define WS_IMPL_wsiOutputStream		\
	public:		\
	virtual void Close(void) {_realClose();}	\
	virtual void Flush(void) {_realFlush();}	\
	virtual void Write(const void* const buf, const ws_int len) {_realWrite(buf,len);}	\
	virtual void Write(ws_int b) {_realWrite(b);}	\
	

class wscOutputStream : public wscObject, public wsiOutputStream
{
	WS_IMPL_wsiObject
	WS_IMPL_wsiOutputStream

	WS_IMPL_GET_INTERFACE_BEGIN
		WS_IMPL_GET_INTERFACE_BODY( wsiOutputStream )
	WS_IMPL_GET_INTERFACE_END

public:
    typedef wscObject super_class;
public:
	wscOutputStream(void);
	~wscOutputStream(void);
protected:
	virtual void _realClose(void);
	virtual void _realFlush(void);
	virtual void _realWrite(const void* const buf, const ws_int len);
	virtual void _realWrite(ws_int b) = 0;
};


#endif // __wsOutputStream_h__
