#pragma once
#include "wsinumber.h"




class wsiShort : public wsiNumber
{
public:
	static const ws_iid sIID;
};



