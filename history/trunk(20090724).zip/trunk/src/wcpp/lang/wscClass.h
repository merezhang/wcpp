// wscClass.h
#ifndef __wscClass_h__
#define __wscClass_h__

#include "wscObject.h"
#include "wsiClass.h"
#include "wsiString.h"
#include "ws_implements.h"
#include "ws_ptr.h"




#define WS_IMPL_wsiClass		\
	public:		\
	virtual void GetName(wsiString ** rString) { _realGetName(rString); }	\




class wscClass : public wscObject, public wsiClass
{
public:
    typedef wscObject super_class;

	WS_IMPL_wsiObject
	WS_IMPL_wsiClass

    WS_IMPL_GET_INTERFACE_BEGIN
        WS_IMPL_GET_INTERFACE_BODY( wsiClass )
    WS_IMPL_GET_INTERFACE_END

    WS_IMPL_GET_CLASS( "wcpp.lang.wscClass" );

public:

	wscClass(const ws_char* const aName) : m_name(aName)
	{
	}

	~wscClass(void)
	{
	}

protected:

	virtual void _realGetName(wsiString ** rString);

private:

	const ws_char* const m_name;
};




#endif // __wscClass_h__
