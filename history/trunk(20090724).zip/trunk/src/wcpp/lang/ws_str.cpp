#include "ws_str.h"
#include "wscString.h"
#include "wscThrowable.h"




/*
**********************************************************************************************************************
*   ws_str
**********************************************************************************************************************
*/


ws_str::ws_str(void)
{
}


ws_str::ws_str(const ws_char * const src, ws_int len)
{
    if (src) {
        wsiString * pnew = WS_NULL;
        wscString::New( & pnew , src , len );
        Attach( pnew );
    }
}


ws_str::ws_str(const ws_char * const src)
{
    if (src) {
        wsiString * pnew = WS_NULL;
        wscString::New( & pnew , src );
        Attach( pnew );
    }
}


ws_str::ws_str(const ws_str & src)
{
    wsiString * ptr = WS_NULL;
    src.QueryInterface( & ptr );
    Attach( ptr );
}


ws_str::ws_str(wsiString * src)
{
    if (src) {
        src->AddRef();
        Attach( src );
    }
}


ws_str::~ws_str(void)
{
}


void ws_str::SetString(const ws_char * const buf, ws_int len)
{
    wsiString * pns = WS_NULL;
    wscString::New( & pns , buf , len );
    Attach( pns );
}


const ws_str & ws_str::operator =(const ws_str & src)
{
    wsiString * ps = WS_NULL;
    src.QueryInterface( &ps );
    Attach( ps );
    return (*this);
}


ws_str::operator const ws_char * const (void) const
{
    try {
        wsiString * pstr = WS_NULL;
        QueryInterface( & pstr );
        ws_ptr<wsiString> str( pstr );
        return str->GetBuffer();
    }
    catch (...) {
        return "";
    }
}




