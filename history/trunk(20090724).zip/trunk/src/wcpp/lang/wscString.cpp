// wscString.cpp
#include "wscString.h"
#include "_StringBuffer.h"
#include <wcpp/wspr/wspr.h>
#include "wsoLangService.h"
#include "ws_ptr.h"


void wscString::New(wsiString ** ret, const ws_char* const buf)
{
    New( ret, buf, wspr::ws_strlen(buf) );
}


void wscString::New(wsiString ** ret, const ws_char * const buf, ws_int len)
{
    wsiStringService * pss = WS_NULL;
    GetStringService( &pss );
    ws_ptr<wsiStringService> ss(pss);
    ss->AllocateString( ret, buf, len );
}


void wscString::GetStringService(wsiStringService ** ret)
{
    ws_ptr<wsiLangService> ls;
    wsoLangService::GetLangService( & ls );
    ls->GetStringService( ret );
}

