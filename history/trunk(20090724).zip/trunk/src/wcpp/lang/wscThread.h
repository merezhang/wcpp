#pragma once
#include "wscObject.h"
#include "wscRunnable.h"
#include "wsiThread.h"
#include "wscString.h"

#include <wcpp/lang/ws_ptr.h>
#include <wcpp/lang/ws_implements.h>
#include <wcpp/lang/ref/wsuSupportsWeakReference.h>



#define WS_IMPL_wsiThread		\
	public:		\
	virtual void       GetName(wsiString ** rName)		{ _realGetName(rName); }	\
	virtual ws_int     GetPriority(void)				{ return _realGetPriority(); }	\
	virtual void       Interrupt(void)					{ _realInterrupt(); }	\
	virtual ws_boolean IsAlive(void)					{ return _realIsAlive(); }	\
	virtual void       Join(void)						{ _realJoin(); }	\
	virtual void       SetPriority(ws_int newPriority)	{ _realSetPriority(newPriority); }	\
	virtual void       Start(void)						{ _realStart(); }	\


class wsiRunnableProxy : public wsiRunnable
{
public:
    static const ws_iid sIID;
public:
    virtual void Clear(void) = 0;
    virtual ws_boolean IsStarted(void) = 0;
    virtual ws_boolean IsStopped(void) = 0;
};


class wsiThreadService;


class wscThread : public wscObject, public wsiThread
{
	WS_IMPL_wsiObject
	WS_IMPL_wsiRunnable
	WS_IMPL_wsiThread

    WS_IMPL_GET_INTERFACE_BEGIN
        WS_IMPL_GET_INTERFACE_BODY( wsiThread )
        WS_IMPL_GET_INTERFACE_BODY( wsiRunnable )
    WS_IMPL_GET_INTERFACE_END

    WS_IMPL_GET_CLASS( "wcpp.lang.wscThread" )

public:
    typedef wscObject super_class;
public:

	wscThread(void);
	wscThread(wsiRunnable * target);
	wscThread(wsiRunnable * target, wsiString * name);
	wscThread(wsiString * name);

	~wscThread(void);

	static ws_int ActiveCount(void);
	static void   CurrentThread(wsiThread ** rThread);
	static void   Sleep(ws_long millis);
	static void   Yield(void);

protected:

	void       _realGetName(wsiString ** rName);
	ws_int     _realGetPriority(void);
	void       _realInterrupt(void);
	ws_boolean _realIsAlive(void);
	void       _realJoin(void);
	void       _realSetPriority(ws_int newPriority);
	void       _realStart(void);

	void       _realRun(void);

private:
    void Init(wsiString * name);
    static void GetThreadService(wsiThreadService ** ret);
private:
    ws_ptr<wsiThread>         m_impl;
    ws_ptr<wsiRunnable>       m_target;
    ws_ptr<wsiRunnableProxy>  m_proxy;
};

