#include "wscRuntimeService.h"


wscRuntimeService::wscRuntimeService(void)
{
}


wscRuntimeService::~wscRuntimeService(void)
{
}


void wscRuntimeService::GetRuntime(wsiRuntime ** ret)
{
    m_runtime.QueryInterface( ret );
}

