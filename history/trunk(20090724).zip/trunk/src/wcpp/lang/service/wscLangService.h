#ifndef __wscLangService_h__
#define __wscLangService_h__

#include <wcpp/lang/wsoLangService.h>
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/wscom/wscFactory.h>
#include <wcpp/lang/ws_implements.h>
#include <wcpp/lang/wscClass.h>


class wscLangService : public wscObject, public wsoLangService
{
    WS_IMPL_wsiObject

    WS_IMPL_GET_INTERFACE_BEGIN
        WS_IMPL_GET_INTERFACE_BODY( wsiLangService )
    WS_IMPL_GET_INTERFACE_END

    WS_IMPL_GET_CLASS( "wcpp.lang.service.wscLangService" )

public:
    typedef wscObject super_class;
public:
    wscLangService(void);
    ~wscLangService(void);
public:
    virtual void GetRuntimeService(wsiRuntimeService ** ret) ;
    virtual void GetSystemService(wsiSystemService ** ret) ;
    virtual void GetThreadService(wsiThreadService ** ret) ;
    virtual void GetStringService(wsiStringService ** ret) ;
private:
    ws_ptr<wsiRuntimeService> m_runtimes;
    ws_ptr<wsiSystemService>  m_systems;
    ws_ptr<wsiThreadService>  m_threads;
    ws_ptr<wsiStringService>  m_strings;
};


class wscLangServiceFactory : public wscFactory
{
    WS_IMPL_GET_CLASS( "wcpp.lang.service.wscLangServiceFactory" )
public:
    wscLangServiceFactory(void);
    ~wscLangServiceFactory(void);
    virtual void _realCreateInstance(wsiObject * aOuter, const ws_iid & aIID, void ** ret);
};


#endif // __wscLangService_h__
