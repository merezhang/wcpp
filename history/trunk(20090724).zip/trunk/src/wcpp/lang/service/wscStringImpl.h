#pragma once

#include <wcpp/lang/wscString.h>




class wscStringImpl : public wscObject , public wsiStringRW
{
	WS_IMPL_wsiObject
    WS_IMPL_wsiString
    WS_IMPL_wsiStringRW

    WS_IMPL_GET_INTERFACE_BEGIN
        WS_IMPL_GET_INTERFACE_BODY( wsiString )
    WS_IMPL_GET_INTERFACE_END

    WS_IMPL_GET_CLASS( "wcpp.lang.service.wscStringImpl" )

public:

    typedef wscObject super_class;

private:

    struct _data_block
    {
        ws_byte * pbytes;
        ws_int    sz;
        ws_int    len;
        ws_char   dat[8];
    };

    _data_block * m_pdb;

    wscStringImpl(ws_int size);
    ~wscStringImpl(void);

public:

    static void New(wsiStringRW ** ret , ws_int size);

protected:

    virtual void _RecycleObject(void);

protected:

    virtual ws_char     _realCharAt(ws_int index) const                                                      ;
    virtual ws_int      _realCodePointAt(ws_int index) const                                                 ;
    virtual ws_int      _realCodePointBefore(ws_int index) const                                             ;
    virtual ws_int      _realCodePointCount(ws_int beginIndex, ws_int endIndex) const                        ;
    virtual ws_int      _realCompareTo(wsiString * anotherString) const                                      ;
    virtual ws_int      _realCompareToIgnoreCase(wsiString * str) const                                      ;
    virtual void        _realConcat(wsiString * str, wsiString ** ret) const                                 ;
    virtual ws_boolean  _realContains(wsiCharSequence * s) const                                             ;
    virtual ws_boolean  _realContentEquals(wsiCharSequence * cs) const                                       ;
    virtual ws_boolean  _realContentEquals(wsiStringBuffer * sb) const                                       ;
    virtual ws_boolean  _realEndsWith(wsiString * suffix) const                                              ;
    virtual ws_boolean  _realEquals(wsiObject * anObject) const                                              ;
    virtual ws_boolean  _realEqualsIgnoreCase(wsiString * anotherString) const                               ;
    virtual void        _realGetBytes(wsiByteArray ** ret) const                                             ;
    virtual void        _realGetBytes(wsiCharset * charset, wsiByteArray ** ret) const                       ;
    virtual void        _realGetBytes(wsiString * charsetName, wsiByteArray ** ret) const                    ;
    virtual void        _realGetChars(ws_int srcBegin, ws_int srcEnd, ws_char * dst, ws_int dstSize) const   ;
    virtual ws_int      _realHashCode(void) const                                                            ;
    virtual ws_int      _realIndexOf(ws_int ch) const                                                        ;
    virtual ws_int      _realIndexOf(ws_int ch, ws_int fromIndex) const                                      ;
    virtual ws_int      _realIndexOf(wsiString * str) const                                                  ;
    virtual ws_int      _realIndexOf(wsiString * str, ws_int fromIndex) const                                ;
    virtual void        _realIntern(wsiString ** ret) const                                                  ;
    virtual ws_boolean  _realIsEmpty(void) const                                                             ;
    virtual ws_int      _realLastIndexOf(ws_int ch) const                                                    ;
    virtual ws_int      _realLastIndexOf(ws_int ch, ws_int fromIndex) const                                  ;
    virtual ws_int      _realLastIndexOf(wsiString * str) const                                              ;
    virtual ws_int      _realLastIndexOf(wsiString * str, ws_int fromIndex) const                            ;
    virtual ws_int      _realLength(void) const                                                              ;
    virtual ws_boolean  _realMatches(wsiString * regex) const                                                ;
    virtual ws_int      _realOffsetByCodePoints(ws_int index, ws_int codePointOffset) const                  ;
    virtual ws_boolean  _realRegionMatches(ws_boolean ignoreCase, ws_int toffset, wsiString * other, ws_int ooffset, ws_int len) const ;
    virtual ws_boolean  _realRegionMatches(ws_int toffset, wsiString * other, ws_int ooffset, ws_int len) const          ;
    virtual void        _realReplace(ws_char oldChar, ws_char newChar, wsiString ** ret) const                           ;
    virtual void        _realReplace(wsiCharSequence * target, wsiCharSequence * replacement, wsiString ** ret) const    ;
    virtual void        _realReplaceAll(wsiString * regex, wsiString * replacement, wsiString ** ret) const              ;
    virtual void        _realReplaceFirst(wsiString * regex, wsiString * replacement, wsiString ** ret) const            ;
    virtual void        _realSplit(wsiString * regex, wsiStringArray ** ret) const                                       ;
    virtual void        _realSplit(wsiString * regex, ws_int limit, wsiStringArray ** ret) const                         ;
    virtual ws_boolean  _realStartsWith(wsiString * prefix) const                                            ;
    virtual ws_boolean  _realStartsWith(wsiString * prefix, ws_int toffset) const                            ;
    virtual void        _realSubSequence(ws_int beginIndex, ws_int endIndex, wsiCharSequence ** ret) const   ;
    virtual void        _realSubstring(ws_int beginIndex, wsiString ** ret) const                            ;
    virtual void        _realSubstring(ws_int beginIndex, ws_int endIndex, wsiString ** ret) const           ;
    virtual void        _realToCharArray(wsiCharArray ** ret) const                                          ;
    virtual void        _realToLowerCase(wsiString ** ret) const                                             ;
    virtual void        _realToLowerCase(wsiLocale * locale, wsiString ** ret) const                         ;
    virtual void        _realToString(wsiString ** ret) const                                                ;
    virtual void        _realToUpperCase(wsiString ** ret) const                                             ;
    virtual void        _realToUpperCase(wsiLocale * locale, wsiString ** ret) const                         ;
    virtual void        _realTrim(wsiString ** ret) const                                                    ;

protected:

    virtual const ws_char * const   _realGetBuffer(void) const;
    virtual ws_int                  _realGetLength(void) const;

protected:

    virtual ws_char* _realGetBufferRW(void);
    virtual ws_int   _realGetBufferSize(void) const;
    virtual ws_int   _realSetLength(ws_int newLength);
    virtual ws_int   _realSetString(const ws_char * const buf, ws_int newLength);
};



