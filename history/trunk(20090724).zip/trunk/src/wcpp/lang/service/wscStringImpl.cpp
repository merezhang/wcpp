#include "wscStringImpl.h"
#include <wcpp/lang/wscThrowable.h>


void wscStringImpl::New(wsiStringRW ** ret , ws_int size)
{
    ws_ptr<wsiStringRW> pnew( new wscStringImpl( size ) );
    pnew.QueryInterface( ret );
}


wscStringImpl::wscStringImpl(ws_int size) : m_pdb(WS_NULL)
{
    ws_byte * pb = new ws_byte[ sizeof(_data_block) + size ];
    if (pb == WS_NULL) {
    }
    else {
        _data_block * pdb = (_data_block *) pb;
        pdb->dat[0] = 0;
        pdb->len    = 0;
        pdb->pbytes = pb;
        pdb->sz     = size;
        m_pdb = pdb;
    }
}


wscStringImpl::~wscStringImpl(void)
{
    _data_block * pdb = m_pdb;
    m_pdb = WS_NULL;
    if (pdb) {
        ws_byte * pb = ((ws_byte*)pdb);
        ws_boolean ex = (pb != pdb->pbytes);
        delete []pb;
        if (ex) {
            WS_THROW(  wseError , "wscStringImpl::~wscStringImpl() {pb != pdb->pbytes}" );
        }
    }
}


void wscStringImpl::_RecycleObject(void)
{
//    WS_THROW( wseUnsupportedOperationException , "" );

    try {
        ws_ptr<wsiStringService> ss;
        wscString::GetStringService( &ss );
        ss->RecycleStringRW( this );
    }
    catch (...) {
        delete this;
    }
}




ws_char     wscStringImpl::_realCharAt(ws_int index) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realCodePointAt(ws_int index) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realCodePointBefore(ws_int index) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realCodePointCount(ws_int beginIndex, ws_int endIndex) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realCompareTo(wsiString * anotherString) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realCompareToIgnoreCase(wsiString * str) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realConcat(wsiString * str, wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realContains(wsiCharSequence * s) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realContentEquals(wsiCharSequence * cs) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realContentEquals(wsiStringBuffer * sb) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realEndsWith(wsiString * suffix) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realEquals(wsiObject * anObject) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realEqualsIgnoreCase(wsiString * anotherString) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realGetBytes(wsiByteArray ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realGetBytes(wsiCharset * charset, wsiByteArray ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realGetBytes(wsiString * charsetName, wsiByteArray ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realGetChars(ws_int srcBegin, ws_int srcEnd, ws_char * dst, ws_int dstSize) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realHashCode(void) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realIndexOf(ws_int ch) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realIndexOf(ws_int ch, ws_int fromIndex) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realIndexOf(wsiString * str) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realIndexOf(wsiString * str, ws_int fromIndex) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realIntern(wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realIsEmpty(void) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realLastIndexOf(ws_int ch) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realLastIndexOf(ws_int ch, ws_int fromIndex) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realLastIndexOf(wsiString * str) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realLastIndexOf(wsiString * str, ws_int fromIndex) const 
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realLength(void) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realMatches(wsiString * regex) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int      wscStringImpl::_realOffsetByCodePoints(ws_int index, ws_int codePointOffset) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realRegionMatches(ws_boolean ignoreCase, ws_int toffset, wsiString * other, ws_int ooffset, ws_int len) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realRegionMatches(ws_int toffset, wsiString * other, ws_int ooffset, ws_int len) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realReplace(ws_char oldChar, ws_char newChar, wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realReplace(wsiCharSequence * target, wsiCharSequence * replacement, wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realReplaceAll(wsiString * regex, wsiString * replacement, wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realReplaceFirst(wsiString * regex, wsiString * replacement, wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realSplit(wsiString * regex, wsiStringArray ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realSplit(wsiString * regex, ws_int limit, wsiStringArray ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realStartsWith(wsiString * prefix) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_boolean  wscStringImpl::_realStartsWith(wsiString * prefix, ws_int toffset) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realSubSequence(ws_int beginIndex, ws_int endIndex, wsiCharSequence ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realSubstring(ws_int beginIndex, wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realSubstring(ws_int beginIndex, ws_int endIndex, wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realToCharArray(wsiCharArray ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realToLowerCase(wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realToLowerCase(wsiLocale * locale, wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realToString(wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realToUpperCase(wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realToUpperCase(wsiLocale * locale, wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }


void        wscStringImpl::_realTrim(wsiString ** ret) const
{ WS_THROW(wseUnsupportedOperationException,"") }








const ws_char * const   wscStringImpl::_realGetBuffer(void) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int                  wscStringImpl::_realGetLength(void) const
{ WS_THROW(wseUnsupportedOperationException,"") }








ws_char* wscStringImpl::_realGetBufferRW(void)
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int   wscStringImpl::_realGetBufferSize(void) const
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int   wscStringImpl::_realSetLength(ws_int newLength)
{ WS_THROW(wseUnsupportedOperationException,"") }


ws_int   wscStringImpl::_realSetString(const ws_char * const buf, ws_int newLength)
{ WS_THROW(wseUnsupportedOperationException,"") }








