#pragma once

#include <wcpp/lang/wsiLangService.h>
#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/ws_implements.h>
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/lang/wscClass.h>
#include <wcpp/lang/wscString.h>



class wscStringService : public wscObject , public wsiStringService
{
    WS_IMPL_wsiObject

    WS_IMPL_GET_CLASS( "wcpp.lang.service.wscStringService" )

public:
    wscStringService(void);
    ~wscStringService(void);
public:
    virtual void AllocateString( wsiString ** ret, const ws_char * const buf, ws_int len );
    virtual void AllocateStringRW( wsiStringRW ** ret, ws_int size, const ws_char * const buf, ws_int len );
    virtual void RecycleStringRW( wsiStringRW * obj );
};



