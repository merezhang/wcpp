#pragma once

#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/wsiThread.h>
#include <wcpp/lang/ref/ws_weakref.h>
#include <wcpp/lang/wscString.h>
#include <wcpp/lang/ws_str.h>
#include <wcpp/wspr/ws_thread.h>


class wscThreadImpl : public wscObject, public wsiThread, public ws_runnable
{
    WS_IMPL_wsiObject
    WS_IMPL_GET_CLASS( "wcpp.lang.service.wscThreadImpl" )
public:
    wscThreadImpl(wsiRunnable * target, wsiString * name);
    ~wscThreadImpl(void);
private:
    virtual void       GetName(wsiString ** rName);
	virtual ws_int     GetPriority(void);
	virtual void       Interrupt(void);
	virtual ws_boolean IsAlive(void);
	virtual void       Join(void);
	virtual void       Run(void);
	virtual void       SetPriority(ws_int newPriority);
	virtual void       Start(void);
//	virtual void       ToString(wsiString ** rString);

    virtual void ThreadProc(void);

private:
    ws_ptr<wsiRunnable> m_target;
    ws_str m_name;
    ws_thread * m_thread;
};

