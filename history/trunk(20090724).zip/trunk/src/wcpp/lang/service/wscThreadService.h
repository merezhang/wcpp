#pragma once

#include <wcpp/lang/wsiLangService.h>
#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/wscString.h>


class wscThreadService : public wscObject, public wsiThreadService
{
    WS_IMPL_wsiObject
    WS_IMPL_GET_CLASS( "wcpp.lang.service.wscThreadService" )
public:
    wscThreadService(void);
    ~wscThreadService(void);
private:
    virtual void NewThread(wsiRunnable * target, wsiString * name, wsiThread ** ret);
    virtual void Sleep(ws_long millis);
};

