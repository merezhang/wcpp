#include "wscSystemService.h"
#include <wcpp/io/wscPrintStream.h>
#include <wcpp/io/wscInputStream.h>
#include <wcpp/lang/wscThrowable.h>


wscSystemService::wscSystemService(void)
{
    ws_ptr<wsiInputStream> is( new wscInputStream() );
    m_in = is;
    ws_ptr<wsiPrintStream> ps( new wscPrintStream(WS_NULL) );
    m_err = ps;
    m_out = ps;
}


wscSystemService::~wscSystemService(void)
{
}


void wscSystemService::GetErr(wsiPrintStream ** ret)
{
    m_err.QueryInterface( ret );
}


void wscSystemService::GetIn(wsiInputStream ** ret)
{
    m_in.QueryInterface( ret );
}


void wscSystemService::GetOut(wsiPrintStream ** ret)
{
    m_out.QueryInterface( ret );
}


void wscSystemService::SetErr(wsiPrintStream * aPS)
{
    if (aPS==WS_NULL) {
        WS_THROW( wseNullPointerException , "wscSystemService::SetErr must set a non-null wsiPrintStream." );
    }
    m_err = aPS;
}


void wscSystemService::SetIn(wsiInputStream * aIS)
{
    if (aIS==WS_NULL) {
        WS_THROW( wseNullPointerException , "wscSystemService::SetIn must set a non-null wsiInputStream." );
    }
    m_in = aIS;
}


void wscSystemService::SetOut(wsiPrintStream * aPS)
{
    if (aPS==WS_NULL) {
        WS_THROW( wseNullPointerException , "wscSystemService::SetOut must set a non-null wsiPrintStream." );
    }
    m_out = aPS;
}

