#pragma once

#include <wcpp/lang/wsiLangService.h>
#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/lang/wsiRuntime.h>
#include <wcpp/lang/wscString.h>


class wscRuntimeService : public wscObject, public wsiRuntimeService
{
    WS_IMPL_wsiObject

    WS_IMPL_GET_CLASS( "wcpp.lang.service.wscRuntimeService" )

public:
    wscRuntimeService(void);
    ~wscRuntimeService(void);
private:
    virtual void GetRuntime(wsiRuntime ** ret);
private:
    ws_ptr<wsiRuntime> m_runtime;
};

