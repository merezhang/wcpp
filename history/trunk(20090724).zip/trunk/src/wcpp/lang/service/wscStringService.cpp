#include "wscStringService.h"
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/lang/wscThrowable.h>
#include "wscStringImpl.h"



wscStringService::wscStringService(void)
{
}


wscStringService::~wscStringService(void)
{
}




void wscStringService::AllocateString( wsiString ** ret, const ws_char * const buf, ws_int len )
{
    ws_ptr<wsiStringRW> strRW;
    AllocateStringRW( &strRW, len+8, buf, len );
    ws_ptr<wsiString> str;
    str.Attach( strRW.Detach() );
    str.QueryInterface( ret );
}


void wscStringService::AllocateStringRW( wsiStringRW ** ret, ws_int size, const ws_char * const buf, ws_int len )
{
    if (len > size) {
        WS_THROW( wseStringIndexOutOfBoundsException , "string length larger than buffer size." );
    }

    ws_ptr<wsiStringRW> str;
    wscStringImpl::New( &str , size );
    str.QueryInterface( ret );
    str->SetString( buf, len );
}


void wscStringService::RecycleStringRW( wsiStringRW * obj )
{
    delete obj;
}

