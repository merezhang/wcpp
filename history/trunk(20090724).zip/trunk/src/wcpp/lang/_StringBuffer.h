#pragma once

#include <wcpp/wspr/ws_type.h>


struct _StringBuffer
{

	const ws_int     SetString(const ws_char* const buf, const ws_int cb);

	static _StringBuffer * New(const ws_int aStrLen);
	static void Delete(_StringBuffer * psbuf);

	ws_int   GetLength(void) {return m_len;}
	ws_char* GetBuffer(void) {return m_buf;}
	ws_int   GetCapability(void) {return m_cap;}

private:

	_StringBuffer(void);
	~_StringBuffer(void);

	ws_int      m_cap;
	ws_int      m_len;
	ws_char     m_buf[2];

};

