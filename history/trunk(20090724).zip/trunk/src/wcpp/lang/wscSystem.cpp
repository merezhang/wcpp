// wscSystem.cpp
#include "wscSystem.h"
#include "wsoLangService.h"
#include <wcpp/lang/ws_ptr.h>


void wscSystem::GetSystemService(wsiSystemService ** ret)
{
    wsiLangService * pls = WS_NULL;
    wsoLangService::GetLangService( &pls );
    ws_ptr<wsiLangService> ls(pls);
    ls->GetSystemService(ret);
}


void wscSystem::GetErr(wsiPrintStream ** ret)
{
    wsiSystemService * pss = WS_NULL;
    GetSystemService( &pss );
    ws_ptr<wsiSystemService> ss(pss);
    ss->GetErr(ret);
}


void wscSystem::GetOut(wsiPrintStream ** ret)
{
    wsiSystemService * pss = WS_NULL;
    GetSystemService( &pss );
    ws_ptr<wsiSystemService> ss(pss);
    ss->GetOut(ret);
}


void wscSystem::GetIn(wsiInputStream ** ret)
{
    wsiSystemService * pss = WS_NULL;
    GetSystemService( &pss );
    ws_ptr<wsiSystemService> ss(pss);
    ss->GetIn(ret);
}


void wscSystem::SetErr(wsiPrintStream *aPrintStream)
{
    wsiSystemService * pss = WS_NULL;
    GetSystemService( &pss );
    ws_ptr<wsiSystemService> ss(pss);
    ss->SetErr( aPrintStream );
}


void wscSystem::SetIn(wsiInputStream *aInputStream)
{
    wsiSystemService * pss = WS_NULL;
    GetSystemService( &pss );
    ws_ptr<wsiSystemService> ss(pss);
    ss->SetIn( aInputStream );
}


void wscSystem::SetOut(wsiPrintStream *aPrintStream)
{
    wsiSystemService * pss = WS_NULL;
    GetSystemService( &pss );
    ws_ptr<wsiSystemService> ss(pss);
    ss->SetOut( aPrintStream );
}

