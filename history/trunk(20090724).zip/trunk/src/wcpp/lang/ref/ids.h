// <wcpp.lang.ref/ids.h>


#include "wsiSupportsWeakReference.h"


WS_IMPL_IID_OF( wsiSupportsWeakReference )

