#include "wscWeakReference.h"



wscWeakReference::wscWeakReference(wsiSupportsWeakReference * obj) : m_ptr(obj)
{
}


wscWeakReference::~wscWeakReference(void)
{
	m_ptr = WS_NULL;
}



	
void wscWeakReference::Clear(void)
{
	m_ptr = WS_NULL;
}


void wscWeakReference::Get(const ws_iid & aIID, void ** ret)
{
	if (m_ptr) {
		m_ptr->QueryInterface(aIID,ret);
	} else {
		(*ret) = WS_NULL;
	}
}



