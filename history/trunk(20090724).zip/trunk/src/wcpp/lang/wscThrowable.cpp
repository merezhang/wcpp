// wscThrowable.cpp

#include "wscThrowable.h"
#include "ws_str.h"


const ws_char* const wscThrowable::sSTR = "wcpp.lang.wscThrowable";
const ws_char* const wseError::sSTR     = "wcpp.lang.wseError";
const ws_char* const wseException::sSTR = "wcpp.lang.wseException";

const ws_char* const wseRuntimeException::sSTR                = "wcpp.lang.wseRuntimeException";
const ws_char* const wseNullPointerException::sSTR            = "wcpp.lang.wseNullPointerException";
const ws_char* const wseClassCastException::sSTR              = "wcpp.lang.wseClassCastException";
const ws_char* const wseUnsupportedOperationException::sSTR   = "wcpp.lang.wseUnsupportedOperationException";
const ws_char* const wseIllegalThreadStateException::sSTR     = "wcpp.lang.wseIllegalThreadStateException";
const ws_char* const wseClassNotFoundException::sSTR          = "wcpp.lang.wseClassNotFoundException";
const ws_char* const wseNumberFormatException::sSTR           = "wcpp.lang.wseNumberFormatException";
const ws_char* const wseIllegalArgumentException::sSTR        = "wcpp.lang.wseIllegalArgumentException";
const ws_char* const wseIllegalStateException::sSTR           = "wcpp.lang.wseIllegalStateException";
const ws_char* const wseStringIndexOutOfBoundsException::sSTR = "wcpp.lang.wseStringIndexOutOfBoundsException";
const ws_char* const wseIndexOutOfBoundsException::sSTR       = "wcpp.lang.wseIndexOutOfBoundsException";




wscThrowable::wscThrowable(const ws_char * const aStr, const ws_char * const aMsg, const ws_char* const aFileName, ws_int aLine)
:   m_string (aStr),
    m_msg    (aMsg),
    m_file   (aFileName),
    m_line   (aLine)
{
}


wscThrowable::~wscThrowable(void)
{
}


void wscThrowable::_realGetMessage(wsiString ** rString)
{
    ws_str str( m_msg );
    str.QueryInterface( rString );
}


void wscThrowable::_realPrintStackTrace(void)
{
}


void wscThrowable::_realToString(wsiString ** rString)
{
    ws_str str( m_string );
    str.QueryInterface( rString );
}

