// wscClass.cpp
#include "wscClass.h"
#include "ws_str.h"


void wscClass::_realGetName(wsiString ** rString)
{
    ws_str str( m_name );
    str.QueryInterface( rString );
}

