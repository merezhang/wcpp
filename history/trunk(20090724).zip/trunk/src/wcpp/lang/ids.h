// <wcpp.lang/ids.h>

#include "wsiObject.h"
#include "wsiSystem.h"
#include "wsiString.h"
#include "wsiClass.h"
#include "wsiThread.h"
#include "wsiRunnable.h"
#include "wsiLangService.h"
#include "wsoLangService.h"


WS_IMPL_IID_OF( wsiObject )
WS_IMPL_IID_OF( wsiClass )
WS_IMPL_IID_OF( wsiSystem )
WS_IMPL_IID_OF( wsiString )
WS_IMPL_IID_OF( wsiThread )
WS_IMPL_IID_OF( wsiRunnable )
WS_IMPL_IID_OF( wsiLangService )


WS_IMPL_CID_OF( wsoLangService )

