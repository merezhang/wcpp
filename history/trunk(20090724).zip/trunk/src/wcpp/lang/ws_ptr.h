// ws_ptr.h

#ifndef __ws_ptr_h__
#define __ws_ptr_h__

#include <wcpp/wspr/ws_type.h>
#include <wcpp/wspr/ws_id.h>




class wsiInterface;
class wsiString;




template <typename T>
class _ws_ptr_T_noAddRelease : public T
{
private:
	virtual ws_int AddRef(void) = 0;
	virtual ws_int Release(void) = 0;
};




class _ws_ptr_func
{
public:
    enum eid_x {
        eidNullPointer ,
        eidUnsupportedOperation ,
        eidIllegalStateException ,
    };
    static void Throw( ws_int eid, const ws_char * const msg , const ws_char * const filename , ws_int linenum );
};




template<typename T>
class ws_ptr_base
{
public:

    enum WS_CLSCTX_x {
        WS_CLSCTX_ALL ,
    };

private:

    T * p;

protected:

    ws_ptr_base(void) : p(WS_NULL)
    {
    }

    ~ws_ptr_base(void) throw()
    {
        try {
            Release();
        }
        catch (...) {
        //    throw;
        }
    }

public:             // operators

    operator T* (void) const
    {
        return p;
    }

    ws_boolean operator < (T * pT) const
    {
        return ( p < pT );
    }

    ws_boolean operator ! (void) const
    {
        return ( p == WS_NULL );
    }

    T ** operator & (void)
    {
        Release();
        return (&p) ;
    }

    T & operator * (void) const
    {
        return (*p);
    }

    _ws_ptr_T_noAddRelease<T> * operator -> (void) const
    {
        _ws_ptr_T_noAddRelease<T> * ret = (_ws_ptr_T_noAddRelease<T> *) p;
        if (ret==WS_NULL) {
            _ws_ptr_func::Throw(
                _ws_ptr_func::eidNullPointer ,
                "" ,
                __FILE__ ,
                __LINE__ );
            return WS_NULL;
        }
        else {
            return ret;
        }
    }

    ws_boolean operator == (T * pT) const
    {
        return (p == pT);
    }

public:

    void Advise(wsiInterface* pObj, const ws_iid & iid, ws_uint32 & dw)
    {
        _ws_ptr_func::Throw(
            _ws_ptr_func::eidUnsupportedOperation,
            "no implements the ws_ptr_base<T>::Advise",
            __FILE__ ,
            __LINE__ );
    }

    void Attach(T * p2)
    {
        Release();
        p = p2;
    }

    void CoCreateInstance(wsiString * aContractID, wsiInterface * aOuter = WS_NULL, ws_uint32 dwClsContext = WS_CLSCTX_ALL)
    {
        _ws_ptr_func::Throw(
            _ws_ptr_func::eidUnsupportedOperation,
            "no implements the ws_ptr_base<T>::Advise",
            __FILE__ ,
            __LINE__ );
    }

    void CoCreateInstance(const ws_cid & aClass, wsiInterface * aOuter = WS_NULL, ws_uint32 dwClsContext = WS_CLSCTX_ALL)
    {
        _ws_ptr_func::Throw(
            _ws_ptr_func::eidUnsupportedOperation,
            "no implements the ws_ptr_base<T>::Advise",
            __FILE__ ,
            __LINE__ );
    }

    void CopyTo(T ** ret)
    {
        if (ret==WS_NULL) {
            _ws_ptr_func::Throw(
                _ws_ptr_func::eidNullPointer,
                "no implements the ws_ptr_base<T>::Advise",
                __FILE__ ,
                __LINE__ );
        }
        else {
            T * p2 = p;
            if (p2) p2->AddRef();
            (*ret) = p2;
        }
    }

    T * Detach(void)
    {
        T * p2 = p;
        p = WS_NULL;
        return p2;
    }

    ws_boolean IsEqualObject(wsiInterface * other)
    {
        _ws_ptr_func::Throw(
            _ws_ptr_func::eidUnsupportedOperation,
            "no implements the ws_ptr_base<T>::Advise",
            __FILE__ ,
            __LINE__ );
    }

    template<typename Q>
    void QueryInterface(Q ** pp) const
    {
        if (pp==WS_NULL) {
            _ws_ptr_func::Throw(
                _ws_ptr_func::eidNullPointer, 
                "",
                __FILE__ ,
                __LINE__ );
        }
        else {
            T * p2 = p;
            if (p2) {
                p2->QueryInterface( Q::sIID , (void**) pp );
            }
            else {
                (*pp) = WS_NULL;
            }
        }
    }

    void QueryInterface(T ** pp) const
    {
        if (pp==WS_NULL) {
            _ws_ptr_func::Throw(
                _ws_ptr_func::eidNullPointer, 
                "",
                __FILE__ ,
                __LINE__ );
        }
        else {
            T * p2 = p;
            if (p2) p2->AddRef();
            (*pp) = p2;
        }
    }

    void Release(void) 
    {
        T * p2 = p;
        p = WS_NULL;
        if (p2) p2->Release();
    }

    void SetSite(wsiInterface * parent)
    {
        _ws_ptr_func::Throw(
            _ws_ptr_func::eidUnsupportedOperation,
            "no implements the ws_ptr_base<T>::Advise",
            __FILE__ ,
            __LINE__ );
    }

};




template <typename T>
class ws_ptr : public ws_ptr_base<T>
{
public:

    ws_ptr(void)
    {
    }

    ws_ptr(T* lp)
    {
        if (lp) lp->AddRef();
        Attach( lp );
    }

    ws_ptr(const ws_ptr & lp)
    {
        T * ptr = WS_NULL;
        lp.QueryInterface( & ptr );
        Attach( ptr );
    }

public:

    T* operator =(T* lp)
    {
        if (lp) lp->AddRef();
        Attach( lp );
        return lp;
    }

    T* operator =(const ws_ptr & lp)
    {
        T * ptr = WS_NULL;
        lp.QueryInterface( &ptr );
        Attach( ptr );
        return ptr;
    }

public:

    static const ws_iid & GetIID(void)
    {
        return T::sIID;
    }

};




#endif // __ws_ptr_h__
