#pragma once
#include "wsinumber.h"



class wsiInteger : public wsiNumber
{
public:
	wsiInteger(void);
public:
	~wsiInteger(void);
};



