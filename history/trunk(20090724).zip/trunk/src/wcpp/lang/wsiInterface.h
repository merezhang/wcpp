// wsiInterface.h

#ifndef __wsiInterface_h__
#define __wsiInterface_h__

#include <wcpp/wspr/ws_type.h>
#include <wcpp/wspr/ws_id.h>




class wsiInterface
{
public:

	virtual ~wsiInterface(void) {}

	virtual ws_int  AddRef(void) = 0;
	virtual void    QueryInterface(const ws_iid & iid, void ** ret) = 0;
	virtual ws_int  Release(void) = 0;

};




#endif // __wsiInterface_h__
