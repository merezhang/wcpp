/* 
 * File:   wsolangservice.h
 * Author: Xukun
 *
 * Created on 2009��7��17��, ����2:09
 */

#ifndef _WSOLANGSERVICE_H
#define	_WSOLANGSERVICE_H

#include "wsiLangService.h"


#define WS_CID_OF_wsoLangService        \
    { 0x73f14971, 0xa37a, 0x4d9c, { 0xa3, 0xab, 0x88, 0x81, 0x69, 0xd2, 0x3a, 0x51 } }
// {73F14971-A37A-4d9c-A3AB-888169D23A51}


class wsoLangService : public wsiLangService
{
public:
    static const ws_cid sCID;
    static void GetLangService(wsiLangService ** ret);
private:
};


#endif	/* _WSOLANGSERVICE_H */
