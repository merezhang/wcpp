// wscObject.cpp
#include "wscObject.h"

#include "wscThrowable.h"
#include "wscClass.h"
#include <wcpp/lang/ws_ptr.h>




ws_int wscObject::s_objcnt = 0;
wsuMutex wscObject::s_mutexForObjcnt;
wsuMutex wscObject::s_mutexForRefcnt;



wscObject::wscObject(void) : m_refcnt(0)
{
	s_mutexForObjcnt.Lock();
	s_objcnt ++ ;
	s_mutexForObjcnt.Unlock();
}


wscObject::~wscObject(void)
{
	s_mutexForObjcnt.Lock();
	s_objcnt -- ;
	s_mutexForObjcnt.Unlock();
}




ws_int wscObject::_realAddRef(void)
{
	s_mutexForRefcnt.Lock();
	ws_int ret = (++m_refcnt);
	s_mutexForRefcnt.Unlock();
	return ret;
}


ws_int wscObject::_realRelease(void)
{
	s_mutexForRefcnt.Lock();
	ws_int ret = (--m_refcnt);
	s_mutexForRefcnt.Unlock();
	if (ret==0) {
		_RecycleObject();
	}
	return ret;
}


void wscObject::_realQueryInterface(const ws_iid & aIID, void** ret)
{
    if (ret==WS_NULL) {
		WS_THROW( wseNullPointerException , "Query interface with a null ptr." );
    }
	wsiInterface* pnew = WS_NULL;
	wsiInterface* pold = static_cast<wsiInterface*>(*ret);
	pnew = _getInterfaceByIID( aIID );
    if (pnew==WS_NULL) {
        WS_THROW( wseClassCastException, "Query a un-implemnets interface." );
    }
    else {
		pnew->AddRef();
    }
	if (pold) pold->Release();
	(*ret) = pnew;
}


void wscObject::_RecycleObject(void)
{
    delete this;
}


wsiInterface * wscObject::_getRootInterface(void)
{
	return this;
}


wsiInterface * wscObject::_getInterfaceByIID(const ws_iid & aIID)
{
	wsiInterface * ret = WS_NULL;
	if (aIID == wsiObject::sIID)	{	ret = dynamic_cast<wsiObject*>(this);	}
	return ret;
}


ws_int wscObject::_realHashCode(void)
{
	void* p = this;
	void** pp = &p;
	return ((ws_int*)pp)[0];
}


ws_boolean wscObject::_realEquals(wsiObject * obj)
{
	const void* p1 = this;
	const void* p2 = obj;
	return (p1==p2);
}


void wscObject::_realGetClass(wsiClass ** rClass)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


void wscObject::_realToString(wsiString ** rString)
{
    wsiClass * pcls = WS_NULL;
    GetClass( & pcls );
    ws_ptr<wsiClass> ptr(pcls);
	ptr->GetName( rString );
}



