#pragma once

#include "wsiObject.h"


template <typename T>
class wsiArray_for_Object : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    virtual ws_long GetSize(void) = 0;
    virtual void    GetItem(ws_long index, T ** ret) = 0;
    virtual void    SetItem(ws_long index, T * item) = 0;
};


template <typename T>
class wsiArray_for_Value : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    virtual ws_long GetSize(void) = 0;
    virtual T    GetItem(ws_long index) = 0;
    virtual void SetItem(ws_long index, T value) = 0;
};

