#include "_StringBuffer.h"

#include <memory.h>




const ws_int _StringBuffer::SetString(const ws_char* const buf, const ws_int cb)
{
	const ws_int len = ((cb < m_cap) ? cb : m_cap);
	if (len>0) {
		memcpy( m_buf, buf, len );
		m_buf[len] = 0;
		m_len = len;
	}
	else {
		m_buf[0] = 0;
		m_len = 0;
	}
	return m_len;
}


_StringBuffer * _StringBuffer::New(const ws_int aStrLen)
{
	const ws_int rLen = ((aStrLen > 0) ? aStrLen : 0);
	ws_uint8 * pbytes = new ws_uint8[ sizeof(_StringBuffer) + rLen ];
	_StringBuffer * ret = ((_StringBuffer *)pbytes);
	if (ret) {
		ret->m_buf[0] = 0;
		ret->m_cap = rLen;
		ret->m_len = 0;
	}
	return ret;
}


void _StringBuffer::Delete(_StringBuffer * psbuf)
{
	ws_uint8 * pbytes =(ws_uint8 *) psbuf;
	delete []pbytes;
}

