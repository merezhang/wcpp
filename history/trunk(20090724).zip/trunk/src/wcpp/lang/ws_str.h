#pragma once

#include "ws_ptr.h"
#include "wsiString.h"


class ws_str : public ws_ptr<wsiString>
{
public:

    ws_str(void);
    ws_str(wsiString * src);
    ws_str(const ws_char * const src);
    ws_str(const ws_char * const src, ws_int len);
    ws_str(const ws_str & src);
    ~ws_str(void);

public:

    const ws_str & operator=(const ws_str & src);
    operator const ws_char * const (void) const;

    void SetString(const ws_char * const buf, ws_int len);

};

