#pragma once

#include "wscObject.h"
#include "wsiString.h"
#include "ws_implements.h"
#include "ws_ptr.h"
#include "wscClass.h"
#include "wsiLangService.h"




#define WS_IMPL_wsiString		\
	public:	                    \
virtual ws_char     CharAt(ws_int index) const                                                      { return _realCharAt( index); }    \
virtual ws_int      CodePointAt(ws_int index) const                                                 { return _realCodePointAt( index); }    \
virtual ws_int      CodePointBefore(ws_int index) const                                             { return _realCodePointBefore( index); }    \
virtual ws_int      CodePointCount(ws_int beginIndex, ws_int endIndex) const                        { return _realCodePointCount( beginIndex, endIndex); }    \
virtual ws_int      CompareTo(wsiString * anotherString) const                                      { return _realCompareTo( anotherString); }    \
virtual ws_int      CompareToIgnoreCase(wsiString * str) const                                      { return _realCompareToIgnoreCase( str); }    \
virtual void        Concat(wsiString * str, wsiString ** ret) const                                 { return _realConcat( str, ret); }    \
virtual ws_boolean  Contains(wsiCharSequence * s) const                                             { return _realContains( s); }    \
virtual ws_boolean  ContentEquals(wsiCharSequence * cs) const                                       { return _realContentEquals( cs); }    \
virtual ws_boolean  ContentEquals(wsiStringBuffer * sb) const                                       { return _realContentEquals( sb); }    \
virtual ws_boolean  EndsWith(wsiString * suffix) const                                              { return _realEndsWith( suffix); }    \
virtual ws_boolean  Equals(wsiObject * anObject) const                                              { return _realEquals( anObject); }    \
virtual ws_boolean  EqualsIgnoreCase(wsiString * anotherString) const                               { return _realEqualsIgnoreCase( anotherString); }    \
virtual void        GetBytes(wsiByteArray ** ret) const                                             { return _realGetBytes( ret); }    \
virtual void        GetBytes(wsiCharset * charset, wsiByteArray ** ret) const                       { return _realGetBytes( charset, ret); }    \
virtual void        GetBytes(wsiString * charsetName, wsiByteArray ** ret) const                    { return _realGetBytes( charsetName, ret); }    \
virtual void        GetChars(ws_int srcBegin, ws_int srcEnd, ws_char * dst, ws_int dstSize) const   { return _realGetChars( srcBegin, srcEnd, dst, dstSize); }    \
virtual ws_int      HashCode(void) const                                                            { return _realHashCode(); }    \
virtual ws_int      IndexOf(ws_int ch) const                                                        { return _realIndexOf( ch); }    \
virtual ws_int      IndexOf(ws_int ch, ws_int fromIndex) const                                      { return _realIndexOf( ch, fromIndex); }    \
virtual ws_int      IndexOf(wsiString * str) const                                                  { return _realIndexOf( str); }    \
virtual ws_int      IndexOf(wsiString * str, ws_int fromIndex) const                                { return _realIndexOf( str, fromIndex); }    \
virtual void        Intern(wsiString ** ret) const                                                  { return _realIntern( ret); }    \
virtual ws_boolean  IsEmpty(void) const                                                             { return _realIsEmpty(); }    \
virtual ws_int      LastIndexOf(ws_int ch) const                                                    { return _realLastIndexOf( ch); }    \
virtual ws_int      LastIndexOf(ws_int ch, ws_int fromIndex) const                                  { return _realLastIndexOf( ch, fromIndex); }    \
virtual ws_int      LastIndexOf(wsiString * str) const                                              { return _realLastIndexOf( str); }    \
virtual ws_int      LastIndexOf(wsiString * str, ws_int fromIndex) const                            { return _realLastIndexOf( str, fromIndex); }    \
virtual ws_int      Length(void) const                                                              { return _realLength(); }    \
virtual ws_boolean  Matches(wsiString * regex) const                                                { return _realMatches( regex); }    \
virtual ws_int      OffsetByCodePoints(ws_int index, ws_int codePointOffset) const                  { return _realOffsetByCodePoints( index, codePointOffset); }    \
virtual ws_boolean  RegionMatches(ws_boolean ignoreCase, ws_int toffset, wsiString * other, ws_int ooffset, ws_int len) const { return _realRegionMatches( ignoreCase, toffset, other, ooffset, len); }    \
virtual ws_boolean  RegionMatches(ws_int toffset, wsiString * other, ws_int ooffset, ws_int len) const          { return _realRegionMatches( toffset, other, ooffset, len); }    \
virtual void        Replace(ws_char oldChar, ws_char newChar, wsiString ** ret) const                           { return _realReplace( oldChar, newChar, ret); }    \
virtual void        Replace(wsiCharSequence * target, wsiCharSequence * replacement, wsiString ** ret) const    { return _realReplace( target, replacement, ret); }    \
virtual void        ReplaceAll(wsiString * regex, wsiString * replacement, wsiString ** ret) const              { return _realReplaceAll( regex, replacement, ret); }    \
virtual void        ReplaceFirst(wsiString * regex, wsiString * replacement, wsiString ** ret) const            { return _realReplaceFirst( regex, replacement, ret); }    \
virtual void        Split(wsiString * regex, wsiStringArray ** ret) const                                       { return _realSplit( regex, ret); }    \
virtual void        Split(wsiString * regex, ws_int limit, wsiStringArray ** ret) const                         { return _realSplit( regex, limit, ret); }    \
virtual ws_boolean  StartsWith(wsiString * prefix) const                                            { return _realStartsWith( prefix); }    \
virtual ws_boolean  StartsWith(wsiString * prefix, ws_int toffset) const                            { return _realStartsWith( prefix, toffset); }    \
virtual void        SubSequence(ws_int beginIndex, ws_int endIndex, wsiCharSequence ** ret) const   { return _realSubSequence( beginIndex, endIndex, ret); }    \
virtual void        Substring(ws_int beginIndex, wsiString ** ret) const                            { return _realSubstring( beginIndex, ret); }    \
virtual void        Substring(ws_int beginIndex, ws_int endIndex, wsiString ** ret) const           { return _realSubstring( beginIndex, endIndex, ret); }    \
virtual void        ToCharArray(wsiCharArray ** ret) const                                          { return _realToCharArray( ret); }    \
virtual void        ToLowerCase(wsiString ** ret) const                                             { return _realToLowerCase( ret); }    \
virtual void        ToLowerCase(wsiLocale * locale, wsiString ** ret) const                         { return _realToLowerCase( locale, ret); }    \
virtual void        ToString(wsiString ** ret) const                                                { return _realToString( ret); }    \
virtual void        ToUpperCase(wsiString ** ret) const                                             { return _realToUpperCase( ret); }    \
virtual void        ToUpperCase(wsiLocale * locale, wsiString ** ret) const                         { return _realToUpperCase( locale, ret); }    \
virtual void        Trim(wsiString ** ret) const                                                    { return _realTrim( ret); }    \
    \
virtual const ws_char * const         GetBuffer(void) const         { return _realGetBuffer(); }        \
virtual ws_int                        GetLength(void) const         { return _realGetLength(); }        \




#define WS_IMPL_wsiStringRW     \
    public:                     \
    virtual ws_char *  GetBufferRW(void)            {return _realGetBufferRW();}                \
    virtual ws_int     GetBufferSize(void) const    {return _realGetBufferSize();}              \
    virtual ws_int     SetLength(ws_int newLength)  {return _realSetLength(newLength);}         \
    virtual ws_int     SetString(const ws_char * const buf, ws_int len)  { return _realSetString(buf,len); }         \




class wscString : public wscObject, public wsiString
{
	WS_IMPL_wsiObject

    WS_IMPL_GET_CLASS( "wcpp.lang.wscString" )

public:

    static void GetStringService(wsiStringService ** ret);

//    static void New(wsiString ** ret);
    static void New(wsiString ** ret, const ws_char * const src);
    static void New(wsiString ** ret, const ws_char * const buf, ws_int len);

public:

    static void CopyValueOf(ws_char * data, wsiString ** ret);                             // ����ָ�������б�ʾ���ַ����е� String�� 
    static void CopyValueOf(ws_char * data, ws_int count, wsiString ** ret);               // ����ָ�������б�ʾ���ַ����е� String�� 
    ////
    static void Format(wsiString ** ret, wsiLocale * l, wsiString * format, ... );        // ʹ��ָ�������Ի�������ʽ�ַ����Ͳ�������һ����ʽ���ַ����� 
    static void Format(wsiString ** ret, wsiString * format, ... );                       // ʹ��ָ���ĸ�ʽ�ַ����Ͳ�������һ����ʽ���ַ����� 
    ////
    static void ValueOf(ws_boolean b, wsiString ** ret);                                   // ���� boolean �������ַ�����ʾ��ʽ�� 
    static void ValueOf(ws_char c, wsiString ** ret);                                      // ���� char �������ַ�����ʾ��ʽ�� 
    static void ValueOf(ws_char * data, wsiString ** ret);                                 // ���� char ����������ַ�����ʾ��ʽ�� 
    static void ValueOf(ws_char * data, ws_int offset, ws_int count, wsiString ** ret);    // ���� char ����������ض���������ַ�����ʾ��ʽ�� 
    static void ValueOf(ws_double d, wsiString ** ret);                                    // ���� double �������ַ�����ʾ��ʽ�� 
    static void ValueOf(ws_float f, wsiString ** ret);                                     // ���� float �������ַ�����ʾ��ʽ�� 
    static void ValueOf(ws_int i, wsiString ** ret);                                       // ���� int �������ַ�����ʾ��ʽ�� 
    static void ValueOf(ws_long l, wsiString ** ret);                                      // ���� long �������ַ�����ʾ��ʽ�� 
    static void ValueOf(wsiObject * obj, wsiString ** ret);                                // ���� Object �������ַ�����ʾ��ʽ�� 

protected:

    wscString(const wscString & src){}
    ~wscString(void){}
    const wscString & operator=(const wscString & src){}

};

