
#include "wscThrowable.h"
#include "ws_ptr.h"



void _ws_ptr_func::Throw(ws_int eid, const ws_char * const msg, const ws_char * const filename, ws_int line)
{
    switch (eid) {

        case _ws_ptr_func::eidNullPointer:

            throw wseNullPointerException(
                wseNullPointerException::sSTR, 
                msg,
                filename,
                line );
            break;

        case _ws_ptr_func::eidIllegalStateException:

            throw wseIllegalStateException(
                wseIllegalStateException::sSTR,
                msg,
                filename,
                line );
            break;

        case _ws_ptr_func::eidUnsupportedOperation:
        default:

            throw wseUnsupportedOperationException(
                wseUnsupportedOperationException::sSTR, 
                msg,
                filename,
                line );
            break;

    }
}


