/* 
 * File:   wsolangservice.cpp
 * Author: Xukun
 * 
 * Created on 2009��7��17��, ����2:09
 */

#include "wsoLangService.h"
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/wscom/wsiServiceManager.h>
#include <wcpp/wscom/WSCOM.h>


void wsoLangService::GetLangService(wsiLangService ** ret)
{
    static ws_ptr<wsiLangService> sLS;
    if (!sLS) {

        ws_ptr<wsiServiceManager> sm;
        WSCOM::WS_GetServiceManager( &sm );

        ws_ptr<wsiLangService> ls;
        sm->GetService( wsoLangService::sCID, ls.GetIID(), (void**) (&ls) );

        sLS = ls;
    }
    sLS.QueryInterface( ret );
}

