#include "wscCallsParser.h"
#include "wsiCallsHandler.h"


wscCallsParser::wscCallsParser(wsiCallsHandler * ch)
{
}

