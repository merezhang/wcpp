#pragma once
#include <wcpp/lang/wsiObject.h>
#include <wcpp/lang/wsiString.h>


class wsiCallsParamList : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    virtual ws_int CountParam(void) = 0;
    virtual void   GetParam(ws_int index, wsiString ** rParamString) = 0;
};

