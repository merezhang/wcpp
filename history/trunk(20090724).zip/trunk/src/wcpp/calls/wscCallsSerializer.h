#pragma once
#include <wcpp/lang/ws_ptr.h>


class wsiOutputStream;


class wscCallsSerializer : public wsiCallsSerializer
{
public:
    wscCallsSerializer(wsiOutputStream * os);
    ~wscCallsSerializer(void);
private:
    ws_ptr<wsiOutputStream> m_os;
};

