#pragma once
#include <wcpp/lang/wsiObject.h>


class wsiInputStream;


class wsiCallsParser : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    virtual void parse(wsiInputStream * is) = 0;
};

