// ws_id.cpp

#include "ws_id.h"



