// wsuSyncObject.h
#ifndef __wsuSyncObject_h__
#define __wsuSyncObject_h__

#include <wcpp/wspr/ws_type.h>


class wsuSyncObject
{
protected:
    explicit wsuSyncObject(void);
    explicit wsuSyncObject(const wsuSyncObject & init);
    virtual ~wsuSyncObject(void);
    const wsuSyncObject & operator=(const wsuSyncObject & src);
public:
    virtual void Lock(void) = 0;
    virtual void Unlock(void) = 0;
};


#endif // __wsuSyncObject_h__
