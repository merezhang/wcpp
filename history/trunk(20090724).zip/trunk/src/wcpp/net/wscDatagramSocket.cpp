#include "wscDatagramSocket.h"


wscDatagramSocket::wscDatagramSocket(void)
{
}


wscDatagramSocket::~wscDatagramSocket(void)
{
}

