#include "ReferenceTest.h"
#include <wcpp/lang/ref/wsiWeakReference.h>
#include <wcpp/lang/ref/wsuSupportsWeakReference.h>
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/lang/wscClass.h>


/*
 *******************************************************************************
 * private classes
 *******************************************************************************
 */


class iClassB : public wsiObject
{
public:
        virtual void SetPtr(wsiWeakReference * ptr) = 0;
};


class iClassA : public wsiSupportsWeakReference
{
public:
        virtual void SetPtr(iClassB * ptr) = 0;

};


class ClassA : public wscObject, public iClassA, public wsuSupportsWeakReference
{
    WS_IMPL_wsiObject
    WS_IMPL_wsiSupportsWeakReference
public:
    virtual void SetPtr(iClassB * ptr) { m_b = ptr; }

        virtual void _realGetClass(wsiClass ** rClass)
        {
            static ws_ptr<wsiClass> sClass( new wscClass("unit_test.ClassA") );
            sClass.QueryInterface(rClass);
        }

private:
    ws_ptr<iClassB> m_b;
};


class ClassB : public wscObject, public iClassB
{
        WS_IMPL_wsiObject
public:
        virtual void SetPtr(wsiWeakReference * ptr) { m_a = ptr; }

        virtual void _realGetClass(wsiClass ** rClass)
        {
            static ws_ptr<wsiClass> sClass( new wscClass("unit_test.ClassB") );
            sClass.QueryInterface(rClass);
        }

private:
        ws_ptr<wsiWeakReference> m_a;
};


/*
 *******************************************************************************
 * ReferenceTest class
 *******************************************************************************
 */


ReferenceTest::ReferenceTest(void)
{
}


ReferenceTest::~ReferenceTest(void)
{
}


void ReferenceTest::doTest(void)
{
	trace( "========================================\n" );
	trace( "case:ReferenceTest - begin\n" );

	try {

		test_WeakReference();

	} catch (...) {
		trace( "exception from ReferenceTest\n" );
	}

	trace( "case:ReferenceTest - end\n" );
	trace( "========================================\n" );
}




void ReferenceTest::test_WeakReference(void)
{


	ws_ptr<iClassA> a( new ClassA() );
	ws_ptr<iClassB> b( new ClassB() );
	//
	ws_ptr<wsiWeakReference> wRef;
	a->GetWeakReference( &wRef );
	//
	b->SetPtr( wRef );
	a->SetPtr( b );
	//
//	wRef.Release();
	a.Release();
	b.Release();

	ws_ptr<wsiObject> obj;
	wRef->Get( obj.GetIID(), (void**) (&obj) );

}


