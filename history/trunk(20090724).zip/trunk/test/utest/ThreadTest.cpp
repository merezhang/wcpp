#include "ThreadTest.h"
#include <wcpp/lang/wscThread.h>
#include <wcpp/lang/wscSystem.h>



ThreadTest::ThreadTest(void)
{
}

ThreadTest::~ThreadTest(void)
{
}


void ThreadTest::doTest(void)
{
	trace( "========================================\n" );
	trace( "case:ThreadTest - begin\n" );

	test_CreateThread();

	trace( "case:ThreadTest - end\n" );
	trace( "========================================\n" );
}


void ThreadTest::test_CreateThread(void)
{
	class myThread : public wscThread
	{
	public:
		virtual void Run(void)
		{
            trace( "myThread::Run - begin\n" );
			wscThread::Sleep( 1000 * 5 );
            trace( "myThread::Run - end\n" );
		}
	};

	class myRunnable : public wscObject, public wsiRunnable
	{
		WS_IMPL_wsiObject
        WS_IMPL_GET_CLASS( "unit_test.ThreadTest::test_CreateThread::myRunnable" )
	public:
		virtual void Run(void)
		{
            trace( "myRunnable::Run - begin\n" );
			wscThread::Sleep( 1000 * 10 );
            trace( "myRunnable::Run - end\n" );
		}
	};

	trace( "    --------------------------------    \n" );
	trace( "func:test_CreateThread - begin\n" );

	ws_ptr<wsiThread> thd1( new wscThread() );
	ws_ptr<wsiThread> thd2( new myThread() );
	ws_ptr<wsiThread> thd3( new wscThread( new myRunnable() ) );

	thd1->Start();
	thd2->Start();
	thd3->Start();

	thd1->Join();
	thd2->Join();
	thd3->Join();

	trace( "func:test_CreateThread - end\n" );
	trace( "    --------------------------------    \n" );
}

