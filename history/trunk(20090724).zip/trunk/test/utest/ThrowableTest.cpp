#include "ThrowableTest.h"

#include <wcpp/lang/ws_str.h>
#include <wcpp/lang/wscThrowable.h>
#include <wcpp/io/wseIOException.h>


ThrowableTest::ThrowableTest(void)
{
}


ThrowableTest::~ThrowableTest(void)
{
}


void ThrowableTest::DoTry(int tid)
{
	switch (tid) {
		case tid_wsThrowable:						WS_THROW( wscThrowable,"msg in DoTry(tid_wsThrowable)");		break;
		case tid_wsException:						WS_THROW( wseException,"msg in DoTry(tid_wsException)");		break;
		case tid_wsError:							WS_THROW( wseError    ,"msg in DoTry(tid_wsError)"    );		break;

		case tid_wsRuntimeException:				WS_THROW( wseRuntimeException,"msg");							break;
		case tid_wsNullPointerException:			WS_THROW( wseNullPointerException,"msg");						break;
		case tid_wsClassCastException:				WS_THROW( wseClassCastException,"msg");							break;

		case tid_wsIOException:						WS_THROW( wseIOException,"msg");								break;
		case tid_wsUTFDataFormatException:			WS_THROW( wseUTFDataFormatException,"msg");						break;
		case tid_wsUnsupportedEncodingException:	WS_THROW( wseUnsupportedEncodingException,"msg");				break;
		case tid_wsInterruptedIOException:			WS_THROW( wseInterruptedIOException,"msg");						break;
		case tid_wsEOFException:					WS_THROW( wseEOFException,"msg");								break;
	}
}


void ThrowableTest::DoTryCatch(int tid)
{
	try {
		DoTry(tid);
	}
	catch (wscThrowable e) {

		ws_str str;

		e.GetMessage( &str );
		trace( "    " );
		trace( str );
		trace( "\n" );

		e.ToString( &str );
		trace( "    " );
		trace( str );
		trace( "\n" );

		e.PrintStackTrace();

	}
	catch (...) {
		trace( "catch(...)\n" );
	}
}


void ThrowableTest::doTest(void)
{
	trace( "========================================\n" );
	trace( "case:ThrowableTest - begin\n" );

	for (int i=0; i<tid_max; i++)
	{
		trace( "    --------------------------------    \n" );
		trace( "    " );
		trace( i );
		trace( "." );
		switch (i) {

			case tid_wsThrowable:	trace( "tid_wsThrowable" );	break;
			case tid_wsError:		trace( "tid_wsError" );		break;
			case tid_wsException:	trace( "tid_wsException" );	break;

			case tid_wsRuntimeException:		trace( "tid_wsRuntimeException" );		break;
			case tid_wsNullPointerException:	trace( "tid_wsNullPointerException" );	break;
			case tid_wsClassCastException:		trace( "tid_wsClassCastException" );	break;

			case tid_wsIOException:						trace( "tid_wsIOException" );					break;
			case tid_wsUTFDataFormatException:			trace( "tid_wsUTFDataFormatException" );		break;
			case tid_wsUnsupportedEncodingException:	trace( "tid_wsUnsupportedEncodingException" );	break;
			case tid_wsInterruptedIOException:			trace( "tid_wsInterruptedIOException" );		break;
			case tid_wsEOFException:					trace( "tid_wsEOFException" );					break;

		}
		trace( "\n" );
		DoTryCatch( i );
	}

	trace( "case:ThrowableTest - end\n" );
	trace( "========================================\n" );
}

