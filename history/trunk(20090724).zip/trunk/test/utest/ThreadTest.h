#pragma once
#include "testcase.h"




class ThreadTest : public TestCase
{
    WS_IMPL_GET_CLASS( "ThreadTest" )
public:
	ThreadTest(void);
	~ThreadTest(void);

	void doTest(void);

private:

	void test_CreateThread(void);

};



