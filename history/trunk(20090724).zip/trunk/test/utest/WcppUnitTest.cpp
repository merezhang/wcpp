// WcppUnitTest.cpp : ����Ӧ�ó��������Ϊ��?
//

#include "WcppUnitTest.h"

#include "StringTest.h"
#include "ThrowableTest.h"
#include "ThreadTest.h"
#include "wscomTest.h"
#include "ServiceManagerTest.h"
#include "ReferenceTest.h"

#include <wcpp/lang/ws_ptr.h>
#include <wcpp/wscom/WSCOM.h>
#include <wcpp/io/wscFile.h>


void test_main(void)
{
    ws_str strPath( "d:\\aaa\\bbb\\ccc" );
    ws_ptr<wsiFile> binDir( new wscFile(strPath) );

	ws_ptr<wsiServiceManager> smptr;
	WSCOM::WS_InitWSCOM( &smptr, binDir , WS_NULL );
	WSCOM::WS_InitWSCOM( &smptr, binDir , WS_NULL );


	for (int i=0; i<10; i++) {
		ws_ptr<iTestCase> tc;
		tc.Release();
		switch (i) {
			case 0:		tc = new StringTest();			break;
			case 1:		tc = new ThrowableTest();		break;
			case 2:		tc = new ThreadTest();			break;
			case 3:		tc = new WscomTest();			break;
			case 4:		tc = new ServiceManagerTest();	break;
			case 5:		tc = new ReferenceTest();		break;
		}
		if (!(!tc)) tc->doTest();
	}


	WSCOM::WS_ShutdownWSCOM( smptr );
	WSCOM::WS_ShutdownWSCOM( smptr );

}

