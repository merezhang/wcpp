#pragma once
#include "testcase.h"




class WscomTest : public TestCase
{
    WS_IMPL_GET_CLASS( "WscomTest" )
public:

	WscomTest(void);
	~WscomTest(void);

	virtual void doTest(void);

	void test_LoadLibrary(void);
	void test_WSCOM_static_funcs(void);

};


