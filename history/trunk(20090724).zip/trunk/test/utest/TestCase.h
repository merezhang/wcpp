#pragma once

#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/ws_implements.h>
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/lang/wscClass.h>




class iTestCase : public wsiObject
{
public:
	static const ws_iid sIID;
public:
	virtual void doTest(void) = 0;
};




class TestCase : public wscObject, public iTestCase
{
	WS_IMPL_wsiObject

public:

	TestCase(void);
	virtual ~TestCase(void);

protected:

	static void trace(const char* const str);
	static void trace(ws_long n);

};



