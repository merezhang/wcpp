#include "StdAfx.h"
#include "utOutputStream.h"
#include <wcpp/lang/wscString.h>

#include <utest/WcppUnitTest.h>
#include <wcpp/wscom/WSCOM.h>
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/lang/wscSystem.h>
#include <wcpp/lang/wsoLangService.h>
#include <wcpp/io/wscPrintStream.h>
#include "utOutputStream.h"


void utOutputStream::Init(void)
{
    ws_ptr<wsiOutputStream> os( new utOutputStream() );
    ws_ptr<wsiPrintStream> ps( new wscPrintStream(os) );
    wscSystem::SetOut( ps );
}


utOutputStream::utOutputStream(void) : m_file(NULL)
{
    CTime tm( CTime::GetCurrentTime() );
    CString name;
    name.Format( "wcpp_unit_test_%04d-%02d-%02d_%02d.%02d.%02d.txt",
        tm.GetYear(), tm.GetMonth(), tm.GetDay(),
        tm.GetHour(), tm.GetMinute(), tm.GetSecond() );
    CFile * pf = new CFile( name, CFile::modeCreate|CFile::modeReadWrite );
    m_file = pf;
}


utOutputStream::~utOutputStream(void)
{
    CFile * pf = m_file;
    m_file = NULL;
    if (pf) {
        pf->Close();
        delete pf;
    }
}


void utOutputStream::_realWrite(ws_int b)
{
    ws_byte buf[2];
    buf[0] = (ws_byte)b;
    buf[1] = 0;
    CFile * pf = m_file;
    if (pf) pf->Write( buf, 1 );
}

