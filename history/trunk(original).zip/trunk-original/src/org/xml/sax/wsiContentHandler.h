#pragma once


class wsiContentHandler : public wsiObject
{
public:
    static const ws_iid sIID;
public:
};

