#pragma once


class wsiAttributes : public wsiObject
{
public:
    static const ws_iid sIID;
public:
};

