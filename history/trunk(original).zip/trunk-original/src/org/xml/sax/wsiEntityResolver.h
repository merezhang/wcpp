#pragma once


class wsiEntityResolver : public wsiObject
{
public:
    static const ws_iid sIID;
public:
};

