// wsimpl.h
#ifndef __ws_impl_h__
#define __ws_impl_h__


/********************************************************************************************************************
	WS_IMPL_GET_INTERFACE_

	protected:
	virtual wsiInterface* getInterface(const ws_iid & aIID)
	{
		wsInterface * ret = WS_NULL;
		if      (aIID == wsIObject::sIID)	{	ret = get_wsIObject();					}
		else if (aIID == wsIxxxxx::sIID)	{	ret = dynamic_cast<wsIxxxxx*>(this);	}
		else								{	ret = __super::getInterface(aIID);		}
		return ret;
	}
	
*/


#define WS_IMPL_GET_INTERFACE_BEGIN                                                \
    protected:                                                                  \
    virtual wsiInterface* _getInterfaceByIID(const ws_iid & aIID)               \
    {                                                                           \
        wsiInterface * ret = WS_NULL;                                           \
        if (aIID == wsiObject::sIID) {                                          \
            ret = _getRootInterface();                                          \
        }                                                                       \


#define WS_IMPL_GET_INTERFACE_BODY(_interface_)                                    \
        else if (aIID == _interface_::sIID) {                                   \
            ret = dynamic_cast<_interface_*>(this);                             \
        }                                                                       \


#define WS_IMPL_GET_INTERFACE_END                                         \
        else {                                                                  \
            ret = super_class::_getInterfaceByIID(aIID);                            \
        }                                                                       \
        return ret;                                                             \
    }                                                                           \


/********************************************************************************************************************
	WS_IMPL_GET_CLASS_
*/


#define WS_IMPL_GET_CLASS(_class_name_string_)                                  \
    public:                                                                     \
    virtual void _realGetClass(wsiClass ** rClass) {                            \
        static ws_ptr<wsiClass> sClass( new wscClass( _class_name_string_ ) );  \
        sClass.QueryInterface(rClass);                                          \
    }                                                                           \


/*******************************************************************************************************************
	IMPL_WS_IOBJECT
*/





/*******************************************************************************************************************
	EOF
*/

#endif // __ws_impl_h__
