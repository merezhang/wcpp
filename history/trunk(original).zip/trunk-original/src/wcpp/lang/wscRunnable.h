#pragma once
#include "wsiRunnable.h"






#define WS_IMPL_wsiRunnable		\
	public:		\
	virtual void Run(void) {_realRun();}		\




