#include "wscThreadImpl.h"
#include <wcpp/lang/wscThrowable.h>


wscThreadImpl::wscThreadImpl(wsiRunnable * target, wsiCString * name) : m_thread( WS_NULL )
{
    m_target = target;
    m_name = name;
}


wscThreadImpl::~wscThreadImpl(void)
{
    ws_thread * thd = m_thread;
    m_thread = WS_NULL;
    if (thd) delete thd;
}


void wscThreadImpl::GetName(wsiVString * rName)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


ws_int wscThreadImpl::GetPriority(void)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


void wscThreadImpl::Interrupt(void)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


ws_boolean wscThreadImpl::IsAlive(void)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


void wscThreadImpl::Join(void)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


void wscThreadImpl::Run(void)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


void wscThreadImpl::SetPriority(ws_int newPriority)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


void wscThreadImpl::Start(void)
{
    ws_thread * thd = m_thread;
    if (thd == WS_NULL) {
        thd = ws_thread::StartThread( this );
        m_thread = thd;
        if (thd==WS_NULL) {
            WS_THROW( wseIllegalThreadStateException , "" );
        }
    }
    else {
        WS_THROW( wseIllegalThreadStateException , "" );
    }
}


void wscThreadImpl::ThreadProc(void)
{
    m_target->Run();
}

