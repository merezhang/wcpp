#pragma once

#include <wcpp/lang/wsiLangService.h>
#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/io/wsiPrintStream.h>
#include <wcpp/lang/wscString.h>


class wscSystemService : public wscObject, public wsiSystemService
{
    WS_IMPL_wsiObject
    WS_IMPL_GET_CLASS( "wcpp.lang.service.wscSystemService" )
public:
    wscSystemService(void);
    ~wscSystemService(void);
private:
    virtual void GetErr(wsiPrintStream ** ret);
    virtual void GetIn (wsiInputStream ** ret);
    virtual void GetOut(wsiPrintStream ** ret);
    virtual void SetErr(wsiPrintStream * aPrintStream);
    virtual void SetIn (wsiInputStream * aInputStream);
    virtual void SetOut(wsiPrintStream * aPrintStream);
private:
    ws_ptr<wsiPrintStream> m_err;
    ws_ptr<wsiInputStream> m_in;
    ws_ptr<wsiPrintStream> m_out;
};

