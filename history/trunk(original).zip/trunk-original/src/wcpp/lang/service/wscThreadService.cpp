#include "wscThreadService.h"
#include <wcpp/lang/ws_ptr.h>
#include "wscThreadImpl.h"
#include <wcpp/wspr/ws_thread.h>


wscThreadService::wscThreadService(void)
{
}


wscThreadService::~wscThreadService(void)
{
}


void wscThreadService::NewThread(wsiRunnable * target, wsiCString * name, wsiThread ** ret)
{
    ws_ptr<wsiThread> newthd( new wscThreadImpl(target,name) );
    newthd.QueryInterface( ret );
}


void wscThreadService::Sleep(ws_long millis)
{
    ws_thread::Sleep( millis );
}

