#include "wscLangService.h"
#include <wcpp/lang/wsiObject.h>
#include <wcpp/lang/ws_ptr.h>

#include "wscRuntimeService.h"
#include "wscSystemService.h"
#include "wscThreadService.h"


/*
 **************************************************************************************************************
 *  wscLangServiceFactory
 **************************************************************************************************************
 */


wscLangServiceFactory::wscLangServiceFactory(void)
{
}


wscLangServiceFactory::~wscLangServiceFactory(void)
{
}


void wscLangServiceFactory::_realCreateInstance(wsiObject * aOuter, const ws_iid & aIID, void ** ret)
{
    ws_ptr<wsiLangService> nls( new wscLangService() );
    nls->QueryInterface( aIID, ret );
}


/*
 **************************************************************************************************************
 *  wscLangService
 **************************************************************************************************************
 */


wscLangService::wscLangService(void)
{
    ws_ptr<wsiRuntimeService> rs( new wscRuntimeService() );
    ws_ptr<wsiSystemService> ss( new wscSystemService() );
    ws_ptr<wsiThreadService> ts( new wscThreadService() );

    m_runtimes = rs;
    m_systems  = ss;
    m_threads  = ts;
}


wscLangService::~wscLangService(void)
{
}


void wscLangService::GetRuntimeService(wsiRuntimeService ** ret)
{
    m_runtimes.QueryInterface( ret );
}


void wscLangService::GetSystemService(wsiSystemService ** ret)
{
    m_systems.QueryInterface( ret );
}


void wscLangService::GetThreadService(wsiThreadService ** ret)
{
    m_threads.QueryInterface( ret );
}

