#pragma once

#include "wsiObject.h"




class wsiCString : public wsiObject
{
public:
	static const ws_iid sIID;

	virtual const ws_char * const GetBuffer(void) const = 0;
	virtual const ws_int          GetLength(void) const = 0;


};




class wsiVString : public wsiCString
{
public:
	static const ws_iid sIID;

	virtual void  SetString(const ws_char * const buffer, const ws_int length) = 0;
	virtual void  SetString(const ws_char * const buffer) = 0;
	virtual void  SetString(wsiCString * src) = 0;

public:

};



