#include "wscThread.h"
#include "wsoLangService.h"
#include <wcpp/lang/wscThrowable.h>


/*
 ********************************************************************************************************
 *  wscRunnableProxy
 ********************************************************************************************************
 */


class wscRunnableProxy : public wscObject, public wsiRunnableProxy
{
    WS_IMPL_wsiObject
    WS_IMPL_GET_CLASS( "wcpp.lang.wscRunnableProxy" )
public:
    wscRunnableProxy(wsiRunnable * target);
    ~wscRunnableProxy(void);
    virtual void Run(void);
    virtual void Clear(void);
    virtual ws_boolean IsStarted(void);
    virtual ws_boolean IsStopped(void);
private:
    wsiRunnable * m_pTarget;
    ws_boolean m_started;
    ws_boolean m_stopped;
};


wscRunnableProxy::wscRunnableProxy(wsiRunnable * target)
:   m_pTarget( target ),
    m_started( WS_FALSE ),
    m_stopped( WS_FALSE )
{
}


wscRunnableProxy::~wscRunnableProxy(void)
{
    m_pTarget = WS_NULL;
}


void wscRunnableProxy::Run(void)
{
    ws_ptr<wsiRunnable> target( m_pTarget );
    m_pTarget = WS_NULL;
    m_started = WS_TRUE;
    try {
        target->Run();
        m_stopped = WS_TRUE;
    }
    catch (...) {
        m_stopped = WS_TRUE;
        throw;
    }
}


void wscRunnableProxy::Clear(void)
{
    m_pTarget = WS_NULL;
}


ws_boolean wscRunnableProxy::IsStarted(void)
{
    return m_started;
}


ws_boolean wscRunnableProxy::IsStopped(void)
{
    return m_stopped;
}


/*
 ********************************************************************************************************
 *  wscThread
 ********************************************************************************************************
 */


void wscThread::GetThreadService(wsiThreadService ** ret)
{
    ws_ptr<wsiLangService> ls;
    wsoLangService::GetLangService( ls.GetPtr2() );
    ws_ptr<wsiThreadService> ts;
    ls->GetThreadService( ret );
}


wscThread::wscThread(void)
{
    Init( WS_NULL );
}


wscThread::wscThread(wsiRunnable * target)
{
    m_target = target;
    Init( WS_NULL );
}


wscThread::wscThread(wsiRunnable * target, wsiCString * name)
{
    m_target = target;
    Init( name );
}


wscThread::wscThread(wsiCString * name)
{
    Init( name );
}


void wscThread::Init(wsiCString * name)
{
    ws_ptr<wsiRunnableProxy> proxy( new wscRunnableProxy(this) );
    m_proxy = proxy;

    ws_ptr<wsiThreadService> ts;
    GetThreadService( ts.GetPtr2() );
    ws_ptr<wsiThread> thd;
    ts->NewThread( proxy, name, thd.GetPtr2() );
    m_impl = thd;
}


wscThread::~wscThread(void)
{
    try {
        m_proxy->Clear();
    }
    catch (...) {
    }
}


ws_int wscThread::ActiveCount(void)
{
    WS_THROW( wseUnsupportedOperationException, "" );
	return 0;
}


void wscThread::CurrentThread(wsiThread ** rThread)
{
    WS_THROW( wseUnsupportedOperationException, "" );
}


void wscThread::Sleep(ws_long millis)
{
    ws_ptr<wsiThreadService> ts;
    GetThreadService( ts.GetPtr2() );
    ts->Sleep( millis );
}


void wscThread::Yield(void)
{
    WS_THROW( wseUnsupportedOperationException, "" );
}


void wscThread::_realGetName(wsiVString * rName)
{
	m_impl->GetName( rName );
}


ws_int wscThread::_realGetPriority(void)
{
	return m_impl->GetPriority();
}


void wscThread::_realInterrupt(void)
{
	m_impl->Interrupt();
}


ws_boolean wscThread::_realIsAlive(void)
{
	return m_impl->IsAlive();
}


void wscThread::_realJoin(void)
{
    if ( m_proxy->IsStarted() ) {
        while (true) {
            if (m_proxy->IsStopped()) break;
            Sleep(10);
        }
    }
    else {
        WS_THROW( wseIllegalThreadStateException , "Join a thread which is not started." );
    }
}


void wscThread::_realSetPriority(ws_int newPriority)
{
	m_impl->SetPriority( newPriority );
}


void wscThread::_realStart(void)
{
	m_impl->Start();

    int cs = 0;
    int lp = 0;
    while (cs < 1000) {
        lp++;
        if (m_proxy->IsStarted()) return;
        if (lp > 500) {
            Sleep(1);
            cs++;
        }
        else {
            Sleep(0);
        }
    }
}


void wscThread::_realRun(void)
{
    ws_ptr<wsiRunnable> tar( m_target );
    if (!tar.IsNull()) tar->Run();
}

