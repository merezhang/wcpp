// ws_ptr.h

#ifndef __ws_ptr_h__
#define __ws_ptr_h__

#include <wcpp/wspr/ws_type.h>
#include <wcpp/wspr/ws_id.h>


template <typename T>
class _ws_ptr_T_noAddRelease : public T
{
private:
	virtual ws_int AddRef(void) = 0;
	virtual ws_int Release(void) = 0;
};


class _ws_ptr_throw
{
public:
    static void ThrowNullPointerException(const ws_char * const msg);
};


template <typename T>
class ws_ptr
{
private:
	T * mPtr;

public:

	ws_ptr(void) : mPtr(WS_NULL)
	{
	}

	ws_ptr(const ws_ptr & init) : mPtr(WS_NULL)
	{
		T* pnew = init.mPtr;
		if (pnew) pnew->AddRef();
		mPtr = pnew;
	}

	ws_ptr(T * init) : mPtr(WS_NULL)
	{
		wsiInterface* pnew = init;
		if (pnew) pnew->AddRef();
		mPtr = init;
	}

	~ws_ptr(void)
	{
		Release();
	}

	T* operator=(T* src)
	{
		T* pold = mPtr;
		T* pnew = src;
		if (pnew) pnew->AddRef();
		if (pold) pold->Release();
		mPtr = pnew;
		return pnew;
	}

	T* operator=(const ws_ptr<T> & src)
	{
		T* pold = mPtr;
		T* pnew = src.mPtr;
		if (pnew) pnew->AddRef();
		if (pold) pold->Release();
		mPtr = pnew;
		return pnew;
	}

	_ws_ptr_T_noAddRelease<T>* operator->() const
	{
		_ws_ptr_T_noAddRelease<T>* ret = (_ws_ptr_T_noAddRelease<T>*) mPtr ;
        if (ret==WS_NULL) {
            _ws_ptr_throw::ThrowNullPointerException( "operator-> with null ws_ptr<T>." );
        }
		return ret;
	}

	operator T*( ) const throw( )
	{
		return mPtr;
	}

	T* GetPtr(void)
	{
		return mPtr;
	}

	T** GetPtr2(void)
	{
		Release();
		return (&mPtr);
	}

	void Release()
	{
		wsiInterface* pold = mPtr;
		mPtr = WS_NULL;
		if (pold) pold->Release();
	}

	ws_boolean operator==(const T* const p)
	{
		return (mPtr==p);
	}

	void QueryInterface(T ** ret)
	{
        if (ret==WS_NULL) {
            _ws_ptr_throw::ThrowNullPointerException( "QueryInterface with null ws_ptr<T>." );
        }
		T* p = mPtr;
		if (p) p->AddRef();
		(*ret) = p;
	}

	ws_boolean IsNull(void)
	{
		return ((mPtr==WS_NULL) ? WS_TRUE : WS_FALSE );
	}

	const ws_iid & GetIID(void)
	{
		return T::sIID;
	}

};




#endif // __ws_ptr_h__
