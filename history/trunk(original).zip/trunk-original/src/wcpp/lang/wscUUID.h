#pragma once
#include "wscobject.h"
#include "wsiUUID.h"




#define WS_IMPL_wsiUUID		\
	public:		\




class wscUUID : public wscObject, public wsiUUID
{
	WS_IMPL_wsiObject
	WS_IMPL_wsiUUID

public:

	wscUUID(void);
	~wscUUID(void);

	static void ParseUUID(wsiCString * aStr, ws_uuid & rUuid);
	static void ToString(const ws_uuid & aUuid, wsiVString * rStr);

private:

	static void SwapBytes(ws_byte * buf, ws_uint i1, ws_uint i2);

	static ws_uint32 StrToU32(const ws_char* const str);
	static ws_uint16 StrToU16(const ws_char* const str);
	static ws_uint8  StrToU8 (const ws_char* const str);

	static void U32ToStr(const ws_uint32 n, ws_char* const buf);
	static void U16ToStr(const ws_uint16 n, ws_char* const buf);
	static void U8ToStr (const ws_uint8  n, ws_char* const buf);

};



