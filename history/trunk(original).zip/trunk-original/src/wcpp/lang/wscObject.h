// wscObject.h
#ifndef __wscObject_h__
#define __wscObject_h__

#include "wsiObject.h"
#include "wscInterface.h"
#include <wcpp/wspr/wsuMutex.h>




#define WS_IMPL_wsiObject		\
	public:	\
	virtual ws_boolean   Equals    (wsiObject * obj)             {return _realEquals(obj);}	\
	virtual void         GetClass  (wsiClass ** rClass)          {_realGetClass(rClass);}	\
	virtual ws_int       HashCode  (void)                        {return _realHashCode();}	\
	virtual void         Notify    (void)                        {}	\
	virtual void         NotifyAll (void)                        {}	\
	virtual void         ToString  (wsiVString * rString)        {_realToString(rString);}	\
	virtual void         Wait      (void)                        {}	\
	virtual void         Wait      (ws_long timeout)             {}	\
	virtual void         Wait      (ws_long timeout, ws_int nanos) {}	\
	WS_IMPL_wsiInterface




class wscObject : public wsiObject
{
	WS_IMPL_wsiObject

public:

	wscObject(void);
	~wscObject(void);

	static void _FreeObject(wsiInterface * ptr);

protected:
	
	virtual ws_int       _realAddRef         (void) ;
	virtual ws_int       _realRelease        (void) ;
	virtual void         _realQueryInterface (const ws_iid & aIID, void** ret);

	virtual ws_int       _realHashCode       (void);
	virtual ws_boolean   _realEquals         (wsiObject * obj);
	virtual void         _realGetClass       (wsiClass ** rClass) = 0;
	virtual void         _realToString       (wsiVString * rString);

	wsiInterface *           _getRootInterface(void);
	virtual wsiInterface *   _getInterfaceByIID(const ws_iid & aIID);


private:

	ws_int m_refcnt;
	static ws_int s_objcnt;

	static wsuMutex s_mutexForRefcnt;
	static wsuMutex s_mutexForObjcnt;

};




#endif // __wsxObject_h__
