#pragma once

#include "wsiObject.h"




class wsiRuntime : public wsiObject
{
public:

	static const ws_iid sIID;

	virtual void      Exit(ws_int status) = 0;
	virtual ws_long   FreeMemory(void) = 0;
	virtual void      Gc(void) = 0;
	virtual ws_long   TotalMemory(void) = 0;

};



