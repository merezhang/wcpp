#pragma once
#include "wsiSupportsWeakReference.h"
#include "wscWeakReference.h"
#include <wcpp/lang/ws_ptr.h>


class wsuSupportsWeakReference : public wsiSupportsWeakReference
{
protected:
	wsuSupportsWeakReference(void);
	~wsuSupportsWeakReference(void);
	virtual void _realGetWeakReference(wsiWeakReference ** ret);
private:
	ws_ptr<wsiWeakReference> m_WeakRef;
};


#define WS_IMPL_wsiSupportsWeakReference		\
	public:		\
	virtual void GetWeakReference(wsiWeakReference ** ret) { _realGetWeakReference(ret); }\


