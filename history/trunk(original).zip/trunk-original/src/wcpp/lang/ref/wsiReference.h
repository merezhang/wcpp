#pragma once
#include <wcpp/lang/wsiObject.h>


class wsiReference : public wsiObject
{
public:
	static const ws_iid sIID;
public:
	virtual void Clear(void) = 0;
	virtual void Get(const ws_iid & aIID, void ** ret) = 0;
};

