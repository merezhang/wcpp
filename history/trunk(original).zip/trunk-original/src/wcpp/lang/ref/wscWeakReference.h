#pragma once
#include <wcpp/lang/wscObject.h>
#include "wsiWeakReference.h"
#include "wsiSupportsWeakReference.h"
#include <wcpp/lang/wscString.h>



class wscWeakReference : public wscObject, public wsiWeakReference
{
	WS_IMPL_wsiObject

    WS_IMPL_GET_CLASS( "wcpp.lang.ref.wscWeakReference" )
private:

	wscWeakReference(const wscWeakReference & init);
	const wscWeakReference & operator=(const wscWeakReference & init);

	virtual void Clear(void);
	virtual void Get(const ws_iid & aIID, void ** ret);

public:

	wscWeakReference(wsiSupportsWeakReference * obj);
	~wscWeakReference(void);

private:

	wsiSupportsWeakReference * m_ptr;

};



