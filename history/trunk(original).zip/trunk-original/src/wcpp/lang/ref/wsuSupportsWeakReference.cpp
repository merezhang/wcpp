#include "wsuSupportsWeakReference.h"
#include "wscWeakReference.h"


wsuSupportsWeakReference::wsuSupportsWeakReference(void)
{
    ws_ptr<wsiWeakReference> wref( new wscWeakReference(this) );
    m_WeakRef = wref;
}


wsuSupportsWeakReference::~wsuSupportsWeakReference(void)
{
	try {
		m_WeakRef->Clear();
	}
	catch (...) {
	}
}


void wsuSupportsWeakReference::_realGetWeakReference(wsiWeakReference ** ret)
{
    m_WeakRef.QueryInterface( ret );
}

