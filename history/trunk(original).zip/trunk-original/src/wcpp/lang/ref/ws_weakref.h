#pragma once

#include <wcpp/lang/ws_ptr.h>
#include "wsiWeakReference.h"
#include "wsiSupportsWeakReference.h"


template<typename T>
class ws_weakref
{
private:

    ws_ptr<wsiWeakReference> mWeakRef;

public:

    ws_weakref(void)
    {
    }

    ws_weakref(T * init)
    {
        ws_ptr<wsiInterface> interf( init );
        ws_ptr<wsiSupportsWeakReference> swr;
        interf->QueryInterface( swr.GetIID(), (void**) swr.GetPtr2() );
        swr->GetWeakReference( mWeakRef.GetPtr2() );
    }

    ws_weakref(const ws_weakref & init)
    {
        mWeakRef = init.mWeakRef;
    }

    ~ws_weakref(void)
    {
    }

    const ws_weakref & operator=(T * src)
    {
        ws_ptr<wsiInterface> interf( src );
        ws_ptr<wsiSupportsWeakReference> swr;
        interf->QueryInterface( swr.GetIID(), (void**) swr.GetPtr2() );
        swr->GetWeakReference( mWeakRef.GetPtr2() );
        return (*this);
    }

    const ws_weakref & operator=(const ws_weakref & src)
    {
        mWeakRef = src.mWeakRef;
        return (*this);
    }

    void Get(T ** ret)
    {
        mWeakRef->Get( T::sIID, ret );
    }

};

