#pragma once
#include "wsiReference.h"


class wsiWeakReference : public wsiReference
{
public:
    static const ws_iid sIID;
};

