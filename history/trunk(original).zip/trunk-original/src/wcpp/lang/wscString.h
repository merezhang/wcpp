#pragma once

#include "wscObject.h"
#include "wsiString.h"
#include "ws_implements.h"
#include "ws_ptr.h"
#include "wscClass.h"


struct _StringBuffer;


#define WS_IMPL_wsiVString		\
	public:	                    \
	virtual const ws_char * const GetBuffer(void) const {return _realGetBuffer();}	\
	virtual const ws_int          GetLength(void) const {return _realGetLength();}	\
	virtual void  SetString(const ws_char * const buffer, const ws_int length) { _realSetString(buffer,length); }	\
	virtual void  SetString(const ws_char * const buffer)                      { _realSetString(buffer); }	        \
	virtual void  SetString(wsiCString * src)                                  { _realSetString(src); }	            \


class wscString : public wscObject, public wsiVString
{
	WS_IMPL_wsiObject
	WS_IMPL_wsiVString

    WS_IMPL_GET_CLASS( "wcpp.lang.wscString" )

public:
	static wscString * New(void);
	static wscString * New(const ws_char* const pstr);
	static wscString * New(const ws_char* const pstr, const ws_int len);
	static wscString * New(wsiCString * aString);

private:
    wscString(const wscString & src);
    wscString(const ws_char* const pstr, const ws_int len);
    const wscString & operator=(const wscString & src);

public:
	~wscString(void);

protected:

	const ws_char* const _realGetBuffer(void) const;
	const ws_int         _realGetLength(void) const;

	void                 _realSetString(const ws_char* const buf);
	void                 _realSetString(const ws_char* const buf, const ws_int len);
	void                 _realSetString(wsiCString * src);

private:

	// assistance

	static _StringBuffer * _NewBuffer(const ws_int aStrLen);
    void _private_SetString(const ws_char * const buf, const ws_int len);

private:

	_StringBuffer * m_psbuf;

};



