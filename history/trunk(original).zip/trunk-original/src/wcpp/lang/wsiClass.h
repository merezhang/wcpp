// wsiClass.h
#ifndef __wsiClass_h__
#define __wsiClass_h__

#include "wsiObject.h"


class wsiVString;


#define WS_IID_OF_wsiClass      \
    { 0x87af473a, 0xedfe, 0x40d2, { 0x9a, 0x34, 0xea, 0x52, 0x53, 0x5d, 0xf0, 0x15 } }
// {87AF473A-EDFE-40d2-9A34-EA52535DF015}


class wsiClass : public wsiObject
{
public:
	static const ws_iid sIID;
public:
	virtual void GetName(wsiVString * rString) = 0;
};


#endif // __wsiClass_h__
