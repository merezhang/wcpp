// wscString.cpp
#include "wscString.h"
#include "_StringBuffer.h"
#include <wcpp/wspr/wspr.h>


wscString * wscString::New(void)
{
    return ( new wscString(WS_NULL,0) );
}


wscString * wscString::New(const ws_char* const buf)
{
    const ws_int len = (buf==WS_NULL) ? 0 : wspr::ws_strlen(buf);
    return ( new wscString(buf,len) );
}


wscString * wscString::New(wsiCString * aString)
{
    if (aString) {
	    const ws_int    len = aString->GetLength();
	    const ws_char*  buf = aString->GetBuffer();
	    return ( new wscString(buf,len) );
    }
    else {
        return WS_NULL;
    }
}


wscString * wscString::New(const ws_char* const buf, const ws_int len)
{
	return ( new wscString(buf,len) );
}




wscString::wscString(const ws_char* const buf, const ws_int len) : m_psbuf(WS_NULL)
{
	_StringBuffer * sbuf = WS_NULL;
	if (len>0) sbuf = _NewBuffer( len );
	if (sbuf) sbuf->SetString(buf,len);
	m_psbuf = sbuf;
}


wscString::~wscString(void)
{
	_StringBuffer * p = m_psbuf;
	m_psbuf = WS_NULL;
	if (p) _StringBuffer::Delete( p );
}





// implements wsiVString


void wscString::_realSetString(const ws_char *const buf)
{
	ws_int len = 0;
    if (buf) len = wspr::ws_strlen( buf );
	_realSetString( buf, len );
}


const ws_char * const wscString::_realGetBuffer(void) const
{
	_StringBuffer * sbuf = m_psbuf;
	if (sbuf)
		return sbuf->GetBuffer();
	return "";
}


const ws_int wscString::_realGetLength(void) const
{
	_StringBuffer * sbuf = m_psbuf;
	if (sbuf)
		return sbuf->GetLength();
	return 0;
}


void wscString::_realSetString(const ws_char * const buf, const ws_int len)
{
    _private_SetString( buf, len );
}


void wscString::_private_SetString(const ws_char * const buf, const ws_int len)
{
	_StringBuffer * oldsbuf = m_psbuf;
	_StringBuffer * delsbuf = WS_NULL;
	_StringBuffer * savsbuf = WS_NULL;
	if (oldsbuf) {
		if (oldsbuf->GetCapability() < len) {
			savsbuf = _NewBuffer( len );
			delsbuf = oldsbuf;
		} else {
			savsbuf = oldsbuf;
		}
	} else {
		savsbuf = _NewBuffer( len );
	}
	if (savsbuf) savsbuf->SetString(buf,len);
	if (delsbuf) _StringBuffer::Delete( delsbuf );
	m_psbuf = savsbuf;
}


_StringBuffer * wscString::_NewBuffer(const ws_int aStrLen)
{
	if (aStrLen <= 0) return WS_NULL;

	const ws_int rLen = ( (aStrLen>8) ? (aStrLen*2) : 16 );

	return ( _StringBuffer::New(rLen) );
}


void wscString::_realSetString(wsiCString *src)
{
    ws_ptr<wsiCString> p( src );
    try {
        const ws_char * buf = p->GetBuffer();
        ws_int          len = p->GetLength();
        _private_SetString( buf, len );
    }
    catch (...) {
        _private_SetString( "", 0 );
    }
}

