#include "ws_str.h"
#include "wscString.h"


/*
**********************************************************************************************************************
*   ws_str
**********************************************************************************************************************
*/


ws_str::t_wsiVString_ptr::t_wsiVString_ptr(void) : m_p(WS_NULL)
{
}


ws_str::t_wsiVString_ptr::~t_wsiVString_ptr(void)
{
    wsiVString * p = m_p;
    m_p = WS_NULL;
    if (p) p->Release();
}


wsiVString * ws_str::t_wsiVString_ptr::getPtr(void)
{
    wsiVString * ret = m_p;
    if (ret==WS_NULL) {
        ret = wscString::New();
        ret->AddRef();
        m_p = ret;
    }
    return ret;
}


wsiVString * ws_str::t_wsiVString_ptr::getPtrNoCreate() const
{
    return m_p;
}


/*
**********************************************************************************************************************
*   ws_str
**********************************************************************************************************************
*/


ws_str::ws_str(void)
{
}


ws_str::ws_str(const ws_char *const src)
{
    try {
        if (src) {
            if (src[0]) {
                ws_ptr<wsiVString> p( mPtr.getPtr() );
                p->SetString( src );
            }
        }
    }
    catch (...) {
    }
}


ws_str::ws_str(const ws_str &src)
{
    try {
        ws_ptr<wsiCString> s( src.mPtr.getPtrNoCreate() );
        const ws_char* const buf = s->GetBuffer();
        const ws_int         len = s->GetLength();
        _SetString( buf, len );
    }
    catch (...) {
    }
}


ws_str::ws_str(wsiCString *src)
{
    try {
        ws_ptr<wsiCString> s( src );
        const ws_char* const buf = s->GetBuffer();
        const ws_int         len = s->GetLength();
        _SetString( buf, len );
    }
    catch (...) {
    }
}


ws_str::~ws_str(void)
{
}


void ws_str::SetString(const ws_char * const buf, ws_int len)
{
    _SetString( buf, len );
}


const ws_str & ws_str::operator =(const ws_str &src)
{
    try {
        ws_ptr<wsiCString> s( src.mPtr.getPtrNoCreate() );
        const ws_char* const buf = s->GetBuffer();
        const ws_int         len = s->GetLength();
        _SetString( buf, len );
    }
    catch (...) {
        _SetString( "", 0 );
    }
    return (*this);
}


void ws_str::_SetString(const ws_char *const buf, ws_int len) throw ()
{
    try {
        if ((len <= 0) || (buf == WS_NULL)) {
            ws_ptr<wsiVString> p( mPtr.getPtrNoCreate() );
            p->SetString( "", 0 );
        }
        else {
            ws_ptr<wsiVString> p( mPtr.getPtr() );
            p->SetString( buf, len );
        }
    }
    catch (...) {
    }
}


ws_str::operator const ws_char * const (void) const
{
    ws_ptr<wsiCString> p( mPtr.getPtrNoCreate() );
    try {
        return p->GetBuffer();
    }
    catch (...) {
        return "";
    }
}


ws_str::operator wsiCString * (void) const
{
    return mPtr.getPtrNoCreate();
}


ws_str::operator wsiVString * (void)
{
    return mPtr.getPtr();
}

