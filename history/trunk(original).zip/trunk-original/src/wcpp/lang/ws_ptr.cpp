#include "ws_ptr.h"
#include "wscThrowable.h"



void _ws_ptr_throw::ThrowNullPointerException(const ws_char * const msg)
{
    WS_THROW( wseNullPointerException , msg );
}


