#pragma once

#include "ws_ptr.h"
#include "wsiString.h"


class ws_str
{
public:
    ws_str(void);
    ws_str(wsiCString * src);
    ws_str(const ws_char * const src);
    ws_str(const ws_char * const src, ws_int len);
    ws_str(const ws_str & src);
    ~ws_str(void);

    const ws_str & operator=(const ws_str & src);
    operator const ws_char * const (void) const;
    operator wsiCString * (void) const;
    operator wsiVString * (void);
    wsiCString * operator->(void) const;
    wsiVString * operator->(void);

    void SetString(const ws_char * const buf, ws_int len);

private:

    void _SetString(const ws_char * const buf, ws_int len) throw();

private:

    class t_wsiVString_ptr
    {
    public:
        t_wsiVString_ptr(void);
        ~t_wsiVString_ptr(void);
        wsiVString * getPtr(void);
        wsiVString * getPtrNoCreate(void) const;
    private:
        wsiVString * m_p;
    };

    t_wsiVString_ptr mPtr;

};


