// wsiThrowable.h
#ifndef __wsiThrowable_h__
#define __wsiThrowable_h__

#include "wsiObject.h"


class wsiVString;


#ifdef GetMessage
    #undef GetMessage
#endif


class wsiThrowable : public wsiObject
{
public:
	static const ws_iid sIID;

	virtual void GetMessage(wsiVString * rString) = 0;
	virtual void PrintStackTrace(void) = 0;
	virtual void ToString(wsiVString * rString) = 0;

};




#endif // __wsiThrowable_h__
