#pragma once
#include "wsiobject.h"

class wsiNumber : public wsiObject
{
public:
	static const ws_iid sIID;
};


