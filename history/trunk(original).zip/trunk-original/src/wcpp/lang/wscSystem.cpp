// wscSystem.cpp
#include "wscSystem.h"
#include "wsoLangService.h"
#include <wcpp/lang/ws_ptr.h>


void wscSystem::GetSystemService(wsiSystemService ** ret)
{
    ws_ptr<wsiLangService> ls;
    wsoLangService::GetLangService( ls.GetPtr2() );
    ls->GetSystemService(ret);
}


void wscSystem::GetErr(wsiPrintStream ** ret)
{
    ws_ptr<wsiSystemService> ss;
    GetSystemService( ss.GetPtr2() );
    ss->GetErr(ret);
}


void wscSystem::GetOut(wsiPrintStream ** ret)
{
    ws_ptr<wsiSystemService> ss;
    GetSystemService( ss.GetPtr2() );
    ss->GetOut(ret);
}


void wscSystem::GetIn(wsiInputStream ** ret)
{
    ws_ptr<wsiSystemService> ss;
    GetSystemService( ss.GetPtr2() );
    ss->GetIn(ret);
}


void wscSystem::SetErr(wsiPrintStream *aPrintStream)
{
    ws_ptr<wsiSystemService> ss;
    GetSystemService( ss.GetPtr2() );
    ss->SetErr( aPrintStream );
}


void wscSystem::SetIn(wsiInputStream *aInputStream)
{
    ws_ptr<wsiSystemService> ss;
    GetSystemService( ss.GetPtr2() );
    ss->SetIn( aInputStream );
}


void wscSystem::SetOut(wsiPrintStream *aPrintStream)
{
    ws_ptr<wsiSystemService> ss;
    GetSystemService( ss.GetPtr2() );
    ss->SetOut( aPrintStream );
}

