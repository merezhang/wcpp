#pragma once
#include "wsinumber.h"



class wsiByte : public wsiNumber
{
public:
	static const ws_iid sIID;
};


