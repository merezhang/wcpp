// wsiLong.h

#ifndef __wsiLong_h__
#define __wsiLong_h__

#include "wsiNumber.h"




class wsiLong : public wsiNumber
{
public:

	static const ws_iid sIID;


};




#endif // __wsiLong_h__
