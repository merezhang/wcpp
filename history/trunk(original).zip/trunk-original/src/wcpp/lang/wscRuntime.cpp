#include "wscRuntime.h"
#include "wsoLangService.h"
#include <wcpp/lang/ws_ptr.h>


void wscRuntime::GetRuntime(wsiRuntime ** ret)
{
    ws_ptr<wsiLangService> ls;
    wsoLangService::GetLangService(ls.GetPtr2());
    ws_ptr<wsiRuntimeService> rs;
    ls->GetRuntimeService(rs.GetPtr2());
    rs->GetRuntime(ret);
}

