#pragma once
#include "wsiobject.h"




class wsiUUID : public wsiObject
{
public:
	static const ws_iid sIID;
};



