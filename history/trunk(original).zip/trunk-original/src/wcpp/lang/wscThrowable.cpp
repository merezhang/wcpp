// wscThrowable.cpp

#include "wscThrowable.h"



const ws_char* const wscThrowable::sSTR = "wcpp.lang.wscThrowable";
const ws_char* const wseError::sSTR     = "wcpp.lang.wseError";
const ws_char* const wseException::sSTR = "wcpp.lang.wseException";

const ws_char* const wseRuntimeException::sSTR                = "wcpp.lang.wseRuntimeException";
const ws_char* const wseNullPointerException::sSTR            = "wcpp.lang.wseNullPointerException";
const ws_char* const wseClassCastException::sSTR              = "wcpp.lang.wseClassCastException";
const ws_char* const wseUnsupportedOperationException::sSTR   = "wcpp.lang.wseUnsupportedOperationException";
const ws_char* const wseIllegalThreadStateException::sSTR     = "wcpp.lang.wseIllegalThreadStateException";
const ws_char* const wseClassNotFoundException::sSTR          = "wcpp.lang.wseClassNotFoundException";
const ws_char* const wseNumberFormatException::sSTR           = "wcpp.lang.wseNumberFormatException";
const ws_char* const wseIllegalArgumentException::sSTR        = "wcpp.lang.wseIllegalArgumentException";



wscThrowable::wscThrowable(const ws_char * const aStr, const ws_char * const aMsg, const ws_char* const aFileName, ws_int aLine)
:   m_string (aStr),
    m_msg    (aMsg),
    m_file   (aFileName),
    m_line   (aLine)
{
}


wscThrowable::~wscThrowable(void)
{
}


void wscThrowable::_realGetMessage(wsiVString * rString)
{
//    if (rString==WS_NULL) WS_THROW( wseNullPointerException , "" );
    if (rString) rString->SetString( m_msg );
}


void wscThrowable::_realPrintStackTrace(void)
{
}


void wscThrowable::_realToString(wsiVString * rString)
{
//    if (rString==WS_NULL) WS_THROW( wseNullPointerException , "" );
    if (rString) rString->SetString( m_string );
}

