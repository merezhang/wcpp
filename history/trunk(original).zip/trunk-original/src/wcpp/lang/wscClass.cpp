// wscClass.cpp
#include "wscClass.h"


void wscClass::_realGetName(wsiVString * rString)
{
    ws_ptr<wsiVString> str( rString );
    str->SetString( m_name );
}

