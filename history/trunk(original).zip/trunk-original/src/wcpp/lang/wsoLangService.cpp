/* 
 * File:   wsolangservice.cpp
 * Author: Xukun
 * 
 * Created on 2009��7��17��, ����2:09
 */

#include "wsoLangService.h"
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/wscom/wsiServiceManager.h>
#include <wcpp/wscom/WSCOM.h>


void wsoLangService::GetLangService(wsiLangService ** ret)
{
    static ws_ptr<wsiLangService> sLS;
    if (sLS.IsNull()) {
        ws_ptr<wsiServiceManager> sm;
        WSCOM::WS_GetServiceManager( sm.GetPtr2() );
        ws_ptr<wsiLangService> ls;
        sm->GetService( wsoLangService::sCID, ls.GetIID(), (void**) ls.GetPtr2() );
        sLS = ls;
    }
    sLS.QueryInterface( ret );
}

