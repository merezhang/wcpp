// wscInterface.h
#ifndef __wscInterface_h__
#define __wscInterface_h__

#include "wsiInterface.h"




#define WS_IMPL_wsiInterface		\
	public:	\
	virtual ws_int  AddRef(void) {return _realAddRef();}	\
	virtual void    QueryInterface(const ws_iid & iid, void ** ret) {_realQueryInterface(iid,ret);}	\
	virtual ws_int  Release(void) {return _realRelease();}




#endif // __wsxInterface_h__
