#pragma once

#include "wsiObject.h"


class wsiArray : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    virtual ws_long GetSize(void) = 0;
    virtual void    GetItem(ws_long index, const ws_iid & iid, void ** ret) = 0
    virtual void    SetItem(ws_long index, wsiObject * obj) = 0
};

