// wsiObject.h
#ifndef __wsiObject_h__
#define __wsiObject_h__

#include "wsiInterface.h"




#define WS_IID_OF_wsiObject			\
	{ 0x3f45a92b, 0xa7d5, 0x4d93, { 0x94, 0x6c, 0x37, 0x3e, 0x56, 0xa8, 0xc1, 0x7b } }
// {3F45A92B-A7D5-4d93-946C-373E56A8C17B}




class wsiClass;
class wsiVString;
class wsiCString;




class wsiObject : public wsiInterface
{
public:

	static const ws_iid sIID;

	virtual ws_boolean   Equals    (wsiObject * obj)             = 0;
	virtual void         GetClass  (wsiClass ** rClass)          = 0;
	virtual ws_int       HashCode  (void)                        = 0;
	virtual void         Notify    (void)                        = 0;
	virtual void         NotifyAll (void)                        = 0;
	virtual void         ToString  (wsiVString * rString)        = 0;
	virtual void         Wait      (void)                        = 0;
	virtual void         Wait      (ws_long timeout)             = 0;
	virtual void         Wait      (ws_long timeout, ws_int nanos) = 0;

};




#endif // __wsiObject_h__
