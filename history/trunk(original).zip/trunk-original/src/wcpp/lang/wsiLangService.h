#pragma once
#include <wcpp/lang/wsiObject.h>


class wsiRunnable;
class wsiThread;
class wsiCString;
class wsiRuntime;
class wsiPrintStream;
class wsiInputStream;


#define WS_IID_OF_wsiLangService		\
	{ 0x7c0fd2cd, 0xba82, 0x46e4, { 0xb7, 0x2f, 0xeb, 0xc1, 0xbb, 0xc6, 0x1a, 0x59 } }
// {7C0FD2CD-BA82-46e4-B72F-EBC1BBC61A59}


class wsiRuntimeService : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    virtual void GetRuntime(wsiRuntime ** ret) = 0;
};


class wsiSystemService : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    virtual void GetErr(wsiPrintStream ** ret) = 0;
    virtual void GetIn (wsiInputStream ** ret) = 0;
    virtual void GetOut(wsiPrintStream ** ret) = 0;
    virtual void SetErr(wsiPrintStream * aPrintStream) = 0;
    virtual void SetIn (wsiInputStream * aInputStream) = 0;
    virtual void SetOut(wsiPrintStream * aPrintStream) = 0;
};


class wsiThreadService : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    virtual void NewThread(wsiRunnable * target, wsiCString * name, wsiThread ** ret) = 0;
    virtual void Sleep(ws_long millis) = 0;
};


class wsiLangService : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    virtual void GetRuntimeService(wsiRuntimeService ** ret) = 0;
    virtual void GetSystemService(wsiSystemService ** ret) = 0;
    virtual void GetThreadService(wsiThreadService ** ret) = 0;
};

