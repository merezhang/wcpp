// wscThrowable.h
#ifndef __wscThrowable_h__
#define __wscThrowable_h__

#include "ws_ptr.h"
#include "wscObject.h"
#include "wsiThrowable.h"
#include "wsiString.h"
#include "wscClass.h"



#define WS_IMPL_wsiThrowable	\
	public:	\
	virtual void GetMessage(wsiVString * rString) {_realGetMessage(rString);}		\
	virtual void PrintStackTrace(void) {_realPrintStackTrace();}	\




class wscThrowable : public wscObject, public wsiThrowable
{
	WS_IMPL_wsiObject
	WS_IMPL_wsiThrowable
    WS_IMPL_GET_CLASS( "wcpp.lang.wscThrowable" )

private:

	const ws_char* const m_string;
	const ws_char* const m_msg;
	const ws_char* const m_file;
	const ws_int         m_line;

public:

	static const ws_char* const sSTR;

public:

	wscThrowable(const ws_char * const aStr, const ws_char * const aMsg, const ws_char* const aFileName, ws_int aLine);
	~wscThrowable(void);

// implements wsThrowableBase

	virtual void _realGetMessage(wsiVString * rString);
	virtual void _realPrintStackTrace(void);
	virtual void _realToString(wsiVString * rString);

	ws_int _realAddRef(void) { return 1; }
	ws_int _realRelease(void) { return 1; }

};


#define WS_THROW( _exception_class_ , _msg_ )       \
    throw _exception_class_( _exception_class_::sSTR , _msg_ , __FILE__ , __LINE__ );


template <typename _indicator_ , typename _super_>
class wscThrowableEx : public _super_
{
public:

    typedef _super_          super_class;

    static const ws_char* const sSTR;

    wscThrowableEx(const ws_char * const aStr, const ws_char * const aMsg, const ws_char* const aFileName, ws_int aLine)
    : super_class( aStr, aMsg, aFileName, aLine )
    {
    }

    ~wscThrowableEx(void)
    {
    }

    virtual void _realGetClass(wsiClass ** rClass)
    {
        static ws_ptr<wsiClass> sClass( new wscClass( sSTR ) );
        sClass.QueryInterface( rClass );
    }

};


#define WS_THROW_EX_DECLARE( _class_ , _super_ )                         \
    struct _indicator_of_##_class_ {};                                      \
    typedef wscThrowableEx< _indicator_of_##_class_ , _super_ > _class_;    \


// layer 1
WS_THROW_EX_DECLARE( wseError ,     wscThrowable )
WS_THROW_EX_DECLARE( wseException , wscThrowable )


// layer 2
WS_THROW_EX_DECLARE( wseRuntimeException ,       wseException )
WS_THROW_EX_DECLARE( wseClassNotFoundException , wseException )
WS_THROW_EX_DECLARE( wseIllegalAccessException , wseException )
WS_THROW_EX_DECLARE( wseInstantiationException , wseException )
WS_THROW_EX_DECLARE( wseInterruptedException ,   wseException )

WS_THROW_EX_DECLARE( wseNoClassDefFoundError ,  wseError )
WS_THROW_EX_DECLARE( wseVirtualMachineError ,   wseError )


// layer 3
WS_THROW_EX_DECLARE( wseArithmeticException ,            wseRuntimeException )
WS_THROW_EX_DECLARE( wseArrayStoreException ,            wseRuntimeException )
WS_THROW_EX_DECLARE( wseClassCastException ,             wseRuntimeException )
WS_THROW_EX_DECLARE( wseIllegalArgumentException ,       wseRuntimeException )
WS_THROW_EX_DECLARE( wseIllegalMonitorStateException ,   wseRuntimeException )
WS_THROW_EX_DECLARE( wseIllegalStateException ,          wseRuntimeException )
WS_THROW_EX_DECLARE( wseIndexOutOfBoundsException ,      wseRuntimeException )
WS_THROW_EX_DECLARE( wseNegativeArraySizeException ,     wseRuntimeException )
WS_THROW_EX_DECLARE( wseNullPointerException ,           wseRuntimeException )
WS_THROW_EX_DECLARE( wseSecurityException ,              wseRuntimeException )
WS_THROW_EX_DECLARE( wseUnsupportedOperationException ,  wseRuntimeException )

WS_THROW_EX_DECLARE( wseOutOfMemoryError , wseVirtualMachineError )


// layer 4
WS_THROW_EX_DECLARE( wseArrayIndexOutOfBoundsException ,    wseIndexOutOfBoundsException    )
WS_THROW_EX_DECLARE( wseIllegalThreadStateException ,       wseIllegalArgumentException     )
WS_THROW_EX_DECLARE( wseNumberFormatException ,             wseIllegalArgumentException     )
WS_THROW_EX_DECLARE( wseStringIndexOutOfBoundsException ,   wseIndexOutOfBoundsException    )




#endif // __wsThrowable_h__
