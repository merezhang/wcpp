#pragma once
#include "wsinumber.h"




class wsiFloat : public wsiNumber
{
public:
	static const ws_iid sIID;
};



