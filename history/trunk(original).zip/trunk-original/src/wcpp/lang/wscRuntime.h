#pragma once

#include "wscObject.h"
#include "wsiRuntime.h"


#define WS_IMPL_wsiRuntime		\
	public:		\
	virtual void      Exit(ws_int status)	{ _realExit(status); }	\
	virtual ws_long   FreeMemory(void)		{ return _realFreeMemory(); }	\
	virtual void      Gc(void)				{ _realGc(); }	\
	virtual ws_long   TotalMemory(void)		{ return _realTotalMemory(); }	\


class wscRuntime : public wscObject, public wsiRuntime
{
public:
	static void GetRuntime(wsiRuntime ** ret);
};

