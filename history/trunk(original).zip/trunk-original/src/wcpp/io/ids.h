// <wcpp.io/ids.h>


#include "wsiOutputStream.h"
#include "wsiPrintStream.h"


WS_IMPL_IID_OF( wsiOutputStream )
WS_IMPL_IID_OF( wsiPrintStream )

