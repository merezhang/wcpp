#ifndef __wsiDataOutput_h__
#define __wsiDataOutput_h__

#include <wcpp.lang/wsiObject.h>


class wsiDataOutput : public wsiObject
{
public:
    static const ws_iid sIID;
};


#endif // __wsIDataOutput_h__
