﻿#ifndef __wscDataOutputStream_h__
#define __wscDataOutputStream_h__

#include "wscOutputStream.h"
#include "wsiDataOutputStream.h"




class wscDataOutputStream : public wscOutputStream, public wsiDataOutputStream
{
};




#endif // __wsDataOutputStream_h__
