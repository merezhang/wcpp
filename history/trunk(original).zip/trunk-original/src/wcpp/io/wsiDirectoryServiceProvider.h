#pragma once
#include <wcpp/lang/wsiObject.h>


class wsiDirectoryServiceProvider : public wsiObject
{
public:
	static const ws_iid sIID;
public:
    virtual ws_boolean GetFile(wsiCString * prop, wsiFile ** ret) = 0;
};

