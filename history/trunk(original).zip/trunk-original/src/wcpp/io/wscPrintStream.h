#ifndef __wscPrintStream_h__
#define __wscPrintStream_h__

#include "wscOutputStream.h"
#include "wsiPrintStream.h"
#include <wcpp/lang/ws_implements.h>
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/lang/wscClass.h>


#define WS_IMPL_wsiPrintStream		\
	public:	\
	virtual ws_boolean CheckError(void)                     {return _realCheckError();} \
	virtual void       Print(ws_boolean b)                  {return _realPrint(b);}     \
	virtual void       Print(ws_char c)                     {return _realPrint(c);}     \
	virtual void       Print(const ws_char * const s)       {return _realPrint(s);}     \
	virtual void       Print(ws_double d)                   {return _realPrint(d);}     \
	virtual void       Print(ws_float f)                    {return _realPrint(f);}     \
	virtual void       Print(ws_int i)                      {return _realPrint(i);}     \
	virtual void       Print(ws_long l)                     {return _realPrint(l);}     \
	virtual void       Print(wsiObject * obj)               {return _realPrint(obj);}   \
	virtual void       Print(wsiCString * str)              {return _realPrint(str);}   \
	virtual void       PrintLn(void)                        {return _realPrintLn();}    \
	virtual void       PrintLn(ws_boolean x)                {return _realPrintLn(x);}   \
	virtual void       PrintLn(ws_char x)                   {return _realPrintLn(x);}   \
	virtual void       PrintLn(const ws_char * const x)     {return _realPrintLn(x);}   \
	virtual void       PrintLn(ws_double x)                 {return _realPrintLn(x);}   \
	virtual void       PrintLn(ws_float x)                  {return _realPrintLn(x);}   \
	virtual void       PrintLn(ws_int x)                    {return _realPrintLn(x);}   \
	virtual void       PrintLn(ws_long x)                   {return _realPrintLn(x);}   \
	virtual void       PrintLn(wsiObject * x)               {return _realPrintLn(x);}   \
	virtual void       PrintLn(wsiCString * x)              {return _realPrintLn(x);}   \


class wscPrintStream : public wscOutputStream, public wsiPrintStream
{
	WS_IMPL_wsiObject
	WS_IMPL_wsiOutputStream
	WS_IMPL_wsiPrintStream

	WS_IMPL_GET_INTERFACE_BEGIN
		WS_IMPL_GET_INTERFACE_BODY( wsiPrintStream )
	WS_IMPL_GET_INTERFACE_END

    WS_IMPL_GET_CLASS( "wcpp.io.wscPrintStream" )

public:
    typedef wscOutputStream super_class;
private:

	wsiOutputStream * mOut;
	ws_boolean        mErr;

public:

	wscPrintStream(wsiOutputStream * out);
	~wscPrintStream(void);

protected:

	virtual void       _realSetError(void);
	virtual ws_boolean _realCheckError(void);
	virtual void       _realClose(void);
	virtual void       _realFlush(void);
	virtual void       _realWrite(const void * const buf, const ws_int len);
	virtual void       _realWrite(ws_int b);

	virtual void       _realPrint(ws_boolean b);
	virtual void       _realPrint(ws_char c);
	virtual void       _realPrint(const ws_char * const s);
	virtual void       _realPrint(ws_double d);
	virtual void       _realPrint(ws_float f);
	virtual void       _realPrint(ws_int i);
	virtual void       _realPrint(ws_long l);
	virtual void       _realPrint(wsiObject * obj);
	virtual void       _realPrint(wsiCString * str);

	virtual void       _realPrintLn(void);
	virtual void       _realPrintLn(ws_boolean x);
	virtual void       _realPrintLn(ws_char x);
	virtual void       _realPrintLn(const ws_char * const x);
	virtual void       _realPrintLn(ws_double x);
	virtual void       _realPrintLn(ws_float x);
	virtual void       _realPrintLn(ws_int x);
	virtual void       _realPrintLn(ws_long x);
	virtual void       _realPrintLn(wsiObject * x);
	virtual void       _realPrintLn(wsiCString * x);


};




#endif // __wsPrintStream_h__
