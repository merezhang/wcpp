﻿#ifndef __wscInputStreamReader_h__
#define __wscInputStreamReader_h__

#include "wscReader.h"
#include "wsiInputStreamReader.h"




class wscInputStreamReader : public wscReader, public wsiInputStreamReader
{
};




#endif // __wsInputStreamReader_h__
