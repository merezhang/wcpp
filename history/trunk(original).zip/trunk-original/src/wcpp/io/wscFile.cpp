#include "wscFile.h"
#include <wcpp/lang/wscThrowable.h>
#include <wcpp/lang/wscString.h>


wscFile::wscFile(wsiFile * parent, wsiCString * child)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


wscFile::wscFile(wsiCString * pathname)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


wscFile::wscFile( wsiCString * parent, wsiCString * child)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


wscFile::wscFile(wsiURI * uri)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


wscFile::~wscFile(void)
{
}




ws_boolean wscFile::_realCanExecute(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realCanRead(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realCanWrite(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_int     wscFile::_realCompareTo(wsiFile * pathname) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realCreateNewFile(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realDelete(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realDeleteOnExit(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realEquals(wsiObject * obj) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realExists(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetAbsoluteFile(wsiFile ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetAbsolutePath(wsiVString * ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetCanonicalFile(wsiFile ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetCanonicalPath(wsiVString * ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_long    wscFile::_realGetFreeSpace(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetName(wsiVString * ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetParent(wsiVString * ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetParentFile(wsiFile ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realGetPath(wsiVString * ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_long    wscFile::_realGetTotalSpace(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_long    wscFile::_realGetUsableSpace(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_int     wscFile::_realHashCode(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realIsAbsolute(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realIsDirectory(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realIsFile(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realIsHidden(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_long    wscFile::_realLastModified(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_long    wscFile::_realLength(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realList(wsiStringArray ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realList(wsiFilenameFilter * filter, wsiStringArray ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realListFiles(wsiFileArray ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realListFiles(wsiFileFilter * filter, wsiFileArray ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realListFiles(wsiFilenameFilter * filter, wsiFileArray ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realMkdir(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realMkdirs(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realRenameTo(wsiFile * dest) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetExecutable(ws_boolean executable) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetExecutable(ws_boolean executable, ws_boolean ownerOnly) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetLastModified(ws_long time) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetReadable(ws_boolean readable) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetReadable(ws_boolean readable, ws_boolean ownerOnly) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetReadOnly(void) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetWritable(ws_boolean writable) { WS_THROW( wseUnsupportedOperationException , "" ); }

ws_boolean wscFile::_realSetWritable(ws_boolean writable, ws_boolean ownerOnly) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realToString(wsiVString * ret) { WS_THROW( wseUnsupportedOperationException , "" ); }

void       wscFile::_realToURI(wsiURI ** ret) { WS_THROW( wseUnsupportedOperationException , "" ); }



