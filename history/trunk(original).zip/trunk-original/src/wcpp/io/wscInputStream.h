﻿// wscInputStream.h
#ifndef __wscInputStream_h__
#define __wscInputStream_h__

#include <wcpp/lang/wscObject.h>
#include "wsiInputStream.h"
#include <wcpp/lang/ws_implements.h>



#define WS_IMPL_wsiInputStream		\
	public:		\
	virtual ws_int     Available     (void)                              { return _realAvailable(); }		\
	virtual void       Close         (void)                              { _realClose(); }					\
	virtual void       Mark          (ws_int readlimit)                  { _realMark(readlimit); }			\
	virtual ws_boolean MarkSupported (void)                              { return _realMarkSupported(); }	\
	virtual ws_int     Read          (void)                              { return _realRead0(); }			\
	virtual ws_int     Read          (void* const buf, const ws_int len) { return _realRead2(buf,len); }	\
	virtual void       Reset         (void)                              { _realReset(); }					\
	virtual ws_long    Skip          (ws_long n)                         { return _realSkip(n); }			\




class wscInputStream : public wscObject, public wsiInputStream
{
	WS_IMPL_wsiObject
	WS_IMPL_wsiInputStream
    WS_IMPL_GET_CLASS( "wcpp.io.wscInputStream" )
public:

	wscInputStream(void) {}

protected:

	virtual ws_int     _realAvailable     (void)                              {return 0;}
	virtual void       _realClose         (void)                              {}
	virtual void       _realMark          (ws_int readlimit)                  {}
	virtual ws_boolean _realMarkSupported (void)                              {return WS_FALSE;}
	virtual ws_int     _realRead0         (void)                              {return -1;}
	virtual ws_int     _realRead2         (void* const buf, const ws_int len) {return 0;}
	virtual void       _realReset         (void)                              {}
	virtual ws_long    _realSkip          (ws_long n)                         {return 0;}

};




#endif // __wsInputStream_h__
