#pragma once
#include <wcpp/lang/wscobject.h>
#include "wsiNetwork.h"


#define WS_ContractID_OF_wsoNetwork		"xxxxxxxxxxxxxxxxxxxxxxx"
#define WS_CID_OF_wsoNetwork		\
	{ 0x379c9069, 0x554a, 0x41bb, { 0x97, 0xad, 0x7f, 0x92, 0x9a, 0x19, 0xaf, 0x3a } }
// {379C9069-554A-41bb-97AD-7F929A19AF3A}


class wsoNetwork : public wscObject, public wsiNetwork
{
public:
    static const ws_cid sCID;
public:
    wsoNetwork(void);
    ~wsoNetwork(void);
};

