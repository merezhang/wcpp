#pragma once

#include "wsiURI.h"
#include <wcpp/lang/wscObject.h>


class wscURI : public wscObject, public wsiURI
{
public:

    wscURI( wsiCString * str );

    wscURI( wsiCString * scheme,
            wsiCString * ssp,
            wsiCString * fragment );

    wscURI( wsiCString * scheme,
            wsiCString * userInfo,
            wsiCString * host,
            ws_int port,
            wsiCString * path,
            wsiCString * query,
            wsiCString * fragment );

    wscURI( wsiCString * scheme,
            wsiCString * host,
            wsiCString * path,
            wsiCString * fragment );

    wscURI( wsiCString * scheme,
            wsiCString * authority,
            wsiCString * path,
            wsiCString * query,
            wsiCString * fragment );

};

