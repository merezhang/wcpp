#pragma once

#include <wcpp/wscom/wscModule.h>


class wscNetworkModule : public wscModule
{
    WS_IMPL_GET_CLASS( "wcpp.net.wscNetworkModule" )
public:
    wscNetworkModule(void);
    ~wscNetworkModule(void);
};

