#pragma once
#include <wcpp/lang/wscThrowable.h>


WS_THROW_EX_DECLARE( wseWSCOMException , wseException )

WS_THROW_EX_DECLARE( wseLoadModuleException , wseWSCOMException )

