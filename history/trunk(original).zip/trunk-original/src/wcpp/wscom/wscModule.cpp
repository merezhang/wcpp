#include "wscModule.h"
#include <wcpp/lang/ws_ptr.h>


wscModule::wscModule(void)
{
}


wscModule::~wscModule(void)
{
}


void wscModule::GetCurrentModule(wsiModule ** ret)
{
    ws_ptr<wsiModule> md( NewCurrentModule() );
    md.QueryInterface( ret );
}



	
void wscModule::_realGetClassObject(wsiComponentManager * aCompMgr, const ws_cid & aCID, const ws_iid & aIID, void ** ret)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


void wscModule::_realRegisterSelf(wsiComponentManager * aCompMgr, wsiFile * aLocation, wsiCString * aLoaderStr, wsiCString * aType)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


void wscModule::_realUnregisterSelf(wsiComponentManager * aCompMgr, wsiFile * aLocation, wsiCString * aLoaderStr)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


ws_boolean wscModule::_realCanUnload(wsiComponentManager * aCompMgr)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}



