#pragma once
#include <wcpp\lang\wsiobject.h>




class wsiClassInfo : public wsiObject
{
public:
	static const ws_iid sIID;
};



