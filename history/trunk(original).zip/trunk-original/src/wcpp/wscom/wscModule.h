#pragma once
#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/wscThrowable.h>
#include "wsiModule.h"




#define WS_IMPL_wsiModule		\
	public:		\
	virtual void       GetClassObject(wsiComponentManager * aCompMgr, const ws_cid & aCID, const ws_iid & aIID, void ** ret)\
										{_realGetClassObject(aCompMgr,aCID,aIID,ret);}\
	virtual void       RegisterSelf  (wsiComponentManager * aCompMgr, wsiFile * aLocation, wsiCString * aLoaderStr, wsiCString * aType)\
										{_realRegisterSelf(aCompMgr,aLocation,aLoaderStr,aType);}\
	virtual void       UnregisterSelf(wsiComponentManager * aCompMgr, wsiFile * aLocation, wsiCString * aLoaderStr)\
										{_realUnregisterSelf(aCompMgr,aLocation,aLoaderStr);}\
	virtual ws_boolean CanUnload     (wsiComponentManager * aCompMgr)\
										{return _realCanUnload(aCompMgr);}\




class wscModule : public wscObject, public wsiModule
{
    WS_IMPL_wsiObject
    WS_IMPL_wsiModule

public:
	wscModule(void);
	~wscModule(void);

private:

	static wsiModule * NewCurrentModule(void);

public:

	static void GetCurrentModule(wsiModule ** ret);

	virtual void       _realGetClassObject(wsiComponentManager * aCompMgr, const ws_cid & aCID, const ws_iid & aIID, void ** ret);
	virtual void       _realRegisterSelf  (wsiComponentManager * aCompMgr, wsiFile * aLocation, wsiCString * aLoaderStr, wsiCString * aType);
	virtual void       _realUnregisterSelf(wsiComponentManager * aCompMgr, wsiFile * aLocation, wsiCString * aLoaderStr);
	virtual ws_boolean _realCanUnload     (wsiComponentManager * aCompMgr);

};


// Exported Function from module dll to Create the nsIModule
#define WS_GET_MODULE_SYMBOL "WSGetModule"


extern "C" WS_EXPORT void WS_CALLBACK 
WSGetModule(
			wsiComponentManager *aCompMgr,
            wsiFile* location,
            wsiModule** return_cobj
			);


typedef void (WS_CALLBACK * ws_proc_WSGetModule)(
			wsiComponentManager *aCompMgr,
            wsiFile* location,
            wsiModule** return_cobj
			);



