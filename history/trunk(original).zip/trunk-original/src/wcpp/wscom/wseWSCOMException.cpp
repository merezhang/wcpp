#include "wseWSCOMException.h"




const ws_char* const wseLoadModuleException::sSTR = "wcpp.wscom.main.wseLoadModuleException";
const ws_char* const wseWSCOMException::sSTR      = "wcpp.wscom.main.wseWSCOMException";



