#pragma once
#include <wcpp/lang/wscObject.h>
#include <wcpp/wscom/wsiMemory.h>


#define WS_CID_OF_wscMemory		\
	{ 0x9b99e318, 0x1213, 0x42de, { 0xab, 0x86, 0xa, 0xb8, 0x74, 0x57, 0xe6, 0xa5 } }
// {9B99E318-1213-42de-AB86-0AB87457E6A5}


#define WS_IMPL_wsiMemory		\
	public:		\
	virtual void *     Alloc(ws_int size)                  {return _realAlloc       (size);       }\
	virtual void *     Realloc(void * ptr, ws_int newSize) {return _realRealloc     (ptr,newSize);}\
	virtual void       Free(void * ptr)                    {       _realFree        (ptr);        }\
	virtual void       HeapMinimize(ws_boolean immediate)  {       _realHeapMinimize(immediate);  }\
	virtual ws_boolean IsLowMemory(void)                   {return _realIsLowMemory ();           }\


class wscMemory : public wsiMemory
{
public:

	wscMemory(void);
	~wscMemory(void);

protected:

	virtual void *     _realAlloc(ws_int size) ;
	virtual void *     _realRealloc(void * ptr, ws_int newSize) ;
	virtual void       _realFree(void * ptr) ;
	virtual void       _realHeapMinimize(ws_boolean immediate) ;
	virtual ws_boolean _realIsLowMemory(void) ;

};


