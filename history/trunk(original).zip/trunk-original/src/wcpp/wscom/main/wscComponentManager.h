#pragma once
#include <wcpp/lang/wscObject.h>
#include <wcpp/wscom/wsiComponentManager.h>
#include <map>
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/wscom/wsiFactory.h>


class wsiModuleHolder;
class wsiComponentRegistrarEx;


#define WS_IMPL_wsiComponentManager		\
	public:		\
	virtual void GetClassObject             (const ws_cid & aCID, const ws_iid & aIID, void ** ret)                             { _realGetClassObject             (aCID,aIID,ret);                  }\
	virtual void GetClassObjectByContractID (wsiCString * aContractID, const ws_iid & aIID, void ** ret)                        { _realGetClassObjectByContractID (aContractID,aIID,ret);           }\
	virtual void CreateInstance             (const ws_cid & aCID, wsiObject * aDelegate, const ws_iid & aIID, void ** ret)      { _realCreateInstance             (aCID,aDelegate,aIID,ret);        }\
	virtual void CreateInstanceByContractID (wsiCString * aContractID, wsiObject * aDelegate, const ws_iid & aIID, void ** ret) { _realCreateInstanceByContractID (aContractID,aDelegate,aIID,ret); }\




class wscComponentManager : public wsiComponentManager
{
public:

	wscComponentManager(void);
	~wscComponentManager(void);

protected:

	virtual void _realGetClassObject              (const ws_cid & aCID, const ws_iid & aIID, void ** ret);
	virtual void _realGetClassObjectByContractID  (wsiCString * aContractID, const ws_iid & aIID, void ** ret);
	virtual void _realCreateInstance              (const ws_cid & aCID, wsiObject * aDelegate, const ws_iid & aIID, void ** ret);
	virtual void _realCreateInstanceByContractID  (wsiCString * aContractID, wsiObject * aDelegate, const ws_iid & aIID, void ** ret);

private:

	void AddModuleHolder       (const ws_cid & aClass, wsiModuleHolder *  aModuleHolder);
	void GetModuleHolder       (const ws_cid & aClass, wsiModuleHolder ** ret);
	void GetModuleHolderNoLoad (const ws_cid & aClass, wsiModuleHolder ** ret);

private:

	typedef ws_cid                        mh_key;
	typedef ws_ptr<wsiModuleHolder>       mh_value;
	typedef std::map< mh_key, mh_value >  mh_list;

	mh_list m_mhs;

	wsuMutex m_mutexForMHs;

};

