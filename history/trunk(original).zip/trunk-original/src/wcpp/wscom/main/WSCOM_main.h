#pragma once
#include <wcpp/wscom/WSCOM.h>


class WSCOM_main : public WSCOM
{
public:
	WSCOM_main(void);
	~WSCOM_main(void);

    static void InitWSCOM(wsiServiceManager ** result, wsiFile * binDirectory, wsiDirectoryServiceProvider * appFileLocationProvider);
    static void ShutdownWSCOM(wsiServiceManager * servMgr);

};

