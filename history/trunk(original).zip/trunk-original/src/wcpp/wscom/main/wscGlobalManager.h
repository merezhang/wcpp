#pragma once
#include <wcpp/lang/ws_implements.h>
#include <wcpp/lang/wscObject.h>
#include <wcpp/lang/wscClass.h>
#include "wscComponentManager.h"
#include "wscComponentRegistrar.h"
#include "wscMemory.h"
#include "wscServiceManager.h"


class wscGlobalManager : public wscObject,
                            public wscComponentManager,
                            public wscComponentRegistrar,
                            public wscMemory,
                            public wscServiceManager
{
	WS_IMPL_wsiObject
	WS_IMPL_wsiComponentManager
	WS_IMPL_wsiComponentRegistrar
	WS_IMPL_wsiComponentRegistrarEx
	WS_IMPL_wsiMemory
	WS_IMPL_wsiServiceManager

	WS_IMPL_GET_INTERFACE_BEGIN
		WS_IMPL_GET_INTERFACE_BODY(wsiComponentManager)
		WS_IMPL_GET_INTERFACE_BODY(wsiComponentRegistrar)
		WS_IMPL_GET_INTERFACE_BODY(wsiComponentRegistrarEx)
		WS_IMPL_GET_INTERFACE_BODY(wsiMemory)
		WS_IMPL_GET_INTERFACE_BODY(wsiServiceManager)
	WS_IMPL_GET_INTERFACE_END

    WS_IMPL_GET_CLASS( "wcpp.wscom.main.wscGlobalManager" )

public:
    typedef wscObject super_class;
protected:

	wscGlobalManager(void);
	~wscGlobalManager(void);

public:

	static void GetGlobalManager(const ws_iid & aIID, void ** ret);

};



