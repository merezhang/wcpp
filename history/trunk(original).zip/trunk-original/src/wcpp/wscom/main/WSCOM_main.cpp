#include "WSCOM_main.h"
#include "wscGlobalManager.h"
#include <wcpp/wscom/wscModule.h>
#include <wcpp/io/wsiFile.h>


/*
***********************************************************************************************************************
	WSCOM
***********************************************************************************************************************
*/


void WSCOM::_WS_InitWSCOM(wsiServiceManager ** result, wsiFile * binDirectory, wsiDirectoryServiceProvider * appFileLocationProvider)
{
    WSCOM_main::InitWSCOM( result, binDirectory, appFileLocationProvider );
}


void WSCOM::_WS_ShutdownWSCOM(wsiServiceManager * servMgr)
{
    WSCOM_main::ShutdownWSCOM( servMgr );
}


void WSCOM::_GetGlobalManager(const ws_iid & aIID, void ** ret)
{
	wscGlobalManager::GetGlobalManager( aIID, ret );
}


/*
***********************************************************************************************************************
	WSCOM_main
***********************************************************************************************************************
*/


WSCOM_main::WSCOM_main(void)
{
}


WSCOM_main::~WSCOM_main(void)
{
}


void WSCOM_main::InitWSCOM(wsiServiceManager **result, wsiFile *binDirectory, wsiDirectoryServiceProvider *appFileLocationProvider)
{
    ws_ptr<wsiComponentRegistrar> cr;
    WS_GetComponentRegistrar( cr.GetPtr2() );
    ws_ptr<wsiComponentRegistrarEx> cre;
    cr->QueryInterface( cre.GetIID(), (void**)cre.GetPtr2() );

    try {
        cre->LoadRegInfo( binDirectory );
    }
    catch (...) {
        cre->AutoRegister( binDirectory );
        cre->SaveRegInfo( binDirectory );
    }

	ws_ptr<wsiServiceManager> servMgr;
	WS_GetServiceManager( servMgr.GetPtr2() );
	servMgr.QueryInterface( result );
}


void WSCOM_main::ShutdownWSCOM(wsiServiceManager *servMgr)
{
}

