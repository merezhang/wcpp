#pragma once
#include <wcpp/lang/wscObject.h>
#include <wcpp/wscom/wsiServiceManager.h>
#include <map>
#include <wcpp/lang/ws_ptr.h>


#define WS_CID_OF_wscServiceManager		\
	{ 0xa0ee5cd2, 0x5cf5, 0x4f1b, { 0x8f, 0xe7, 0x44, 0x7, 0x5f, 0xfc, 0xda, 0x5f } }
// {A0EE5CD2-5CF5-4f1b-8FE7-44075FFCDA5F}




#define WS_IMPL_wsiServiceManager		\
	public:		\
	virtual void       GetService                         (const ws_cid & aClass,    const ws_iid & aIID, void ** ret) { _realGetService(aClass,aIID,ret); }\
	virtual void       GetServiceByContractID             (wsiCString * aContractID, const ws_iid & aIID, void ** ret) { _realGetServiceByContractID(aContractID,aIID,ret); }\
	virtual ws_boolean IsServiceInstantiated              (const ws_cid & aClass,    const ws_iid & aIID)              { return _realIsServiceInstantiated(aClass,aIID); }\
	virtual ws_boolean IsServiceInstantiatedByContractID  (wsiCString * aContractID, const ws_iid & aIID)              { return _realIsServiceInstantiatedByContractID(aContractID,aIID); }\




class wscServiceManager : public  wsiServiceManager
{
public:

	static const ws_cid sCID;

public:

	wscServiceManager(void);
	~wscServiceManager(void);

protected:

	virtual void       _realGetService                         (const ws_cid & aClass,    const ws_iid & aIID, void ** ret) ;
	virtual void       _realGetServiceByContractID             (wsiCString * aContractID, const ws_iid & aIID, void ** ret) ;
	virtual ws_boolean _realIsServiceInstantiated              (const ws_cid & aClass,    const ws_iid & aIID)              ;
	virtual ws_boolean _realIsServiceInstantiatedByContractID  (wsiCString * aContractID, const ws_iid & aIID)              ;

private:

	void FindService(const ws_cid & aClass, wsiObject ** ret);
	void AddService (const ws_cid & aClass, wsiObject * obj);

private:

	typedef ws_cid             service_key;
	typedef ws_ptr<wsiObject>  service_value;
	typedef std::map< service_key , service_value > service_list;

	service_list m_services;

	wsuMutex m_mutexForServiceList;

};



