#include "wscComponentManager.h"
#include <wcpp/wscom/wsiComponentRegistrar.h>
#include <wcpp/wscom/WSCOM.h>
#include <wcpp/wspr/wsuSingleLock.h>
#include <wcpp/io/wsiFile.h>
#include <wcpp/lang/wscString.h>
#include <wcpp/lang/wscThrowable.h>
#include <wcpp/lang/service/wscLangService.h>
#include "wsiModuleHolder.h"
#include "wscMainModule.h"
#include "wsiComponentRegistrarEx.h"
#include "wscSubModuleHolder.h"


/*
**************************************************************************************************************
*   wscMainModuleHolder
**************************************************************************************************************
*/


class wscMainModuleHolder : public wscObject, public wsiModuleHolder
{
    WS_IMPL_wsiObject
    WS_IMPL_GET_CLASS( "wcpp.wscom.main.wscMainModuleHolder" )
public:
    wscMainModuleHolder(void);
    ~wscMainModuleHolder(void);
    virtual void GetModule(wsiModule ** ret);
};


wscMainModuleHolder::wscMainModuleHolder(void)
{
}


wscMainModuleHolder::~wscMainModuleHolder(void)
{
}


void wscMainModuleHolder::GetModule(wsiModule ** ret)
{
    wscMainModule::GetCurrentModule( ret );
}


/*
**************************************************************************************************************
*   wscComponentManager
**************************************************************************************************************
*/


wscComponentManager::wscComponentManager(void)
{
    ws_ptr<wsiModuleHolder> mh( new wscMainModuleHolder() );
    AddModuleHolder( wsoLangService::sCID, mh );
}


wscComponentManager::~wscComponentManager(void)
{
}


void wscComponentManager::_realGetClassObject(const ws_cid & aClass, const ws_iid & aIID, void ** ret)
{
	ws_ptr<wsiModuleHolder> mh;
    GetModuleHolder( aClass, mh.GetPtr2() );

    ws_ptr<wsiModule> md;
    mh->GetModule( md.GetPtr2() );

    md->GetClassObject( this, aClass, aIID, ret );
}


void wscComponentManager::_realGetClassObjectByContractID(wsiCString * aContractID, const ws_iid & aIID, void ** ret)
{
	ws_ptr<wsiComponentRegistrar> cr;
	WSCOM::WS_GetComponentRegistrar( cr.GetPtr2() );
	ws_cid cid;
	cr->ContractIDToCID( aContractID, cid );

	_realGetClassObject( cid, aIID, ret );
}


void wscComponentManager::_realCreateInstance(const ws_cid & aClass, wsiObject * aDelegate, const ws_iid & aIID, void ** ret)
{
	ws_ptr<wsiFactory> factory;
	_realGetClassObject( aClass, factory.GetIID(), (void**) factory.GetPtr2() );
	factory->CreateInstance( aDelegate, aIID, ret );
}


void wscComponentManager::_realCreateInstanceByContractID(wsiCString * aContractID, wsiObject * aDelegate, const ws_iid & aIID, void ** ret)
{
	ws_ptr<wsiFactory> factory;
	_realGetClassObjectByContractID( aContractID, factory.GetIID(), (void**) factory.GetPtr2() );
	factory->CreateInstance( aDelegate, aIID, ret );
}




void wscComponentManager::GetModuleHolder(const ws_cid & aClass, wsiModuleHolder ** ret)
{
	try {
        GetModuleHolderNoLoad( aClass, ret );
		return;
	} catch (...) {
		
        // load factory here ...to do

        ws_ptr<wsiComponentRegistrarEx> cre;
        QueryInterface( cre.GetIID(), (void**) cre.GetPtr2() );

        ws_ptr<wsiFile> libfile;
        cre->GetLibFileByCID( aClass, libfile.GetPtr2() );

		ws_ptr<wsiModuleHolder> mh( new wscSubModuleHolder(libfile) );
        AddModuleHolder( aClass, mh );
        mh.QueryInterface( ret );
	}
}


void wscComponentManager::GetModuleHolderNoLoad(const ws_cid & aClass, wsiModuleHolder ** ret)
{
	wsuSingleLock lock( & m_mutexForMHs );
    if ( m_mhs.empty() ) {
        WS_THROW( wseClassNotFoundException , "The required class factory not found in factory list of wscComponentManager." );
    }
	mh_list::iterator iter = m_mhs.find( aClass );
	mh_list::iterator end  = m_mhs.end();
    if (iter==end) {
        WS_THROW( wseClassNotFoundException , "The required class factory not found in factory list of wscComponentManager." );
    }
	(*iter).second.QueryInterface( ret );
}


void wscComponentManager::AddModuleHolder(const ws_cid & aClass, wsiModuleHolder * aMH)
{
    ws_ptr<wsiModuleHolder> mh( aMH );
    if ( mh.IsNull() ) {
		WS_THROW( wseNullPointerException , "Add a null factory to factory list." );
    }
	mh_list::value_type value( aClass, mh );
	wsuSingleLock lock( & m_mutexForMHs );
	m_mhs.insert( value );
}

