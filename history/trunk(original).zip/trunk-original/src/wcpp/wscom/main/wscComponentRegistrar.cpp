#include "wscComponentRegistrar.h"
#include <wcpp/lang/wscThrowable.h>
#include "wsiComponentRegistrarEx.h"


wscComponentRegistrar::wscComponentRegistrar(void)
{
}


wscComponentRegistrar::~wscComponentRegistrar(void)
{
}


void wscComponentRegistrar::_realAutoRegister( wsiFile * aSpec )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realAutoUnregister( wsiFile * aSpec )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realRegisterFactory(	const ws_cid & aClass, wsiCString * aClassName, wsiCString * aContractID, wsiFactory * aFactory )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realUnregisterFactory(	const ws_cid & aClass, wsiFactory * aFactory )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realRegisterFactoryLocation(	const ws_cid & aClass, wsiCString * aClassName, wsiCString * aContractID, wsiFile * aFile, wsiCString * aLoaderStr, wsiCString * aType )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realUnregisterFactoryLocation(	const ws_cid & aClass, wsiFile * aFile )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


ws_boolean wscComponentRegistrar::_realIsCIDRegistered( const ws_cid & aClass )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


ws_boolean wscComponentRegistrar::_realIsContractIDRegistered( wsiCString * aContractID )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realEnumerateCIDs( wsiSimpleEnumerator ** rEnum )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realEnumerateContractIDs( wsiSimpleEnumerator ** rEnum )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realCIDToContractID( const ws_cid & aClass, wsiVString * rContractID )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realContractIDToCID( wsiCString * aContractID, ws_cid & rClass )
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realGetLibFileByCID(const ws_cid & aClass, wsiFile ** ret)
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realSaveRegInfo(wsiFile * regfile)
{
	WS_THROW( wseUnsupportedOperationException , "" );
}


void wscComponentRegistrar::_realLoadRegInfo(wsiFile * regfile)
{
	WS_THROW( wseUnsupportedOperationException , "" );
}

