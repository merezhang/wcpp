// <wcpp/wscom/main/ids.h>


#include "wsiComponentRegistrarEx.h"


WS_IMPL_IID_OF( wsiComponentRegistrarEx )

