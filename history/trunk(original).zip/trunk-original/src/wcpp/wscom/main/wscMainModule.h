#ifndef __wscMainModule_h__
#define __wscMainModule_h__

#include <wcpp/wscom/wscModule.h>


class wscMainModule : public wscModule
{
    WS_IMPL_GET_CLASS( "wcpp.wscom.main.wscMainModule" )
public:
	wscMainModule(void);
	~wscMainModule(void);
};


#endif // __wscMainModule_h__
