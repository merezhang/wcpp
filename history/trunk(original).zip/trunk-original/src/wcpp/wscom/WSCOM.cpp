#include "WSCOM.h"
#include <wcpp/lang/ws_ptr.h>
#include "wsiComponentManager.h"
#include "wsiComponentRegistrar.h"
#include "wsiMemory.h"
#include "wsiServiceManager.h"


void WSCOM::WS_InitWSCOM(wsiServiceManager ** result, wsiFile * binDirectory, wsiDirectoryServiceProvider * appFileLocationProvider)
{
	_WS_InitWSCOM( result, binDirectory, appFileLocationProvider );
}

	
void WSCOM::WS_ShutdownWSCOM(wsiServiceManager * servMgr)
{
	_WS_ShutdownWSCOM( servMgr );
}


void WSCOM::WS_GetServiceManager(wsiServiceManager ** result)
{
	static ws_ptr<wsiServiceManager> sInst;
	if (sInst.IsNull()) {
		_GetGlobalManager( sInst.GetIID(), (void**) sInst.GetPtr2() );
	}
	sInst.QueryInterface( result );
}


void WSCOM::WS_GetComponentManager(wsiComponentManager ** result)
{
	static ws_ptr<wsiComponentManager> sInst;
	if (sInst.IsNull()) {
		_GetGlobalManager( sInst.GetIID(), (void**) sInst.GetPtr2() );
	}
	sInst.QueryInterface( result );
}


void WSCOM::WS_GetComponentRegistrar(wsiComponentRegistrar ** result)
{
	static ws_ptr<wsiComponentRegistrar> sInst;
	if (sInst.IsNull()) {
		_GetGlobalManager( sInst.GetIID(), (void**) sInst.GetPtr2() );
	}
	sInst.QueryInterface( result );
}


void WSCOM::WS_GetMemoryManager(wsiMemory ** result)
{
	static ws_ptr<wsiMemory> sInst;
	if (sInst.IsNull()) {
		_GetGlobalManager( sInst.GetIID(), (void**) sInst.GetPtr2() );
	}
	sInst.QueryInterface( result );
}




WSCOM::WSCOM(void)
{
}


WSCOM::~WSCOM(void)
{
}


