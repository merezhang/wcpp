#pragma once
#include <wcpp/wscom/WSCOM.h>
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/wspr/wsuMutex.h>


class wsiModule;


class WSCOM_sub : public WSCOM
{
public:
	WSCOM_sub(void);
	~WSCOM_sub(void);
public:
	static void _real_WSGetModule(wsiComponentManager *aCompMgr, wsiFile* location, wsiModule** return_cobj);
	static void GetGlobalManager_sub(const ws_iid & aIID, void ** ret);
private:
	static ws_ptr<wsiComponentManager> s_GlobalMgr;
	static wsuMutex s_Mutex;
};

