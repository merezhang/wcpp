#include "wscFactory.h"
#include <wcpp/lang/wscThrowable.h>


wscFactory::wscFactory(void)
{
}


wscFactory::~wscFactory(void)
{
}


void wscFactory::_realCreateInstance(wsiObject * aOuter, const ws_iid & aIID, void ** ret)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


void wscFactory::_realLockFactory(ws_boolean aLock)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}

