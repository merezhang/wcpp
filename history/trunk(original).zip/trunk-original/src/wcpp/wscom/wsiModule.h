#pragma once
#include <wcpp/lang/wsiObject.h>


class wsiComponentManager;
class wsiFile;
class wsiCString;


class wsiModule : public wsiObject
{
public:
	static const ws_iid sIID;
public:
	virtual void       GetClassObject(wsiComponentManager * aCompMgr, const ws_cid & aCID, const ws_iid & aIID, void ** ret) = 0;
	virtual void       RegisterSelf  (wsiComponentManager * aCompMgr, wsiFile * aLocation, wsiCString * aLoaderStr, wsiCString * aType) = 0;
	virtual void       UnregisterSelf(wsiComponentManager * aCompMgr, wsiFile * aLocation, wsiCString * aLoaderStr) = 0;
	virtual ws_boolean CanUnload     (wsiComponentManager * aCompMgr) = 0;
};

