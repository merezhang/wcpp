#include "ws_thread.h"


ws_thread::ws_thread(void)
{
}


ws_thread::~ws_thread(void)
{
}

