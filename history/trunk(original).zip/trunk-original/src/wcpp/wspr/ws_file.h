#pragma once

#include "ws_type.h"


class ws_file
{
protected:
    ws_file(void);
public:
    static ws_file * Open(const ws_char * const filename, const ws_uint32 flag);
public:
    virtual ~ws_file(void);
public:
    virtual ws_int Read (void * const buf, const ws_int cb) = 0;
    virtual void   Write(const void * const buf, const ws_int cb) = 0;
    virtual void   Flush(void) = 0;
    virtual void   Close(void) = 0;
};

