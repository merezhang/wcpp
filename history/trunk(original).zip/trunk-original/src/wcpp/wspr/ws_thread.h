#pragma once

#include "ws_type.h"


class ws_runnable
{
public:
    virtual void ThreadProc(void) = 0;
};


class ws_thread
{
protected:
    ws_thread(void);
public:
    static ws_thread * StartThread(ws_runnable * pRun);
    static void Sleep(ws_long millis);
public:
    virtual ~ws_thread(void);
	virtual ws_int GetPriority(void) = 0;
};

