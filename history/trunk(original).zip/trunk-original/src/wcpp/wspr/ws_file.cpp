#include "ws_file.h"


ws_file::ws_file(void)
{
}


ws_file::~ws_file(void)
{
}

