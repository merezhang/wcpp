#pragma once
#include "ws_type.h"


class ws_library
{
public:
    static ws_library * Load(const ws_char* const aPath);
protected:
    ws_library(void);
public:
    virtual ~ws_library(void);
    virtual void * GetProc(const ws_char* const aProcName) = 0;
};

