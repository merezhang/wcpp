#pragma once

#include "ws_type.h"


class wspr
{
public:

    static ws_int ws_strlen(const ws_char * const str);

};

