/* 
 * File:   ws_mutex.h
 * Author: Xukun
 *
 * Created on 2009��7��17��, ����11:42
 */

#ifndef _WS_MUTEX_H
#define	_WS_MUTEX_H


class ws_mutex
{
protected:
    ws_mutex(void);
    ws_mutex(const ws_mutex& orig);
public:
    static ws_mutex * New(void);
public:
    virtual ~ws_mutex(void);
    virtual void Lock(void) = 0;
    virtual void Unlock(void) = 0;
};


#endif	/* _WS_MUTEX_H */
