#include "wspr.h"


ws_int wspr::ws_strlen(const ws_char *const str)
{
    const ws_char * end = str;
    while (*end) {
        end++;
    }
    return static_cast<ws_int>(end-str);
}

