#pragma


#define WS_PLATFORM_WIN32   1
#define WS_PLATFORM_MACOS   2
#define WS_PLATFORM_LINUX   3

#define WS_PLATFORM     WS_PLATFORM_WIN32



