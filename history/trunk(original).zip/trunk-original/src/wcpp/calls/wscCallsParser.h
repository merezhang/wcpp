#pragma once
#include <wcpp/lang/ws_ptr.h>


class wsiCallsHandler;


class wscCallsParser : public wsiCallsParser
{
public:
    wscCallsParser(wsiCallsHandler * ch);
    ~wscCallsParser(void);
private:
    ws_ptr<wsiCallsHandler> m_ch;
};

