#pragma once
#include "wsiCallsHandler.h"


class wsiCallsSerializer : public wsiCallsHandler
{
public:
    static const ws_iid sIID;
public:
};

