#pragma once
#include <wcpp/lang/wsiObject>


class wsiCallsParser : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    virtual void parse(wsiInputStream * is) = 0;
};

