#pragma once
#include <wcpp/lang/wsiObject.h>


class wsiCallsHandler : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    virtual void OnMethod( wsiCString * method, wsiCallsParamList * aParamList ) = 0;
};

