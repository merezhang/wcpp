#pragma once
#include <wcpp/io/wscOutputStream.h>
#include <wcpp/lang/wscString.h>


class utOutputStream : public wscOutputStream
{
    WS_IMPL_GET_CLASS( "unit_test.utOutputStream" )
public:
    utOutputStream(void);
    ~utOutputStream(void);
    static void Init(void);
protected:
	virtual void _realWrite(ws_int b);
private:
    CFile * m_file;
};

