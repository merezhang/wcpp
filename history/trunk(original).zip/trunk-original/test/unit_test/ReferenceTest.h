#pragma once
#include "testcase.h"

class ReferenceTest : public TestCase
{
    WS_IMPL_GET_CLASS( "ReferenceTest" )
public:

	ReferenceTest(void);
	~ReferenceTest(void);

private:

	virtual void doTest(void);


	void test_WeakReference(void);

};



