#include <windows.h>

#include "WscomTest.h"
#include <wcpp/lang/ws_ptr.h>
#include <wcpp/wscom/wsiServiceManager.h>
#include <wcpp/wscom/WSCOM.h>
#include <wcpp/wscom/wscModule.h>
#include <wcpp/lang/ws_str.h>


WscomTest::WscomTest(void)
{
}


WscomTest::~WscomTest(void)
{
}




void WscomTest::doTest(void)
{
	trace( "========================================\n" );
	trace( "case:WscomTest - begin\n" );

	test_WSCOM_static_funcs();
	test_LoadLibrary();

	trace( "case:WscomTest - end\n" );
	trace( "========================================\n" );
}




void WscomTest::test_WSCOM_static_funcs(void)
{
	trace( "    --------------------------------    \n" );
	trace( "func:test_WSCOM_static_funcs - begin\n" );

	try {
		ws_ptr<wsiServiceManager> aServMgr;

		if (true) {
			ws_ptr<wsiServiceManager> sm;
			trace( "WSCOM::WS_InitWSCOM" );
			WSCOM::WS_InitWSCOM( sm.GetPtr2(), WS_NULL, WS_NULL );
			if (sm.IsNull()) {
				trace( " - error : return null ServiceManager.\n" );
			} else {
				trace( " - ok\n" );
			}
			aServMgr = sm;
		}

		if (true) {
			ws_ptr<wsiComponentManager> cm;
			trace( "WSCOM::WS_GetComponentManager" );
			WSCOM::WS_GetComponentManager( cm.GetPtr2() );
			if (cm.IsNull())
				trace( " - error : return null Component Manager.\n" );
			else
				trace( " - ok\n" );
		}

		if (true) {
			ws_ptr<wsiComponentRegistrar> cr;
			trace( "WSCOM::WS_GetComponentRegistrar" );
			WSCOM::WS_GetComponentRegistrar( cr.GetPtr2() );
			if (cr.IsNull()) {
				trace( " - error : return null wsiComponentRegistrar.\n" );
			} else {
				trace( " - ok\n" );
			}
		}

		if (true) {
			ws_ptr<wsiMemory> mm;
			trace( "WSCOM::WS_GetMemoryManager" );
			WSCOM::WS_GetMemoryManager( mm.GetPtr2() );
			if (mm.IsNull()) {
				trace( " - error : return null wsiMemory.\n" );
			} else {
				trace( " - ok\n" );
			}
		}

		if (true) {
			ws_ptr<wsiServiceManager> sm;
			trace( "WSCOM::WS_GetServiceManager" );
			WSCOM::WS_GetServiceManager( sm.GetPtr2() );
			if (sm.IsNull()) {
				trace( " - error : return null wsiServiceManager.\n" );
			} else {
				trace( " - ok\n" );
			}
		}

		if (true) {
			trace( "WSCOM::WS_ShutdownWSCOM" );
			WSCOM::WS_ShutdownWSCOM( aServMgr );
			aServMgr.Release();
			trace( " - ok\n" );
		}
	}
	catch (...) {
		trace( "test_WSCOM_static_funcs exception\n" );
	}

	trace( "func:test_WSCOM_static_funcs - end\n" );
	trace( "    --------------------------------    \n" );
}




void WscomTest::test_LoadLibrary(void)
{
	trace( "    --------------------------------    \n" );
	trace( "func:test_LoadLibrary - begin\n" );

	try {
		HINSTANCE hDLL = LoadLibraryA( "wcpp.net.win32.dll" );
        if (hDLL==NULL) {
            WS_THROW( wseNullPointerException , "" );
        }

		ws_proc_WSGetModule pEntry =(ws_proc_WSGetModule) GetProcAddress( hDLL, "WSGetModule" );
        if (pEntry==NULL) {
            WS_THROW( wseNullPointerException , "" );
        }

		ws_ptr<wsiComponentManager> aCompMgr;
		WSCOM::WS_GetComponentManager( aCompMgr.GetPtr2() );

		ws_ptr<wsiModule> aModule;
		trace( "WSGetModule" );
		pEntry( aCompMgr, WS_NULL, aModule.GetPtr2() );
		if (aModule.IsNull()) {
			trace( " - error : return null wsiModule.\n" );
		} else {
			trace( " - ok.\n" );
		}

		ws_str str("");
		aModule->RegisterSelf( WS_NULL, WS_NULL, str, str );

	//	AfxFreeLibrary( hDLL );
	}
	catch (wscThrowable e) {
		ws_str str;
		e.GetMessage( str );
		trace( "    msg : " );
		trace( str );
		trace( "\n" );
		trace( "test_LoadLibrary exception\n" );
	}
	catch (...) {
		trace( "test_LoadLibrary exception\n" );
	}

	trace( "func:test_LoadLibrary - end\n" );
	trace( "    --------------------------------    \n" );
}



