#pragma once
#include "testcase.h"


class wsiServiceManager;


class ServiceManagerTest : public TestCase
{
    WS_IMPL_GET_CLASS( "ServiceManagerTest" )
public:
	ServiceManagerTest(void);
	~ServiceManagerTest(void);

	virtual void doTest(void);

private:

	void test_GetService(wsiServiceManager * aServMgr);
	void test_GetServiceByContractID(wsiServiceManager * aServMgr);
	void test_IsServiceInstantiated(wsiServiceManager * aServMgr);
	void test_IsServiceInstantiatedByContractID(wsiServiceManager * aServMgr);

};



