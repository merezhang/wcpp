#pragma once
#include "testcase.h"


class StringTest : public TestCase
{
    WS_IMPL_GET_CLASS( "StringTest" )
public:
	StringTest(void);
public:
	~StringTest(void);

	virtual void doTest(void);




	void test_wsString(void);
	void test_wsLong_ToString(void);
	void test_wscUUID_ToString(void);



};

