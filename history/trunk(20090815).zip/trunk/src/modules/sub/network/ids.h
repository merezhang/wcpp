#pragma once



#include "wscNetworkModule.h"


const ws_char * const wscNetworkModule::s_class_name = "modules.sub.network.wscNetworkModule";

