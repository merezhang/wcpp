#pragma once

#include "wscPimapModule.h"



const ws_char * const wscPimapModule::s_class_name = "modules.sub.pimap.wscPimapModule";


