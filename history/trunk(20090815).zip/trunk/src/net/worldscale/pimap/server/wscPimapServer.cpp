#include "wscPimapServer.h"
#include <wcpp/lang/wscThrowable.h>



wscPimapServer::wscPimapServer(void)
{
}


wscPimapServer::~wscPimapServer(void)
{
}


ws_result wscPimapServer::Start(ws_int nPort)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}


ws_result wscPimapServer::Stop(void)
{
    WS_THROW( wseUnsupportedOperationException , "" );
}

