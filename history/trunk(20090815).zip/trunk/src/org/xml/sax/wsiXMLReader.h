#pragma once


class wsiXMLReader : public wsiObject
{
public:
    static const ws_iid sIID;
public:
};

