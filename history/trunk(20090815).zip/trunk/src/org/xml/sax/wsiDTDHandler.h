#pragma once


class wsiDTDHandler : public wsiObject
{
public:
    static const ws_iid sIID;
public:
};

