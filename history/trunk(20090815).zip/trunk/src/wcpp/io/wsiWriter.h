#ifndef __wsiWriter_h__
#define __wsiWriter_h__

#include <wcpp.lang/wsiObject.h>




class wsiWriter : public wsiObject
{
public:
	static const ws_iid sIID;
};




#endif // __wsWriter_h__
