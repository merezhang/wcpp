﻿#ifndef __wscByteArrayInputStream_h__
#define __wscByteArrayInputStream_h__

#include "wscInputStream.h"
#include "wsiByteArrayInputStream.h"




class wscByteArrayInputStream : public wscInputStream, public wsiByteArrayInputStream
{
};




#endif // __wsByteArrayInputStream_h__
