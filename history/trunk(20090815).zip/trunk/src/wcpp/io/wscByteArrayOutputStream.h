﻿#ifndef __wscByteArrayOutputStream_h__
#define __wscByteArrayOutputStream_h__

#include "wscOutputStream.h"
#include "wsiByteArrayOutputStream.h"




class wscByteArrayOutputStream : public wscOutputStream, public wsiByteArrayOutputStream
{
};




#endif // __wsByteArrayOutputStream_h__
