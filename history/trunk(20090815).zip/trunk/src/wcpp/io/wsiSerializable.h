#pragma once

#include <wcpp/lang/wsiObject.h>


class wsiSerializable : public wsiObject
{
public:
    static const ws_iid sIID;
};

