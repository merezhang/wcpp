#ifndef __wsiByteArrayOutputStream_h__
#define __wsiByteArrayOutputStream_h__

#include "wsiOutputStream.h"




class wsiByteArrayOutputStream : public wsiOutputStream
{
public:
	static const ws_iid sIID;
};




#endif // __wsByteArrayOutputStream_h__
