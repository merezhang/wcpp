﻿#ifndef __wscWriter_h__
#define __wscWriter_h__

#include <wcpp/lang/wscObject.h>
#include "wsiWriter.h"




class wscWriter : public wscObject, public wsiWriter
{
};




#endif // __wsWriter_h__
