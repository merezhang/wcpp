#ifndef __wsiDataInput_h__
#define __wsiDataInput_h__

#include <wcpp.lang/wsiObject.h>


class wsiDataInput : public wsiObject
{
public:
	static const ws_iid sIID;
};


#endif // __wsIDataInput_h__
