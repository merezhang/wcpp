#pragma once

#include "wsiCallsParser.h"
#include "wsiCallsSerializer.h"


WS_IMPL_IID_OF( wsiCallsParser )
WS_IMPL_IID_OF( wsiCallsSerializer )

