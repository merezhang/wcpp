// wsuSyncObject.cpp
#include "wsuSyncObject.h"


wsuSyncObject::wsuSyncObject(void)
{
}


wsuSyncObject::wsuSyncObject(const wsuSyncObject & init)
{
}


wsuSyncObject::~wsuSyncObject(void)
{
}


const wsuSyncObject & wsuSyncObject::operator=(const wsuSyncObject & src)
{
	return (*this);
}

