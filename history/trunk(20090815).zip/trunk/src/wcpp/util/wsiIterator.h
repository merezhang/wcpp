#pragma once

#include <wcpp/lang/wsiObject.h>


template <typename E>
class wsiIterator : public wsiObject
{
public:
    static const ws_iid sIID;
};

