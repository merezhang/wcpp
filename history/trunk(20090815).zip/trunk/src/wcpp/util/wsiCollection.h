#pragma once


template <typename E>
class wsiCollection : public wsiIterable<E>
{
public:
    static const ws_iid sIID;
};

