#pragma once

#include <wcpp/lang/wsiObject.h>


template <typename K , typename V>
class wsiMap : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    ;
};


