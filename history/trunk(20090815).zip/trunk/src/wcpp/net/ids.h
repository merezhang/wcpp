// <wcpp.net/ids.h>


#include "wscNetworkLibrary.h"



WS_IMPL_CID_OF( wscNetworkLibrary )
WS_IMPL_ClassName_OF( wscNetworkLibrary )
WS_IMPL_ContractID_OF( wscNetworkLibrary )


const ws_char * const wscNetworkLibrary::t_factory::s_class_name = "wcpp.net.wscNetworkLibrary::t_factory";




