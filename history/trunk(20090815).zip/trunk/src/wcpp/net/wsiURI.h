#pragma once

#include <wcpp/lang/wsiObject.h>


#define WS_IID_OF_wsiURI        \
    { 0x9fc4b9bf, 0x2a17, 0x4071, { 0x8d, 0x1, 0xde, 0x70, 0xfb, 0xbf, 0x8f, 0x72 } }
// {9FC4B9BF-2A17-4071-8D01-DE70FBBF8F72}


class wsiURI : public wsiObject
{
public:
    static const ws_iid sIID;
public:
    ;
};

