#pragma once

#include "wsiObject.h"


class wsiCloneable : public wsiObject
{
public:
    static const ws_iid sIID;
};


