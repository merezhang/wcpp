#include "ws_runtime.h"


ws_runtime * ws_runtime::s_pRuntime = WS_NULL;


