#pragma once
#include "wsinumber.h"




class wsiDouble : public wsiNumber
{
public:
	static const ws_iid sIID;
};



