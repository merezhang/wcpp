#pragma once

#include <wcpp/wscom/wsiComponentRegistrar.h>


