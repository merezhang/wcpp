#pragma once

#include <wcpp/wscom/wscModule.h>


class wscSubModule : public wscModule
{
protected:
    wscSubModule(void);
    ~wscSubModule(void);
};

