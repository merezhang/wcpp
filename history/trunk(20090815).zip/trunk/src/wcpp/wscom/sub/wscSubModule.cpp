#include "wscSubModule.h"
#include "WSCOM_sub.h"


wscSubModule::wscSubModule(void)
{
}


wscSubModule::~wscSubModule(void)
{
}

