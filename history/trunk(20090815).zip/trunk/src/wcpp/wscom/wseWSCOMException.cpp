#include "wseWSCOMException.h"




const ws_char* const wseLoadModuleException::s_class_name = "wcpp.wscom.main.wseLoadModuleException";
const ws_char* const wseWSCOMException::s_class_name      = "wcpp.wscom.main.wseWSCOMException";



